#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/source_project"
BUILD="$ROOT/build-macos-universal"

printf '\n=== Praat AudioTools macOS Universal 2 build ===\n'
printf 'Project: %s\n' "$SRC"
printf 'Build:   %s\n\n' "$BUILD"

if ! command -v cmake >/dev/null 2>&1; then
    echo "ERROR: cmake was not found. Install CMake 3.25 or newer and run this script again."
    exit 2
fi

if ! command -v xcodebuild >/dev/null 2>&1; then
    echo "ERROR: Xcode was not found. Install the full Xcode application, open it once, and accept its license."
    exit 2
fi

if ! xcode-select -p >/dev/null 2>&1; then
    echo "ERROR: xcode-select has no active developer directory."
    echo "Try: sudo xcode-select -s /Applications/Xcode.app/Contents/Developer"
    exit 2
fi

DEV_DIR="$(xcode-select -p)"
if [[ "$DEV_DIR" != *"Xcode.app/Contents/Developer"* ]]; then
    echo "ERROR: the full Xcode application is not selected."
    echo "Current developer directory: $DEV_DIR"
    echo "Install/open Xcode, then run:"
    echo "  sudo xcode-select -s /Applications/Xcode.app/Contents/Developer"
    exit 2
fi

printf '%s\n' "--- Environment ---"
sw_vers || true
uname -m || true
cmake --version | head -n 1
xcodebuild -version | head -n 2
printf '\n'

if [[ "${CLEAN:-0}" == "1" ]]; then
    echo "CLEAN=1 -> removing old build directory"
    rm -rf "$BUILD"
fi

printf '%s\n' "--- Configure ---"
cmake -S "$SRC" -B "$BUILD" -G Xcode \
    -DMAX_SDK_PACKAGE_OUT_OF_TREE=ON \
    -DCMAKE_OSX_ARCHITECTURES="x86_64;arm64" \
    -DCMAKE_OSX_DEPLOYMENT_TARGET="11.0"

printf '\n%s\n' "--- Build Release ---"
cmake --build "$BUILD" --config Release --parallel "$(sysctl -n hw.ncpu 2>/dev/null || echo 4)"

MXO="$BUILD/package/externals/AudioTools.praat~.mxo"
BIN="$MXO/Contents/MacOS/AudioTools.praat~"

if [[ ! -d "$MXO" || ! -f "$BIN" ]]; then
    echo "ERROR: build finished, but the expected external was not found:"
    echo "  $MXO"
    echo "Searching build tree:"
    find "$BUILD" -name 'AudioTools.praat~.mxo' -print || true
    exit 3
fi

printf '\n%s\n' "--- Universal 2 verification ---"
ARCHS="$(lipo -archs "$BIN")"
echo "Architectures: $ARCHS"
case " $ARCHS " in
    *" x86_64 "*) ;;
    *) echo "ERROR: x86_64 slice is missing."; exit 4;;
esac
case " $ARCHS " in
    *" arm64 "*) ;;
    *) echo "ERROR: arm64 slice is missing."; exit 4;;
esac

file "$BIN"

printf '\n%s\n' "--- Ad-hoc sign for local Max testing ---"
codesign --force --deep --sign - "$MXO"
codesign --verify --deep --strict --verbose=2 "$MXO"

printf '\n%s\n' "--- Dynamic libraries ---"
otool -L "$BIN" || true

printf '\nSUCCESS: Universal 2 external built.\n'
printf 'External bundle:\n  %s\n' "$MXO"
printf '\nNext step:\n  ./assemble_macos_package.sh /path/to/plugin_AudioTools [/Applications/Praat.app]\n\n'
