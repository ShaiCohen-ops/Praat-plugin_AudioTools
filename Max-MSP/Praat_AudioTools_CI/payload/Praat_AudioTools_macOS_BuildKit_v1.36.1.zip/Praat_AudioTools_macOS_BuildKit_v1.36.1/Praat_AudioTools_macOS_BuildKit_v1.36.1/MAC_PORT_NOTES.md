# AudioTools.praat~ v1.36.1 - macOS Port Notes

The goal of this port is platform parity without changing the musical/DSP logic
of the hosted Praat scripts.

## Source changes made for the first macOS build

1. **Universal 2 CMake target**
   - `CMAKE_OSX_ARCHITECTURES = x86_64;arm64`
   - `CMAKE_OSX_DEPLOYMENT_TARGET = 11.0`
   - Windows-only WIC libraries remain guarded by `if(WIN32)`.

2. **Bundled Praat path on macOS**
   - On Windows, the Praat executable is beside the `.mxe64`.
   - On macOS, `dladdr()` resolves the binary inside
     `AudioTools.praat~.mxo/Contents/MacOS`.
   - The port walks back to the package `externals` directory and looks for:
     `Praat.app/Contents/MacOS/Praat`.
   - `/Applications/Praat.app/Contents/MacOS/Praat` is a development fallback.

3. **Python default**
   - Windows default remains `python`.
   - POSIX/macOS default is `python3`.
   - Python remains an optional script-specific capability, not a dependency of
     the core external.

4. **Library scanner**
   - Package library remains first priority.
   - macOS fallbacks were added for Praat 7 and the Praat 6 legacy location:
     `~/Library/Application Support/Praat/plugin_AudioTools/`
     `~/Library/Preferences/Praat Prefs/plugin_AudioTools/`

5. **150-equivalent visualization mode**
   - Windows keeps its WIC implementation.
   - macOS uses `/usr/bin/sips` to read PNG dimensions and resample the host's
     captured 300-dpi Praat PNG to half width/height.
   - 300 and 600 export modes remain native Praat exports.

6. **Max package metadata**
   - macOS minimum set to 11.0.
   - platforms declare `x64` and `aarch64`.
   - the package assembler places `Praat.app` beside the `.mxo` bundle under
     `externals/`.

7. **Signing for the first test**
   - the locally compiled `.mxo` is ad-hoc signed;
   - official `Praat.app` is copied intact and keeps its upstream signature.

## Intentionally not changed

- v1.36.1 parameter/preset semantics;
- Pause virtualization logic;
- run safety behavior;
- buffer WAV import/export behavior;
- stereo handling;
- Praat Info capture;
- script output strategies;
- headless playback prohibition;
- any Praat AudioTools DSP or musical algorithm.

## Test status

The scripts and package layout have been statically checked in the preparation
environment, but this environment is not macOS and cannot produce or execute a
real `.mxo`. The first Xcode/CMake build on the friend's Mac is therefore the
actual platform validation step.
