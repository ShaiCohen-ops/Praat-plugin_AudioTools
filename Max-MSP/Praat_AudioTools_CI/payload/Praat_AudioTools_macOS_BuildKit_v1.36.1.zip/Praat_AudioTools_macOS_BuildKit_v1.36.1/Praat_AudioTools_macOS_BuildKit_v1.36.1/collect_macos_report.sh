#!/bin/bash
set -u

ROOT="$(cd "$(dirname "$0")" && pwd)"
PKG="${1:-$HOME/Documents/Max 9/Packages/praat}"
REPORT="$ROOT/macOS_BUILD_AND_TEST_REPORT.txt"

{
    echo "Praat AudioTools macOS build/test report"
    date
    echo
    echo "=== macOS ==="
    sw_vers 2>&1
    uname -a 2>&1
    echo
    echo "=== CPU ==="
    uname -m 2>&1
    sysctl -n machdep.cpu.brand_string 2>&1 || true
    echo
    echo "=== Xcode ==="
    xcode-select -p 2>&1 || true
    xcodebuild -version 2>&1 || true
    echo
    echo "=== CMake ==="
    cmake --version 2>&1 || true
    echo
    echo "=== Package ==="
    echo "$PKG"
    if [[ -d "$PKG" ]]; then
        find "$PKG" -maxdepth 2 -print 2>/dev/null | sort
    fi
    echo
    EXTBIN="$PKG/externals/AudioTools.praat~.mxo/Contents/MacOS/AudioTools.praat~"
    PRAATBIN="$PKG/externals/Praat.app/Contents/MacOS/Praat"
    if [[ -f "$EXTBIN" ]]; then
        echo "=== External ==="
        file "$EXTBIN" 2>&1
        lipo -archs "$EXTBIN" 2>&1
        otool -L "$EXTBIN" 2>&1
        codesign -dv --verbose=4 "$PKG/externals/AudioTools.praat~.mxo" 2>&1
        codesign --verify --deep --strict --verbose=4 "$PKG/externals/AudioTools.praat~.mxo" 2>&1
    fi
    echo
    if [[ -f "$PRAATBIN" ]]; then
        echo "=== Praat ==="
        file "$PRAATBIN" 2>&1
        lipo -archs "$PRAATBIN" 2>&1
        codesign -dv --verbose=4 "$PKG/externals/Praat.app" 2>&1
        codesign --verify --deep --strict --verbose=4 "$PKG/externals/Praat.app" 2>&1
    fi
    echo
    echo "=== Library count ==="
    if [[ -d "$PKG/misc/plugin_AudioTools" ]]; then
        find "$PKG/misc/plugin_AudioTools" -type f -iname '*.praat' | wc -l
    fi
} > "$REPORT"

echo "Report written to: $REPORT"
