#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
BUILD="$ROOT/build-macos-universal"
TEMPLATE="$ROOT/package_template/praat"
DIST="$ROOT/dist"
OUTPKG="$DIST/praat"
MXO_SRC="$BUILD/package/externals/AudioTools.praat~.mxo"

usage() {
    cat <<'TXT'
Usage:
  ./assemble_macos_package.sh /path/to/plugin_AudioTools [/path/to/Praat.app]

Examples:
  ./assemble_macos_package.sh ~/Desktop/plugin_AudioTools /Applications/Praat.app
  ./assemble_macos_package.sh ~/Desktop/plugin_AudioTools.zip /Applications/Praat.app

The first argument can be either:
  - the actual plugin_AudioTools directory, or
  - a ZIP containing plugin_AudioTools (or a ZIP whose top-level directory is
    the library itself, such as a GitHub source archive).
TXT
}

if [[ $# -lt 1 || $# -gt 2 ]]; then
    usage
    exit 2
fi

LIB_INPUT="$1"
PRAAT_APP="${2:-/Applications/Praat.app}"

if [[ ! -d "$MXO_SRC" ]]; then
    echo "ERROR: built external not found:"
    echo "  $MXO_SRC"
    echo "Run ./build_macos_universal.sh first."
    exit 3
fi

if [[ ! -e "$LIB_INPUT" ]]; then
    echo "ERROR: AudioTools library input does not exist: $LIB_INPUT"
    exit 3
fi

if [[ ! -d "$PRAAT_APP" ]]; then
    echo "ERROR: Praat.app was not found: $PRAAT_APP"
    echo "Download the official macOS Praat 7.0 disk image, then copy Praat.app to /Applications."
    exit 3
fi

PRAAT_BIN="$PRAAT_APP/Contents/MacOS/Praat"
if [[ ! -x "$PRAAT_BIN" ]]; then
    echo "ERROR: Praat executable not found or not executable:"
    echo "  $PRAAT_BIN"
    exit 3
fi

TMP_LIB=""
cleanup() {
    if [[ -n "$TMP_LIB" && -d "$TMP_LIB" ]]; then rm -rf "$TMP_LIB"; fi
}
trap cleanup EXIT

RESOLVED_LIB=""
resolve_library_dir() {
    local input="$1"
    RESOLVED_LIB=""
    if [[ -d "$input" ]]; then
        RESOLVED_LIB="$input"
        return 0
    fi

    case "$input" in
        *.zip|*.ZIP)
            TMP_LIB="$(mktemp -d "${TMPDIR:-/tmp}/audiotools-lib.XXXXXX")"
            ditto -x -k "$input" "$TMP_LIB"

            if [[ -d "$TMP_LIB/plugin_AudioTools" ]]; then
                RESOLVED_LIB="$TMP_LIB/plugin_AudioTools"
                return 0
            fi

            local found
            found="$(find "$TMP_LIB" -type d -name plugin_AudioTools -print -quit)"
            if [[ -n "$found" ]]; then
                RESOLVED_LIB="$found"
                return 0
            fi

            # GitHub archives usually wrap the repository in one top-level folder.
            local top_count top_dir
            top_count="$(find "$TMP_LIB" -mindepth 1 -maxdepth 1 -type d | wc -l | tr -d ' ')"
            top_dir="$(find "$TMP_LIB" -mindepth 1 -maxdepth 1 -type d -print -quit)"
            if [[ "$top_count" == "1" && -n "$top_dir" ]]; then
                RESOLVED_LIB="$top_dir"
                return 0
            fi
            ;;
    esac
    return 1
}

if ! resolve_library_dir "$LIB_INPUT"; then
    echo "ERROR: could not identify plugin_AudioTools inside: $LIB_INPUT"
    exit 4
fi
LIB_DIR="$RESOLVED_LIB"

SCRIPT_COUNT="$(find "$LIB_DIR" -type f -iname '*.praat' | wc -l | tr -d ' ')"
if [[ "$SCRIPT_COUNT" == "0" ]]; then
    echo "ERROR: the supplied AudioTools library contains no .praat files:"
    echo "  $LIB_DIR"
    exit 4
fi

echo "AudioTools library: $LIB_DIR"
echo "Praat scripts:      $SCRIPT_COUNT"
echo "Praat.app:          $PRAAT_APP"

rm -rf "$DIST"
mkdir -p "$OUTPKG"
ditto "$TEMPLATE" "$OUTPKG"

rm -rf "$OUTPKG/misc/plugin_AudioTools"
mkdir -p "$OUTPKG/misc/plugin_AudioTools"
ditto "$LIB_DIR" "$OUTPKG/misc/plugin_AudioTools"

mkdir -p "$OUTPKG/externals"
rm -rf "$OUTPKG/externals/AudioTools.praat~.mxo" "$OUTPKG/externals/Praat.app"
ditto "$MXO_SRC" "$OUTPKG/externals/AudioTools.praat~.mxo"
ditto "$PRAAT_APP" "$OUTPKG/externals/Praat.app"

# The official Praat application keeps its own upstream signature. Only the
# locally built Max external is ad-hoc signed for this private test build.
codesign --force --deep --sign - "$OUTPKG/externals/AudioTools.praat~.mxo"

"$ROOT/verify_macos_package.sh" "$OUTPKG"

ZIP="$DIST/Praat_AudioTools_1.0.0_macOS_Universal2_TEST.zip"
rm -f "$ZIP"
ditto -c -k --sequesterRsrc --keepParent "$OUTPKG" "$ZIP"

printf '\nSUCCESS: macOS test package assembled.\n'
printf 'Folder: %s\n' "$OUTPKG"
printf 'ZIP:    %s\n\n' "$ZIP"
printf 'Install the folder as:\n  ~/Documents/Max 9/Packages/praat\n'
printf 'Then restart Max.\n\n'
