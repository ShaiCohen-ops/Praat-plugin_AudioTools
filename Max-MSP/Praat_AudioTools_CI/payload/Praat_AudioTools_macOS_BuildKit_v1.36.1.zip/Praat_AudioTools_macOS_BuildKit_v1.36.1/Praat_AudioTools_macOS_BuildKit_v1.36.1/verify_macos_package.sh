#!/bin/bash
set -euo pipefail

PKG="${1:-}"
if [[ -z "$PKG" || ! -d "$PKG" ]]; then
    echo "Usage: ./verify_macos_package.sh /path/to/praat"
    exit 2
fi

MXO="$PKG/externals/AudioTools.praat~.mxo"
EXTBIN="$MXO/Contents/MacOS/AudioTools.praat~"
PRAATAPP="$PKG/externals/Praat.app"
PRAATBIN="$PRAATAPP/Contents/MacOS/Praat"
LIB="$PKG/misc/plugin_AudioTools"

fail=0
need_file() { if [[ ! -f "$1" ]]; then echo "MISSING FILE: $1"; fail=1; fi; }
need_dir()  { if [[ ! -d "$1" ]]; then echo "MISSING DIR:  $1"; fail=1; fi; }

need_file "$PKG/package-info.json"
need_file "$PKG/patchers/praat.maxpat"
need_file "$PKG/extras/Praat AudioTools.maxpat"
need_file "$PKG/javascript/AudioTools.praat.ui.js"
need_file "$PKG/javascript/AudioTools.praat.info.js"
need_file "$PKG/javascript/AudioTools.praat.library.js"
need_file "$PKG/help/AudioTools.praat~.maxhelp"
need_file "$PKG/docs/AudioTools.praat~.maxref.xml"
need_file "$PKG/media/icon.png"
need_file "$PKG/README.md"
need_file "$PKG/LICENSE.md"
need_file "$PKG/THIRD_PARTY_NOTICES.md"
need_file "$PKG/licenses/Praat-GPL-3.0.txt"
need_dir "$MXO"
need_file "$EXTBIN"
need_dir "$PRAATAPP"
need_file "$PRAATBIN"
need_dir "$LIB"

if [[ "$fail" != "0" ]]; then exit 3; fi

python3 -m json.tool "$PKG/package-info.json" >/dev/null

EXT_ARCHS="$(lipo -archs "$EXTBIN")"
PRAAT_ARCHS="$(lipo -archs "$PRAATBIN")"

echo "External architectures: $EXT_ARCHS"
echo "Praat architectures:    $PRAAT_ARCHS"

for a in x86_64 arm64; do
    case " $EXT_ARCHS " in *" $a "*) ;; *) echo "ERROR: external missing $a"; fail=1;; esac
    case " $PRAAT_ARCHS " in *" $a "*) ;; *) echo "ERROR: Praat missing $a"; fail=1;; esac
done

SCRIPT_COUNT="$(find "$LIB" -type f -iname '*.praat' | wc -l | tr -d ' ')"
echo "Bundled .praat files:   $SCRIPT_COUNT"
if [[ "$SCRIPT_COUNT" == "0" ]]; then
    echo "ERROR: bundled AudioTools library is empty."
    fail=1
fi

codesign --verify --deep --strict --verbose=2 "$MXO" || fail=1
codesign --verify --deep --strict --verbose=2 "$PRAATAPP" || {
    echo "WARNING: Praat.app signature verification failed. Use a fresh official Praat.app from the Praat disk image."
    fail=1
}

if [[ "$fail" != "0" ]]; then
    echo "PACKAGE VERIFICATION FAILED"
    exit 4
fi

echo "PACKAGE VERIFICATION PASSED"
