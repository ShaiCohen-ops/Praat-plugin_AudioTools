#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
exec "$ROOT/assemble_macos_package.sh" "$ROOT/tests" "${1:-/Applications/Praat.app}"
