# Praat.app input

Download the official macOS edition from:

https://praat.org/download_mac.html

Copy `Praat.app` to `/Applications/Praat.app`. The assembler copies the whole
application bundle into the Max package and does not modify/re-sign it.
