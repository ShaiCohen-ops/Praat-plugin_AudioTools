# Full AudioTools library input

For the final package, put Shai's exact current library archive here or beside
the BuildKit, typically named:

```text
plugin_AudioTools_for_mac_build.zip
```

Create it on Shai's Windows system using `MAKE_LIBRARY_ZIP_WINDOWS.bat`.

Do not silently substitute an older GitHub snapshot during the first port test:
the purpose is to compare macOS against the exact Windows-tested library.
