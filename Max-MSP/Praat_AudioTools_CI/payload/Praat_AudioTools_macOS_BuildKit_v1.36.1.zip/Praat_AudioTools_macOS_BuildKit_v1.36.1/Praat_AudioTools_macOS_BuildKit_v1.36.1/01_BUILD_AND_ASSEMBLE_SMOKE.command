#!/bin/bash
set -o pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT" || exit 1
chmod +x "$ROOT"/*.sh

echo "Praat AudioTools v1.36.1 - macOS first build"
echo "Detailed instructions: README_BUILD_MAC.md"
echo

./build_macos_universal.sh 2>&1 | tee build_macos.log
rc=${PIPESTATUS[0]}
if [[ "$rc" != "0" ]]; then
    echo
    echo "BUILD FAILED (exit $rc). Send build_macos.log back to Shai."
    read -r -p "Press Return to close..." _
    exit "$rc"
fi

./assemble_smoke_package.sh /Applications/Praat.app 2>&1 | tee assemble_smoke.log
rc=${PIPESTATUS[0]}
if [[ "$rc" != "0" ]]; then
    echo
    echo "SMOKE PACKAGE ASSEMBLY FAILED (exit $rc). Send assemble_smoke.log back to Shai."
    read -r -p "Press Return to close..." _
    exit "$rc"
fi

echo
echo "SUCCESS. The smoke package is in:"
echo "  $ROOT/dist/praat"
echo
echo "Continue at section 6 of README_BUILD_MAC.md to install it in Max 9."
read -r -p "Press Return to close..." _
