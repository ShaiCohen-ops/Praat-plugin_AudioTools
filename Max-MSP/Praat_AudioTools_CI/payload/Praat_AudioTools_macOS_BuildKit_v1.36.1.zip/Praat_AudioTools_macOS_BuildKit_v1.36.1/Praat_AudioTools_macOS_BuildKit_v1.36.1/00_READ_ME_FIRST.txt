PRAAT AUDIOTOOLS v1.36.1 - macOS UNIVERSAL 2 BUILD KIT
======================================================

This kit is for the FIRST real macOS compilation and runtime test of
AudioTools.praat~ v1.36.1.

Target:
  macOS 11 or later
  Max 9
  Universal 2 external: x86_64 + arm64

The builder does NOT need Git.
The builder DOES need:
  1. a Mac
  2. Max 9
  3. full Xcode
  4. CMake 3.25 or later
  5. official Praat.app from praat.org
  6. Internet access during the first CMake configure, because the project
     downloads a PINNED max-sdk-base source archive over HTTPS.

FIRST READ:
  README_BUILD_MAC.md

For the first test, do NOT start with the full 400+ script library.
Build the external, assemble the supplied four-script smoke package, and make
sure Max can load and run it. Only then assemble the full library package.

Recommended first commands:
  cd ~/Desktop/Praat_AudioTools_macOS_BuildKit_v1.36.1
  chmod +x *.sh
  ./build_macos_universal.sh 2>&1 | tee build_macos.log
  ./assemble_smoke_package.sh /Applications/Praat.app 2>&1 | tee assemble_smoke.log

IMPORTANT:
This is a private TEST build. The script ad-hoc signs the locally built .mxo,
which is appropriate for local Max testing. It is NOT a substitute for the
Developer ID signing/notarization procedure that should be used for a public
macOS release.
