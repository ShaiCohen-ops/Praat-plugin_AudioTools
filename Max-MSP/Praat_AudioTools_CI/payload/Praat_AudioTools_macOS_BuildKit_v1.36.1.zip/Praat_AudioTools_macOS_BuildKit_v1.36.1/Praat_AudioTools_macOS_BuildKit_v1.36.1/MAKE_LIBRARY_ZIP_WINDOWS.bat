@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

rem ============================================================
rem Praat AudioTools library packer for macOS build
rem
rem IMPORTANT:
rem A candidate is accepted only if it actually contains .praat
rem files.  This avoids selecting an empty/stale Praat preferences
rem folder merely because the directory exists.
rem
rem Priority for this build:
rem   1. %USERPROFILE%\Praat\plugin_AudioTools
rem   2. Max package bundled library
rem   3. %APPDATA%\Praat\plugin_AudioTools
rem ============================================================

set "SRC="
set "COUNT=0"

call :TrySource "%USERPROFILE%\Praat\plugin_AudioTools"
if defined SRC goto :SourceFound

call :TrySource "%USERPROFILE%\Documents\Max 9\Packages\Praat_AudioTools\misc\plugin_AudioTools"
if defined SRC goto :SourceFound

call :TrySource "%APPDATA%\Praat\plugin_AudioTools"
if defined SRC goto :SourceFound

echo.
echo ERROR: No usable plugin_AudioTools library was found.
echo A usable library must contain at least one .praat file.
echo.
echo Checked:
echo   %USERPROFILE%\Praat\plugin_AudioTools
echo   %USERPROFILE%\Documents\Max 9\Packages\Praat_AudioTools\misc\plugin_AudioTools
echo   %APPDATA%\Praat\plugin_AudioTools
echo.
exit /b 2

:SourceFound
echo.
echo Selected source:
echo   %SRC%
echo Praat scripts:
echo   %COUNT%
echo.

set "OUT=%~dp0plugin_AudioTools_for_mac_build.zip"
set "INFO=%~dp0plugin_AudioTools_for_mac_build_INFO.txt"

if exist "%OUT%" del /q "%OUT%"
if exist "%INFO%" del /q "%INFO%"

echo Creating:
echo   %OUT%
echo.

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "Compress-Archive -LiteralPath $env:SRC -DestinationPath $env:OUT -CompressionLevel Optimal -Force"

if errorlevel 1 (
    echo.
    echo ERROR: Compress-Archive failed.
    exit /b 3
)

(
  echo Praat AudioTools library prepared for macOS build
  echo Source: %SRC%
  echo .praat files: %COUNT%
  echo Created: %DATE% %TIME%
) > "%INFO%"

echo.
echo SUCCESS.
echo Created:
echo   %OUT%
echo   %INFO%
echo.
echo Verify that the INFO file reports the expected source and script count
echo before sending the files to the Mac builder.
echo.
exit /b 0


:TrySource
set "CANDIDATE=%~1"
if not exist "!CANDIDATE!\" goto :eof

set "N=0"
for /f %%N in ('dir /s /b /a-d "!CANDIDATE!\*.praat" 2^>nul ^| find /c /v ""') do set "N=%%N"

if "!N!"=="0" (
    echo Skipping empty candidate:
    echo   !CANDIDATE!
    goto :eof
)

set "SRC=!CANDIDATE!"
set "COUNT=!N!"
goto :eof
