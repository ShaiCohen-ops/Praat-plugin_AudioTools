# Praat AudioTools v1.36.1 - macOS Universal 2 Build and Test Guide

This folder is intended to be handed to a Mac user who can perform the first
real macOS build of `AudioTools.praat~` v1.36.1. The goal is to produce one
Max external containing both Intel (`x86_64`) and Apple Silicon (`arm64`)
slices, then test the same Praat AudioTools host workflow that is already
working on Windows.

The source in this kit is the v1.36.1 source supplied by Shai Cohen, not the
older v1.25 source that had previously been available in the conversation.
The macOS port changes are deliberately narrow and are documented in
`MAC_PORT_NOTES.md` and `MAC_PORT_CHANGES.diff`.

## 1. What this first test should prove

A successful test should establish all of the following:

- CMake can generate an Xcode build for the v1.36.1 source.
- `AudioTools.praat~.mxo` contains both `x86_64` and `arm64` slices.
- Max 9 can load the external without a missing-object or security-policy error.
- The external finds the bundled `Praat.app` inside the Max package.
- A generator can run headlessly and return audio.
- Praat Info text reaches the Max UI.
- a processor can read a Max input buffer and return processed audio.
- v1.36.1 `beginPause/endPause` virtualization works without opening a Praat dialog.
- visualization capture works on macOS; 150 mode uses Praat's 300-dpi PNG followed
  by a host-side 0.5x resize using the macOS `/usr/bin/sips` utility.
- the package scanner can use a self-contained `misc/plugin_AudioTools` library.

Do the small smoke test BEFORE testing the full library.

## 2. Required software on the Mac

### Max 9

Install Max 9 normally. The macOS deployment target in this kit is 11.0,
matching the Max 9 macOS baseline for Intel and Apple Silicon.

### Full Xcode

Install the full Xcode application from Apple. The Xcode Command Line Tools by
themselves are not enough for this kit because CMake is asked to generate an
Xcode project.

Open Xcode once after installation and allow it to install any requested
components. If necessary, in Terminal run:

```bash
sudo xcode-select -s /Applications/Xcode.app/Contents/Developer
sudo xcodebuild -license accept
```

Check:

```bash
xcode-select -p
xcodebuild -version
```

The first command should normally print:

```text
/Applications/Xcode.app/Contents/Developer
```

### CMake 3.25 or later

Install CMake from https://cmake.org/download/ or with Homebrew if Homebrew is
already used on the machine:

```bash
brew install cmake
```

Homebrew is NOT otherwise required.

If CMake was installed as `/Applications/CMake.app` but `cmake` is not in the
Terminal PATH, this temporary command is enough for the current Terminal:

```bash
export PATH="/Applications/CMake.app/Contents/bin:$PATH"
```

Check:

```bash
cmake --version
```

### Official Praat.app

Download the official current macOS Praat 7 disk image from:

https://praat.org/download_mac.html

Copy `Praat.app` to:

```text
/Applications/Praat.app
```

Check from Terminal:

```bash
/Applications/Praat.app/Contents/MacOS/Praat --version
```

If that command does not report a version on a particular Praat build, simply
check that the binary exists:

```bash
ls -l /Applications/Praat.app/Contents/MacOS/Praat
```

Do not modify or re-sign the official Praat application during this first test.
The package assembler preserves its upstream signature.

## 3. Put the BuildKit in a simple local folder

Unzip this BuildKit, preferably to the Desktop. Avoid building directly inside
iCloud Drive, Dropbox, OneDrive, a network share, or a read-only disk image.

Expected path, for example:

```text
~/Desktop/Praat_AudioTools_macOS_BuildKit_v1.36.1/
```

Open Terminal and enter:

```bash
cd ~/Desktop/Praat_AudioTools_macOS_BuildKit_v1.36.1
chmod +x *.sh
```

## 4. Build the Universal 2 external

Run exactly:

```bash
./build_macos_universal.sh 2>&1 | tee build_macos.log
```

The first CMake configure needs Internet access. It downloads the pinned
Cycling '74 `max-sdk-base` archive specified in `source_project/CMakeLists.txt`.
Git is not required.

The build script explicitly requests:

```text
x86_64;arm64
```

and a macOS 11.0 deployment target.

### Expected successful ending

Near the end of the log, look for lines equivalent to:

```text
Architectures: x86_64 arm64
SUCCESS: Universal 2 external built.
```

The order can also be `arm64 x86_64`; both must be present.

The generated external should be:

```text
build-macos-universal/package/externals/AudioTools.praat~.mxo
```

The script then ad-hoc signs the `.mxo` for local testing, following the normal
Max SDK testing approach for Apple Silicon.

### Rebuilding cleanly

If source/CMake settings change or the first build becomes inconsistent:

```bash
CLEAN=1 ./build_macos_universal.sh 2>&1 | tee build_macos_clean.log
```

## 5. Assemble the SMALL smoke-test package

Do this before using the full AudioTools library:

```bash
./assemble_smoke_package.sh /Applications/Praat.app 2>&1 | tee assemble_smoke.log
```

This builds a package containing only four tiny test scripts:

```text
Mac_Smoke_Generator.praat
Mac_Smoke_Processor.praat
Mac_Smoke_Pause.praat
Mac_Smoke_Visualization.praat
```

The assembled package folder is:

```text
dist/praat
```

and a transport ZIP is also created:

```text
dist/Praat_AudioTools_1.0.0_macOS_Universal2_TEST.zip
```

`ditto` is used to create the ZIP so macOS bundle/resource metadata is retained.

## 6. Install the smoke package in Max 9

Max should be closed while replacing a package that contains an external.

Create the Packages folder if necessary:

```bash
mkdir -p "$HOME/Documents/Max 9/Packages"
```

If a folder named `praat` ALREADY exists there, do not delete it. Back it up:

```bash
mv "$HOME/Documents/Max 9/Packages/praat" \
   "$HOME/Documents/Max 9/Packages/praat.backup"
```

Then install the test package:

```bash
ditto dist/praat "$HOME/Documents/Max 9/Packages/praat"
```

Start Max 9.

Open the package by either:

```text
Extras -> Praat AudioTools
```

or directly open:

```text
~/Documents/Max 9/Packages/praat/patchers/praat.maxpat
```

Keep the Max Console visible during all tests.

## 7. Smoke test A - external load and bundled Praat path

The patch must open without a missing `AudioTools.praat~` object.

The Console/status output should identify external v1.36.1. The Praat executable
should resolve inside the package, conceptually:

```text
.../Max 9/Packages/praat/externals/Praat.app/Contents/MacOS/Praat
```

If it resolves `/Applications/Praat.app/...` instead, report that. The installed
package should prefer its bundled Praat application.

## 8. Smoke test B - generator + Praat Info

Choose:

```text
Mac_Smoke_Generator.praat
```

The UI should expose `frequency_hz` and `duration_s`.

Run it. Expected result:

- no Praat dialog opens;
- processing completes successfully;
- a short 440 Hz sound is returned to the output buffer;
- Praat Info shows the macOS smoke-test text;
- the structured output reports an audio output path.

Listen to the output to make sure the returned buffer is not silent.

## 9. Smoke test C - input-buffer processor

Load any short audio file into the input buffer in the main patch. Stereo is
preferred because this also gives a useful first channel-preservation check.

Choose:

```text
Mac_Smoke_Processor.praat
```

The default gain is 0.5. Run it.

Expected result:

- duration remains the same;
- channel count should remain compatible with the input/output-buffer workflow;
- amplitude is approximately half of the source;
- processing returns without a Praat GUI appearing.

## 10. Smoke test D - v1.36.1 Pause virtualization

Choose:

```text
Mac_Smoke_Pause.praat
```

This script deliberately contains a conditional `beginPause/endPause` advanced
configuration block. Its advanced frequency/amplitude controls should be
virtualized by the Max host.

Run it.

Critical expected behavior:

- NO Praat Pause dialog appears;
- the run does not block;
- the returned tone is produced;
- Praat Info includes:

```text
If this ran headlessly, beginPause/endPause virtualization worked.
```

If any Praat dialog appears, stop and send the exact Console log.

## 11. Smoke test E - visualization + 150 mode

Choose:

```text
Mac_Smoke_Visualization.praat
```

Enable visualization in the Max host and keep the host visual DPI at 150 for
the first run.

Expected Console behavior includes a visual capture and a line similar to:

```text
visual screen downsample -> <width> x <height>
```

The picture should appear in the Jitter visualization area. The macOS port uses
`/usr/bin/sips` to halve Praat's native 300-dpi PNG for this 150-equivalent
screen mode. Then also try 300 mode; it should keep the native Praat 300-dpi
raster.

## 12. Collect the first diagnostic report

After the smoke package is installed, run:

```bash
./collect_macos_report.sh "$HOME/Documents/Max 9/Packages/praat"
```

This creates:

```text
macOS_BUILD_AND_TEST_REPORT.txt
```

It records macOS/CPU/Xcode/CMake versions, package contents, binary architecture
slices, linked libraries, code-signature checks, and the number of bundled
Praat scripts.

## 13. Only after smoke tests pass: assemble the FULL AudioTools package

Shai should also send a second file:

```text
plugin_AudioTools_for_mac_build.zip
```

The BuildKit contains `MAKE_LIBRARY_ZIP_WINDOWS.bat` so that this ZIP can be
created from the exact currently tested Windows library rather than silently
substituting an older GitHub snapshot.

Place that ZIP beside this README and run:

```bash
./assemble_macos_package.sh \
    ./plugin_AudioTools_for_mac_build.zip \
    /Applications/Praat.app \
    2>&1 | tee assemble_full.log
```

The assembler reports the exact number of `.praat` files it found. Do not treat
a hard-coded historical count as authoritative; compare the reported count with
Shai's current Windows library count.

Install the newly assembled `dist/praat` in the same Max Packages location,
restart Max, and test several real library scripts.

At minimum test:

1. one ordinary processor with stereo input;
2. one generator;
3. one analyzer;
4. one script with `beginPause/endPause` virtualization (the current
   `Stockhausen_Studie_II_Generator.praat` is a useful known case);
5. one visualization-heavy script at 150 and 300 modes;
6. one script that emits substantial Praat Info text.

Do not begin with Python/FFmpeg/VST-dependent tools. Those are optional
script-specific dependencies and can be tested after the core host is proven.

## 14. Optional Intel-slice runtime test on Apple Silicon

`lipo` verifies that the Intel slice exists, but if Rosetta is already installed
and you want an actual x86_64 runtime check, Max can optionally be launched under
Rosetta. This is not required for the first pass. Do not install Rosetta solely
for this test unless Shai asks for it.

An actual Intel Mac test is still the strongest verification of the x86_64
slice.

## 15. What to send back to Shai

Please return all of these:

```text
build_macos.log
assemble_smoke.log
assemble_full.log              (after full-library assembly)
macOS_BUILD_AND_TEST_REPORT.txt
Praat_AudioTools_1.0.0_macOS_Universal2_TEST.zip
```

Also send:

- a screenshot of the main Max patch after a successful generator run;
- a screenshot of the visualization smoke test;
- the complete Max Console text for any failure;
- whether the Mac is Intel or Apple Silicon;
- the macOS version and Max 9 version used.

Do not paraphrase compiler or Max errors. Copy the exact text.

## 16. Common build failures

### `cmake: command not found`

Install CMake or add `/Applications/CMake.app/Contents/bin` to PATH as described
above.

### CMake says the Xcode generator cannot be used

Make sure the FULL Xcode application is installed and selected:

```bash
sudo xcode-select -s /Applications/Xcode.app/Contents/Developer
```

Then retry with a clean build:

```bash
CLEAN=1 ./build_macos_universal.sh 2>&1 | tee build_macos_clean.log
```

### First CMake configure cannot download `max-sdk-base`

The source is pinned, but the archive is fetched over HTTPS. Check Internet
access, VPN/firewall restrictions, or GitHub availability. Git itself is not
required.

### Max says the external cannot load because of system security policy

Do not randomly modify the bundle first. Run:

```bash
codesign --verify --deep --strict --verbose=4 \
  "$HOME/Documents/Max 9/Packages/praat/externals/AudioTools.praat~.mxo"
```

and send the exact Max Console error plus the `codesign` output. The build script
already applies an ad-hoc signature intended for local Max testing.

### The external loads but Praat does not run

Check:

```bash
ls -l "$HOME/Documents/Max 9/Packages/praat/externals/Praat.app/Contents/MacOS/Praat"
codesign --verify --deep --strict --verbose=4 \
  "$HOME/Documents/Max 9/Packages/praat/externals/Praat.app"
```

Then send the external's `status` output and the Max Console text.

### 150 visualization works but reports a resize warning

Run this in Terminal:

```bash
/usr/bin/sips --version
```

Then send the exact resize warning and the visual PNG path from the Console.
The host intentionally keeps the 300-dpi PNG if the 0.5x screen resize fails,
so a resize failure should not destroy the original visual output.

## 17. Signing/distribution status

The BuildKit produces a PRIVATE TEST BUILD. The Max external is ad-hoc signed.
That is appropriate for testing a locally built external, but it is not the
final public distribution procedure.

Before a public macOS release or Cycling '74 Package Manager submission, the
finished package should be revalidated against current Apple/Cycling '74
requirements and should use the appropriate Developer ID signing/notarization
workflow. The official Praat application should keep its own upstream
signature.

## 18. Licensing note

The package template contains the Praat AudioTools MIT license, third-party
notices, and a GPLv3 text for bundled Praat. Before public redistribution of a
specific Praat.app build, keep the corresponding source for that exact Praat
version available to recipients as required by Praat's GPL terms.

## Official references

- Max SDK: https://github.com/Cycling74/max-sdk
- Max downloads/system requirements: https://cycling74.com/downloads
- Praat for macOS: https://praat.org/download_mac.html
- Praat source: https://praat.org/download_sources.html
- Praat license: https://praat.org/manual/License.html
