#@tool mode=generator output=host_save_selected_sound
# v1.36.1 macOS smoke test: conditional beginPause/endPause virtualization.

form: "Mac Smoke Pause Virtualization"
    positive: "duration_s", 0.75
    boolean: "edit_details", 1
endform

frequency_hz = 523.251
amplitude = 0.15

if edit_details
    beginPause: "Mac Smoke - Advanced Details"
        positive: "Frequency (Hz)", frequency_hz
        real: "Amplitude", amplitude
    endPause: "Run", 1
endif

clearinfo
writeInfoLine: "=== macOS Pause virtualization smoke test ==="
appendInfoLine: "Frequency: ", frequency_hz, " Hz"
appendInfoLine: "Amplitude: ", amplitude
appendInfoLine: "If this ran headlessly, beginPause/endPause virtualization worked."

Create Sound from formula: "mac_smoke_pause", 1, 0, duration_s, 44100,
    ... "amplitude * sin(2*pi*frequency_hz*x)"
