# Praat AudioTools macOS port smoke test
# This file is for build validation only, not part of the AudioTools library.
#@tool mode=processor output=host_save_selected_sound

form: "Mac Smoke Processor"
    real: "gain", 0.5
endform

clearinfo
writeInfoLine: "=== macOS smoke processor ==="
appendInfoLine: "Gain: ", gain

Formula: "self * gain"
