#@tool mode=generator output=host_save_selected_sound
# v1.36.1 macOS smoke test: legacy Picture capture + host screen downsample.

form: "Mac Smoke Visualization"
    positive: "frequency_hz", 330
    positive: "duration_s", 0.75
    boolean: "draw_visualization", 1
endform

clearinfo
writeInfoLine: "=== macOS visualization smoke test ==="
appendInfoLine: "Frequency: ", frequency_hz, " Hz"

Create Sound from formula: "mac_smoke_visual", 1, 0, duration_s, 44100,
    ... "0.18 * sin(2*pi*frequency_hz*x)"

if draw_visualization
    Erase all
    Select outer viewport: 0, 8, 0, 4.4
    Axes: 0, 1, 0, 1
    Draw inner box
    Draw line: 0.1, 0.2, 0.9, 0.8
    Text top: "yes", "Praat AudioTools - macOS visualization smoke test"
endif
