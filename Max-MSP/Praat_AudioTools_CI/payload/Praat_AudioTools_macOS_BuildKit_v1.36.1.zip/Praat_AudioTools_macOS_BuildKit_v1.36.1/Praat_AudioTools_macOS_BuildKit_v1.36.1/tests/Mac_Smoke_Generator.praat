# Praat AudioTools macOS port smoke test
# This file is for build validation only, not part of the AudioTools library.
#@tool mode=generator output=host_save_selected_sound

form: "Mac Smoke Generator"
    positive: "frequency_hz", 440
    positive: "duration_s", 0.75
endform

clearinfo
writeInfoLine: "=== macOS smoke generator ==="
appendInfoLine: "Frequency: ", frequency_hz, " Hz"
appendInfoLine: "Duration: ", duration_s, " s"

Create Sound from formula: "mac_smoke_440", 1, 0, duration_s, 44100,
    ... "0.20 * sin(2*pi*frequency_hz*x)"
