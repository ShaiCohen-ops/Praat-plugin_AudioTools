# Expected first-pass results

## Build

`build_macos_universal.sh` should finish with:

```text
Architectures: x86_64 arm64
SUCCESS: Universal 2 external built.
```

Both architecture names are mandatory; order is irrelevant.

## Package verification

`assemble_smoke_package.sh` runs `verify_macos_package.sh`. A successful run
should include:

```text
External architectures: ... x86_64 ... arm64 ...
Praat architectures:    ... x86_64 ... arm64 ...
Bundled .praat files:   4
PACKAGE VERIFICATION PASSED
```

## Max smoke tests

- external loads as `AudioTools.praat~`;
- bundled Praat path points inside the package;
- generator returns a non-silent short tone;
- Praat Info arrives in the right-hand Info UI;
- processor returns approximately 0.5 input amplitude;
- Pause test runs with no Praat dialog;
- visualization test generates a PNG and appears in the Jitter viewer;
- 150 visual mode reports host half-size downsampling; 300 mode does not.
