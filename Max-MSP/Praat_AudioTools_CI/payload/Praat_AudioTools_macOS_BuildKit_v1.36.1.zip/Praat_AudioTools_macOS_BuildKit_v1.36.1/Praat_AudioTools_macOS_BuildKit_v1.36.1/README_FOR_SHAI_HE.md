# מה אתה צריך לעשות ב-Windows לפני שמעבירים לחבר

ערכת ה-Mac עצמה כבר כוללת את מקור `AudioTools.praat~ v1.36.1`, את CMake,
סקריפטי הבנייה, תבנית ה-Max Package, בדיקות Smoke, תיעוד ו-License files.

חסר בה בכוונה רק דבר גדול אחד: **העותק המדויק של ספריית `plugin_AudioTools`
שנבדקה אצלך כרגע**. לא רציתי להחליף אותה אוטומטית בגרסת GitHub שעלולה להיות
שונה מהעותק המקומי שלך.

## 1. חלץ את ה-BuildKit ב-Windows

פתח את התיקייה ולחץ פעמיים על:

```text
MAKE_LIBRARY_ZIP_WINDOWS.bat
```

ה-BAT מחפש לפי הסדר:

```text
%USERPROFILE%\Documents\Max 9\Packages\praat\misc\plugin_AudioTools
%APPDATA%\Praat\plugin_AudioTools
%USERPROFILE%\Praat\plugin_AudioTools
```

והוא ייצור לידו:

```text
plugin_AudioTools_for_mac_build.zip
```

בדוק שהקובץ אינו קטן באופן חשוד.

## 2. שלח לחבר את הקבצים הבאים

```text
Praat_AudioTools_macOS_BuildKit_v1.36.1.zip
plugin_AudioTools_for_mac_build.zip
plugin_AudioTools_for_mac_build_INFO.txt
```

קובץ ה-INFO קטן אך שימושי: הוא רושם כמה קבצי `.praat` היו אצלך בעת יצירת ה-ZIP,
כדי שנוכל להשוות למספר שה-Mac assembler מדווח.

בקש ממנו להתחיל מהקובץ:

```text
00_READ_ME_FIRST.txt
```

ואחר כך לבצע בדיוק את `README_BUILD_MAC.md`.

## 3. סדר הבדיקה חשוב

הוא לא מתחיל מ-400+ הסקריפטים. קודם:

1. קומפילציה Universal 2;
2. בדיקה שה-binary מכיל `x86_64` וגם `arm64`;
3. בניית Smoke Package עם ארבעה סקריפטים קטנים;
4. טעינה ב-Max 9;
5. Generator;
6. Praat Info;
7. Processor;
8. Pause virtualization;
9. Visualization 150/300;
10. רק אז Package מלא עם הספרייה שלך.

כך אם תהיה שגיאה נדע מיד אם היא ב-build/host של Mac או בסקריפט מסוים.

## 4. מה הוא צריך להחזיר

```text
build_macos.log
assemble_smoke.log
assemble_full.log
macOS_BUILD_AND_TEST_REPORT.txt
Praat_AudioTools_1.0.0_macOS_Universal2_TEST.zip
```

וגם צילום מסך של Max וה-Console במקרה של תקלה.

## 5. דבר חשוב לגבי חתימה

הבנייה הראשונה היא **TEST build**. ה-external מקבל ad-hoc signature כדי ש-Max
יוכל לטעון external שנבנה מקומית. זה אינו תהליך ההפצה הציבורי הסופי. לאחר
שהכל יעבוד נוכל לטפל בנפרד ב-Developer ID / notarization ובגרסת ההפצה.
