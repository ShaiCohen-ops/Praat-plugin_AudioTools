{
    "patcher": {
        "fileversion": 1,
        "appversion": {
            "major": 9,
            "minor": 1,
            "revision": 0,
            "architecture": "x64",
            "modernui": 1
        },
        "classnamespace": "box",
        "rect": [
            34.0,
            77.0,
            1852.0,
            929.0
        ],
        "openinpresentation": 1,
        "boxes": [
            {
                "box": {
                    "fontsize": 10.0,
                    "id": "obj-292",
                    "maxclass": "number",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        471.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        471.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_random_seed[4]"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-290",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        441.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        441.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_stereo_decorrelation[2]"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-288",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        411.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        411.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_density_variation[2]"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-286",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        381.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        381.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_position_jitter[2]"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-284",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        351.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        351.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_varispeed_scatter_semitones[2]"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-282",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        321.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        321.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_synthesis_overlap[2]"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-280",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        291.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        291.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_output_duration_sec[2]"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-278",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        261.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        261.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_randomness[2]"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "id": "obj-276",
                    "maxclass": "number",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        201.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        201.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_number_of_states[2]"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-274",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        171.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        171.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_analysis_overlap[2]"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-272",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        141.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        141.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_grain_size_ms[2]"
                }
            },
            {
                "box": {
                    "fontface": 1,
                    "fontsize": 18.918545454545455,
                    "id": "obj-297",
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [
                        1068.0,
                        729.0,
                        252.0,
                        28.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        617.0,
                        789.0,
                        100.0,
                        28.0
                    ],
                    "text": "Reference"
                }
            },
            {
                "box": {
                    "annotation": "Documentation",
                    "handoff": "",
                    "id": "obj-299",
                    "maxclass": "ubutton",
                    "numinlets": 1,
                    "numoutlets": 4,
                    "outlettype": [
                        "bang",
                        "bang",
                        "",
                        "int"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1039.0,
                        726.0,
                        154.0,
                        25.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        592.0,
                        790.0,
                        154.0,
                        25.0
                    ]
                }
            },
            {
                "box": {
                    "id": "obj-295",
                    "linecount": 2,
                    "maxclass": "message",
                    "numinlets": 2,
                    "numoutlets": 1,
                    "outlettype": [
                        ""
                    ],
                    "patching_rect": [
                        1029.0,
                        768.0,
                        243.0,
                        36.0
                    ],
                    "text": ";\r\nmax showdoc AudioTools.praat~.maxref.xml"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "id": "obj-618",
                    "maxclass": "number",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        501.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        501.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_random_seed[3]"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-616",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        471.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        471.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_fade_duration_s[1]"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "id": "obj-614",
                    "maxclass": "number",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        381.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        381.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_output_length_chunks"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-612",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        231.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        231.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_temperature"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-610",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        201.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        201.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_min_chunk_duration_s"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-608",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        171.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        171.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_chunk_duration_s"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "id": "obj-334",
                    "maxclass": "number",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        471.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        471.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_random_seed[2]"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-332",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        441.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        441.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_stereo_decorrelation[1]"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-330",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        411.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        411.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_density_variation[1]"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-328",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        381.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        381.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_position_jitter[1]"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-326",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        351.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        351.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_varispeed_scatter_semitones[1]"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-324",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        321.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        321.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_synthesis_overlap[1]"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-322",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        291.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        291.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_output_duration_sec[1]"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-320",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        261.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        261.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_randomness[1]"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "id": "obj-318",
                    "maxclass": "number",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        201.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        201.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_number_of_states[1]"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-316",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        171.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        171.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_analysis_overlap[1]"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-314",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        141.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        141.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_grain_size_ms[1]"
                }
            },
            {
                "box": {
                    "fontsize": 17.61381818181818,
                    "id": "obj-298",
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [
                        234.0,
                        755.0,
                        218.0,
                        27.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        81.0,
                        756.0,
                        138.0,
                        27.0
                    ],
                    "text": "Send To Ableton"
                }
            },
            {
                "box": {
                    "id": "obj-296",
                    "maxclass": "toggle",
                    "numinlets": 1,
                    "numoutlets": 1,
                    "outlettype": [
                        "int"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        396.0,
                        252.0,
                        55.0,
                        55.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        13.0,
                        742.0,
                        55.0,
                        55.0
                    ],
                    "prototypename": "tiny",
                    "style": "MP-M4L"
                }
            },
            {
                "box": {
                    "id": "obj-294",
                    "maxclass": "newobj",
                    "numinlets": 2,
                    "numoutlets": 1,
                    "outlettype": [
                        ""
                    ],
                    "patching_rect": [
                        409.0,
                        285.0,
                        32.0,
                        22.0
                    ],
                    "text": "gate"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-223",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        977.0,
                        327.0,
                        62.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        937.0,
                        141.0,
                        62.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_grain_size_ms"
                }
            },
            {
                "box": {
                    "id": "obj-247",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [
                        409.0,
                        320.0,
                        138.0,
                        22.0
                    ],
                    "text": "udpsend 127.0.0.1 7474"
                }
            },
            {
                "box": {
                    "id": "obj-246",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 1,
                    "outlettype": [
                        ""
                    ],
                    "patching_rect": [
                        422.0,
                        253.0,
                        89.0,
                        22.0
                    ],
                    "text": "prepend import"
                }
            },
            {
                "box": {
                    "id": "obj-245",
                    "maxclass": "newobj",
                    "numinlets": 2,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        ""
                    ],
                    "patching_rect": [
                        422.0,
                        218.0,
                        69.0,
                        22.0
                    ],
                    "text": "route audio"
                }
            },
            {
                "box": {
                    "id": "obj-244",
                    "maxclass": "newobj",
                    "numinlets": 2,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        ""
                    ],
                    "patching_rect": [
                        422.0,
                        184.0,
                        73.0,
                        22.0
                    ],
                    "text": "route output"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "id": "obj-243",
                    "maxclass": "number",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        -1000.0,
                        -1000.0,
                        70.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        -1000.0,
                        -1000.0,
                        70.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_random_seed[1]"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-241",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        -1000.0,
                        -1000.0,
                        70.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        -1000.0,
                        -1000.0,
                        70.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_stereo_decorrelation"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-239",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        -1000.0,
                        -1000.0,
                        70.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        -1000.0,
                        -1000.0,
                        70.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_density_variation"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-237",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        -1000.0,
                        -1000.0,
                        70.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        -1000.0,
                        -1000.0,
                        70.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_position_jitter"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-235",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        -1000.0,
                        -1000.0,
                        70.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        -1000.0,
                        -1000.0,
                        70.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_varispeed_scatter_semitones"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-233",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        -1000.0,
                        -1000.0,
                        70.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        -1000.0,
                        -1000.0,
                        70.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_synthesis_overlap"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-231",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        -1000.0,
                        -1000.0,
                        70.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        -1000.0,
                        -1000.0,
                        70.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_output_duration_sec"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-229",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        -1000.0,
                        -1000.0,
                        70.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        -1000.0,
                        -1000.0,
                        70.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_randomness"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "id": "obj-227",
                    "maxclass": "number",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        -1000.0,
                        -1000.0,
                        70.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        -1000.0,
                        -1000.0,
                        70.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_number_of_states"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-225",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        -1000.0,
                        -1000.0,
                        70.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        -1000.0,
                        -1000.0,
                        70.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_analysis_overlap"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-1561",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        651.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        651.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_wet_dry_percent[1]"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-1559",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        621.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        621.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_listener_z"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-1557",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        591.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        591.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_listener_y"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-1555",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        561.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        561.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_listener_x"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-1553",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        531.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        531.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_source_z"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-1551",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        501.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        501.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_source_y"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-1549",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        471.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        471.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_source_x"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-1547",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        441.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        441.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_diffuse_level"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-1545",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        411.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        411.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_reverb_tail_s"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-1543",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        381.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        381.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_speed_of_sound"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-1541",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        351.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        351.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_air_absorption"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-1539",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        321.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        321.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_wall_absorption"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-1537",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        291.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        291.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_listener_radius_m"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-1535",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        261.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        261.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_max_reflections"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-1533",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        231.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        231.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_number_of_rays"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-1531",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        201.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        201.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_room_depth_m"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-1529",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        171.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        171.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_room_height_m"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-1527",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        1190.0,
                        141.0,
                        63.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1190.0,
                        141.0,
                        63.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_room_width_m"
                }
            },
            {
                "box": {
                    "id": "obj-1079",
                    "linecount": 2,
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [
                        239.0,
                        187.0,
                        150.0,
                        34.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        257.0,
                        184.0,
                        270.0,
                        20.0
                    ],
                    "text": "Department of Music, Bar-Ilan University, Israel"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-699",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        576.0,
                        531.0,
                        62.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_fade_out_s"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-697",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        576.0,
                        501.0,
                        62.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_fade_duration_s"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-695",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        576.0,
                        441.0,
                        62.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_amplitude_scaling"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-693",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        576.0,
                        381.0,
                        62.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_spatial_drift"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-691",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        576.0,
                        351.0,
                        62.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_spatial_step_size"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-689",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        576.0,
                        261.0,
                        62.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_time_drift"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-687",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        576.0,
                        231.0,
                        62.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_time_step_size_s"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-685",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        576.0,
                        201.0,
                        62.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_density_grains_per_sec"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-683",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        576.0,
                        171.0,
                        62.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_output_duration_s"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-681",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        576.0,
                        141.0,
                        62.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_grain_duration_s"
                }
            },
            {
                "box": {
                    "fontface": 1,
                    "fontsize": 18.918545454545455,
                    "id": "obj-305",
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [
                        124.0,
                        742.0,
                        252.0,
                        28.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        593.0,
                        765.0,
                        152.0,
                        28.0
                    ],
                    "text": "Documentation"
                }
            },
            {
                "box": {
                    "annotation": "Documentation",
                    "handoff": "",
                    "id": "obj-307",
                    "maxclass": "ubutton",
                    "numinlets": 1,
                    "numoutlets": 4,
                    "outlettype": [
                        "bang",
                        "bang",
                        "",
                        "int"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        95.0,
                        739.0,
                        154.0,
                        25.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        592.0,
                        768.0,
                        154.0,
                        25.0
                    ]
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-7961",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        576.0,
                        351.0,
                        62.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_wet_dry_percent"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-7959",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        576.0,
                        291.0,
                        62.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_decay_time"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-7957",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        576.0,
                        261.0,
                        62.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_ir_duration"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "id": "obj-7955",
                    "maxclass": "number",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        576.0,
                        231.0,
                        62.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_random_seed"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "format": 6,
                    "id": "obj-7953",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        576.0,
                        171.0,
                        62.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_ca_width"
                }
            },
            {
                "box": {
                    "fontsize": 10.0,
                    "id": "obj-7951",
                    "maxclass": "number",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        576.0,
                        141.0,
                        62.0,
                        20.0
                    ],
                    "varname": "__AudioTools_num_rule"
                }
            },
            {
                "box": {
                    "id": "obj-7721",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 1,
                    "outlettype": [
                        ""
                    ],
                    "patcher": {
                        "fileversion": 1,
                        "appversion": {
                            "major": 9,
                            "minor": 1,
                            "revision": 0,
                            "architecture": "x64",
                            "modernui": 1
                        },
                        "classnamespace": "box",
                        "rect": [
                            0.0,
                            0.0,
                            1000.0,
                            780.0
                        ],
                        "boxes": [
                            {
                                "box": {
                                    "id": "obj-7712",
                                    "maxclass": "newobj",
                                    "numinlets": 13,
                                    "numoutlets": 13,
                                    "outlettype": [
                                        "bang",
                                        "bang",
                                        "bang",
                                        "bang",
                                        "bang",
                                        "bang",
                                        "bang",
                                        "bang",
                                        "bang",
                                        "bang",
                                        "bang",
                                        "bang",
                                        ""
                                    ],
                                    "patching_rect": [
                                        206.0,
                                        100.0,
                                        156.0,
                                        22.0
                                    ],
                                    "text": "sel 0 1 2 3 4 5 6 7 8 9 10 11"
                                }
                            },
                            {
                                "box": {
                                    "id": "obj-7708",
                                    "maxclass": "message",
                                    "numinlets": 2,
                                    "numoutlets": 1,
                                    "outlettype": [
                                        ""
                                    ],
                                    "patching_rect": [
                                        402.0,
                                        158.0,
                                        29.5,
                                        22.0
                                    ],
                                    "text": "507"
                                }
                            },
                            {
                                "box": {
                                    "id": "obj-7569",
                                    "maxclass": "message",
                                    "numinlets": 2,
                                    "numoutlets": 1,
                                    "outlettype": [
                                        ""
                                    ],
                                    "patching_rect": [
                                        377.0,
                                        158.0,
                                        29.5,
                                        22.0
                                    ],
                                    "text": "479"
                                }
                            },
                            {
                                "box": {
                                    "id": "obj-7300",
                                    "maxclass": "message",
                                    "numinlets": 2,
                                    "numoutlets": 1,
                                    "outlettype": [
                                        ""
                                    ],
                                    "patching_rect": [
                                        345.0,
                                        158.0,
                                        29.5,
                                        22.0
                                    ],
                                    "text": "438"
                                }
                            },
                            {
                                "box": {
                                    "id": "obj-7004",
                                    "maxclass": "message",
                                    "numinlets": 2,
                                    "numoutlets": 1,
                                    "outlettype": [
                                        ""
                                    ],
                                    "patching_rect": [
                                        314.0,
                                        158.0,
                                        29.5,
                                        22.0
                                    ],
                                    "text": "405"
                                }
                            },
                            {
                                "box": {
                                    "id": "obj-6818",
                                    "maxclass": "message",
                                    "numinlets": 2,
                                    "numoutlets": 1,
                                    "outlettype": [
                                        ""
                                    ],
                                    "patching_rect": [
                                        280.0,
                                        158.0,
                                        29.5,
                                        22.0
                                    ],
                                    "text": "269"
                                }
                            },
                            {
                                "box": {
                                    "id": "obj-6388",
                                    "maxclass": "message",
                                    "numinlets": 2,
                                    "numoutlets": 1,
                                    "outlettype": [
                                        ""
                                    ],
                                    "patching_rect": [
                                        248.0,
                                        158.0,
                                        29.5,
                                        22.0
                                    ],
                                    "text": "236"
                                }
                            },
                            {
                                "box": {
                                    "id": "obj-5972",
                                    "maxclass": "message",
                                    "numinlets": 2,
                                    "numoutlets": 1,
                                    "outlettype": [
                                        ""
                                    ],
                                    "patching_rect": [
                                        216.0,
                                        158.0,
                                        29.5,
                                        22.0
                                    ],
                                    "text": "212"
                                }
                            },
                            {
                                "box": {
                                    "id": "obj-5285",
                                    "maxclass": "message",
                                    "numinlets": 2,
                                    "numoutlets": 1,
                                    "outlettype": [
                                        ""
                                    ],
                                    "patching_rect": [
                                        185.0,
                                        158.0,
                                        29.5,
                                        22.0
                                    ],
                                    "text": "155"
                                }
                            },
                            {
                                "box": {
                                    "id": "obj-4704",
                                    "maxclass": "message",
                                    "numinlets": 2,
                                    "numoutlets": 1,
                                    "outlettype": [
                                        ""
                                    ],
                                    "patching_rect": [
                                        153.0,
                                        158.0,
                                        29.5,
                                        22.0
                                    ],
                                    "text": "117"
                                }
                            },
                            {
                                "box": {
                                    "id": "obj-4360",
                                    "maxclass": "message",
                                    "numinlets": 2,
                                    "numoutlets": 1,
                                    "outlettype": [
                                        ""
                                    ],
                                    "patching_rect": [
                                        121.0,
                                        158.0,
                                        29.5,
                                        22.0
                                    ],
                                    "text": "94"
                                }
                            },
                            {
                                "box": {
                                    "id": "obj-4105",
                                    "maxclass": "message",
                                    "numinlets": 2,
                                    "numoutlets": 1,
                                    "outlettype": [
                                        ""
                                    ],
                                    "patching_rect": [
                                        81.0,
                                        158.0,
                                        29.5,
                                        22.0
                                    ],
                                    "text": "77"
                                }
                            },
                            {
                                "box": {
                                    "id": "obj-3762",
                                    "maxclass": "message",
                                    "numinlets": 2,
                                    "numoutlets": 1,
                                    "outlettype": [
                                        ""
                                    ],
                                    "patching_rect": [
                                        50.0,
                                        158.0,
                                        29.5,
                                        22.0
                                    ],
                                    "text": "1"
                                }
                            },
                            {
                                "box": {
                                    "comment": "",
                                    "id": "obj-7719",
                                    "index": 1,
                                    "maxclass": "inlet",
                                    "numinlets": 0,
                                    "numoutlets": 1,
                                    "outlettype": [
                                        "int"
                                    ],
                                    "patching_rect": [
                                        206.0,
                                        40.0,
                                        30.0,
                                        30.0
                                    ]
                                }
                            },
                            {
                                "box": {
                                    "comment": "",
                                    "id": "obj-7720",
                                    "index": 1,
                                    "maxclass": "outlet",
                                    "numinlets": 1,
                                    "numoutlets": 0,
                                    "patching_rect": [
                                        225.0,
                                        240.0,
                                        30.0,
                                        30.0
                                    ]
                                }
                            }
                        ],
                        "lines": [
                            {
                                "patchline": {
                                    "destination": [
                                        "obj-7720",
                                        0
                                    ],
                                    "source": [
                                        "obj-3762",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "destination": [
                                        "obj-7720",
                                        0
                                    ],
                                    "source": [
                                        "obj-4105",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "destination": [
                                        "obj-7720",
                                        0
                                    ],
                                    "source": [
                                        "obj-4360",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "destination": [
                                        "obj-7720",
                                        0
                                    ],
                                    "source": [
                                        "obj-4704",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "destination": [
                                        "obj-7720",
                                        0
                                    ],
                                    "source": [
                                        "obj-5285",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "destination": [
                                        "obj-7720",
                                        0
                                    ],
                                    "source": [
                                        "obj-5972",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "destination": [
                                        "obj-7720",
                                        0
                                    ],
                                    "source": [
                                        "obj-6388",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "destination": [
                                        "obj-7720",
                                        0
                                    ],
                                    "source": [
                                        "obj-6818",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "destination": [
                                        "obj-7720",
                                        0
                                    ],
                                    "source": [
                                        "obj-7004",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "destination": [
                                        "obj-7720",
                                        0
                                    ],
                                    "source": [
                                        "obj-7300",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "destination": [
                                        "obj-7720",
                                        0
                                    ],
                                    "source": [
                                        "obj-7569",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "destination": [
                                        "obj-7720",
                                        0
                                    ],
                                    "source": [
                                        "obj-7708",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "destination": [
                                        "obj-3762",
                                        0
                                    ],
                                    "source": [
                                        "obj-7712",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "destination": [
                                        "obj-4105",
                                        0
                                    ],
                                    "source": [
                                        "obj-7712",
                                        1
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "destination": [
                                        "obj-4360",
                                        0
                                    ],
                                    "source": [
                                        "obj-7712",
                                        2
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "destination": [
                                        "obj-4704",
                                        0
                                    ],
                                    "source": [
                                        "obj-7712",
                                        3
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "destination": [
                                        "obj-5285",
                                        0
                                    ],
                                    "source": [
                                        "obj-7712",
                                        4
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "destination": [
                                        "obj-5972",
                                        0
                                    ],
                                    "source": [
                                        "obj-7712",
                                        5
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "destination": [
                                        "obj-6388",
                                        0
                                    ],
                                    "source": [
                                        "obj-7712",
                                        6
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "destination": [
                                        "obj-6818",
                                        0
                                    ],
                                    "source": [
                                        "obj-7712",
                                        7
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "destination": [
                                        "obj-7004",
                                        0
                                    ],
                                    "source": [
                                        "obj-7712",
                                        8
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "destination": [
                                        "obj-7300",
                                        0
                                    ],
                                    "source": [
                                        "obj-7712",
                                        9
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "destination": [
                                        "obj-7569",
                                        0
                                    ],
                                    "source": [
                                        "obj-7712",
                                        10
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "destination": [
                                        "obj-7708",
                                        0
                                    ],
                                    "source": [
                                        "obj-7712",
                                        11
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "destination": [
                                        "obj-7712",
                                        0
                                    ],
                                    "source": [
                                        "obj-7719",
                                        0
                                    ]
                                }
                            }
                        ]
                    },
                    "patching_rect": [
                        13.0,
                        97.0,
                        19.0,
                        22.0
                    ],
                    "text": "p"
                }
            },
            {
                "box": {
                    "id": "obj-7718",
                    "maxclass": "number",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        13.0,
                        43.0,
                        50.0,
                        22.0
                    ]
                }
            },
            {
                "box": {
                    "id": "obj-7711",
                    "items": [
                        "AI",
                        "&",
                        "Adaptive",
                        ",",
                        "Distortion",
                        ",",
                        "Dynamics",
                        "&",
                        "Envelope",
                        ",",
                        "Filter",
                        "&",
                        "Color",
                        ",",
                        "Generative",
                        "&",
                        "Synthesis",
                        ",",
                        "Modulation",
                        ",",
                        "Pitch",
                        ",",
                        "Hybrid",
                        "Systems",
                        ",",
                        "Reverb",
                        ",",
                        "Spatial",
                        "&",
                        "Surround",
                        ",",
                        "Spectral",
                        ",",
                        "Time",
                        "&",
                        "Granular"
                    ],
                    "maxclass": "umenu",
                    "numinlets": 1,
                    "numoutlets": 3,
                    "outlettype": [
                        "int",
                        "",
                        ""
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        13.0,
                        73.0,
                        181.0,
                        22.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        114.0,
                        263.5,
                        181.0,
                        22.0
                    ]
                }
            },
            {
                "box": {
                    "bgcolor": [
                        0.144131996740917,
                        0.144131949846078,
                        0.144131962041943,
                        1.0
                    ],
                    "buffername": "myInput",
                    "gridcolor": [
                        0.349019607843137,
                        0.349019607843137,
                        0.349019607843137,
                        0.0
                    ],
                    "id": "obj-51",
                    "ignoreclick": 1,
                    "labels": 0,
                    "maxclass": "waveform~",
                    "numinlets": 5,
                    "numoutlets": 6,
                    "outlettype": [
                        "float",
                        "float",
                        "float",
                        "float",
                        "list",
                        ""
                    ],
                    "patching_rect": [
                        562.0,
                        565.0,
                        399.0,
                        101.17809458428314
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        13.0,
                        499.0,
                        731.5,
                        101.0
                    ],
                    "reflectioncolor": [
                        1.0,
                        0.725490196078431,
                        0.003921568627451,
                        1.0
                    ],
                    "ruler": 0,
                    "saved_attribute_attributes": {
                        "bgcolor": {
                            "expression": "themecolor.live_contrast_frame"
                        },
                        "reflectioncolor": {
                            "expression": "themecolor.live_display_line_one"
                        },
                        "waveformcolor": {
                            "expression": "themecolor.live_display_line_one"
                        }
                    },
                    "selectioncolor": [
                        0.929411764705882,
                        0.929411764705882,
                        0.352941176470588,
                        0.0
                    ],
                    "vticks": 0,
                    "waveformcolor": [
                        1.0,
                        0.725490196078431,
                        0.003921568627451,
                        1.0
                    ]
                }
            },
            {
                "box": {
                    "bgcolor": [
                        0.144131996740917,
                        0.144131949846078,
                        0.144131962041943,
                        1.0
                    ],
                    "buffername": "myOutput",
                    "gridcolor": [
                        0.349019607843137,
                        0.349019607843137,
                        0.349019607843137,
                        0.0
                    ],
                    "id": "obj-49",
                    "ignoreclick": 1,
                    "labels": 0,
                    "maxclass": "waveform~",
                    "numinlets": 5,
                    "numoutlets": 6,
                    "outlettype": [
                        "float",
                        "float",
                        "float",
                        "float",
                        "list",
                        ""
                    ],
                    "patching_rect": [
                        562.0,
                        677.0,
                        399.0,
                        101.17809458428314
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        13.0,
                        632.0,
                        732.0,
                        101.0
                    ],
                    "reflectioncolor": [
                        1.0,
                        0.725490196078431,
                        0.003921568627451,
                        1.0
                    ],
                    "ruler": 0,
                    "saved_attribute_attributes": {
                        "bgcolor": {
                            "expression": "themecolor.live_contrast_frame"
                        },
                        "reflectioncolor": {
                            "expression": "themecolor.live_display_line_one"
                        },
                        "waveformcolor": {
                            "expression": "themecolor.live_display_line_one"
                        }
                    },
                    "selectioncolor": [
                        0.929411764705882,
                        0.929411764705882,
                        0.352941176470588,
                        0.0
                    ],
                    "vticks": 0,
                    "waveformcolor": [
                        1.0,
                        0.725490196078431,
                        0.003921568627451,
                        1.0
                    ]
                }
            },
            {
                "box": {
                    "fontsize": 12.0,
                    "id": "obj-36",
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [
                        130.0,
                        148.0,
                        157.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        579.0,
                        271.0,
                        79.0,
                        20.0
                    ],
                    "text": "Visualization "
                }
            },
            {
                "box": {
                    "id": "obj-32",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 3,
                    "outlettype": [
                        "jit_matrix",
                        "bang",
                        ""
                    ],
                    "patching_rect": [
                        325.0,
                        565.0,
                        229.0,
                        22.0
                    ],
                    "text": "jit.world @enable 1 @erase_color 1 1 1 1"
                }
            },
            {
                "box": {
                    "filename": "AudioTools.praat.info.js",
                    "id": "obj-30",
                    "maxclass": "jsui",
                    "numinlets": 1,
                    "numoutlets": 1,
                    "outlettype": [
                        ""
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        432.0,
                        395.0,
                        149.0,
                        108.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        1280.0,
                        37.0,
                        519.0,
                        814.0
                    ]
                }
            },
            {
                "box": {
                    "fontsize": 12.0,
                    "id": "obj-48",
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [
                        134.0,
                        171.0,
                        157.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        328.0,
                        271.0,
                        40.0,
                        20.0
                    ],
                    "text": "Praat"
                }
            },
            {
                "box": {
                    "fontsize": 12.0,
                    "id": "obj-46",
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [
                        43.0,
                        233.0,
                        157.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        473.0,
                        271.0,
                        40.0,
                        20.0
                    ],
                    "text": "Buffer"
                }
            },
            {
                "box": {
                    "fontsize": 12.0,
                    "id": "obj-45",
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [
                        120.5,
                        125.5,
                        154.0,
                        20.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        22.0,
                        231.0,
                        84.0,
                        20.0
                    ],
                    "text": "Choose Script"
                }
            },
            {
                "box": {
                    "id": "obj-50",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 1,
                    "outlettype": [
                        "jit_matrix"
                    ],
                    "patcher": {
                        "fileversion": 1,
                        "appversion": {
                            "major": 9,
                            "minor": 1,
                            "revision": 0,
                            "architecture": "x64",
                            "modernui": 1
                        },
                        "classnamespace": "box",
                        "rect": [
                            59.0,
                            107.0,
                            1000.0,
                            780.0
                        ],
                        "boxes": [
                            {
                                "box": {
                                    "id": "obj-46",
                                    "maxclass": "newobj",
                                    "numinlets": 1,
                                    "numoutlets": 1,
                                    "outlettype": [
                                        ""
                                    ],
                                    "patching_rect": [
                                        179.0,
                                        137.0,
                                        70.0,
                                        22.0
                                    ],
                                    "text": "loadmess 1"
                                }
                            },
                            {
                                "box": {
                                    "id": "obj-45",
                                    "maxclass": "newobj",
                                    "numinlets": 2,
                                    "numoutlets": 1,
                                    "outlettype": [
                                        "bang"
                                    ],
                                    "patching_rect": [
                                        179.0,
                                        170.0,
                                        63.0,
                                        22.0
                                    ],
                                    "text": "qmetro 33"
                                }
                            },
                            {
                                "box": {
                                    "id": "obj-32",
                                    "maxclass": "newobj",
                                    "numinlets": 1,
                                    "numoutlets": 2,
                                    "outlettype": [
                                        "jit_matrix",
                                        ""
                                    ],
                                    "patching_rect": [
                                        50.0,
                                        209.0,
                                        165.0,
                                        22.0
                                    ],
                                    "text": "jit.matrix 4 char 1 1 @adapt 1"
                                }
                            },
                            {
                                "box": {
                                    "id": "obj-30",
                                    "maxclass": "newobj",
                                    "numinlets": 1,
                                    "numoutlets": 1,
                                    "outlettype": [
                                        ""
                                    ],
                                    "patching_rect": [
                                        50.0,
                                        170.0,
                                        121.0,
                                        22.0
                                    ],
                                    "text": "prepend importmovie"
                                }
                            },
                            {
                                "box": {
                                    "id": "obj-29",
                                    "maxclass": "newobj",
                                    "numinlets": 2,
                                    "numoutlets": 2,
                                    "outlettype": [
                                        "",
                                        ""
                                    ],
                                    "patching_rect": [
                                        50.0,
                                        137.0,
                                        72.0,
                                        22.0
                                    ],
                                    "text": "route image"
                                }
                            },
                            {
                                "box": {
                                    "id": "obj-15",
                                    "maxclass": "newobj",
                                    "numinlets": 2,
                                    "numoutlets": 2,
                                    "outlettype": [
                                        "",
                                        ""
                                    ],
                                    "patching_rect": [
                                        50.0,
                                        100.0,
                                        73.0,
                                        22.0
                                    ],
                                    "text": "route output"
                                }
                            },
                            {
                                "box": {
                                    "comment": "",
                                    "id": "obj-48",
                                    "index": 1,
                                    "maxclass": "inlet",
                                    "numinlets": 0,
                                    "numoutlets": 1,
                                    "outlettype": [
                                        ""
                                    ],
                                    "patching_rect": [
                                        50.0,
                                        40.0,
                                        30.0,
                                        30.0
                                    ]
                                }
                            },
                            {
                                "box": {
                                    "comment": "",
                                    "id": "obj-49",
                                    "index": 1,
                                    "maxclass": "outlet",
                                    "numinlets": 1,
                                    "numoutlets": 0,
                                    "patching_rect": [
                                        50.0,
                                        291.0,
                                        30.0,
                                        30.0
                                    ]
                                }
                            }
                        ],
                        "lines": [
                            {
                                "patchline": {
                                    "destination": [
                                        "obj-29",
                                        0
                                    ],
                                    "source": [
                                        "obj-15",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "destination": [
                                        "obj-30",
                                        0
                                    ],
                                    "source": [
                                        "obj-29",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "destination": [
                                        "obj-32",
                                        0
                                    ],
                                    "source": [
                                        "obj-30",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "destination": [
                                        "obj-49",
                                        0
                                    ],
                                    "source": [
                                        "obj-32",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "destination": [
                                        "obj-32",
                                        0
                                    ],
                                    "source": [
                                        "obj-45",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "destination": [
                                        "obj-45",
                                        0
                                    ],
                                    "source": [
                                        "obj-46",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "destination": [
                                        "obj-15",
                                        0
                                    ],
                                    "source": [
                                        "obj-48",
                                        0
                                    ]
                                }
                            }
                        ]
                    },
                    "patching_rect": [
                        337.0,
                        357.0,
                        45.0,
                        22.0
                    ],
                    "text": "p draw"
                }
            },
            {
                "box": {
                    "filename": "AudioTools.praat.ui.js",
                    "id": "obj-39",
                    "maxclass": "jsui",
                    "numinlets": 1,
                    "numoutlets": 1,
                    "outlettype": [
                        ""
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        805.0,
                        223.0,
                        229.0,
                        208.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        765.0,
                        37.0,
                        502.0,
                        814.0
                    ]
                }
            },
            {
                "box": {
                    "id": "obj-18",
                    "maxclass": "meter~",
                    "numinlets": 1,
                    "numoutlets": 1,
                    "outlettype": [
                        "float"
                    ],
                    "patching_rect": [
                        13.0,
                        400.0,
                        93.0,
                        171.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        13.0,
                        334.0,
                        732.0,
                        140.0
                    ]
                }
            },
            {
                "box": {
                    "hidden": 1,
                    "id": "obj-10",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 1,
                    "outlettype": [
                        ""
                    ],
                    "patching_rect": [
                        268.0,
                        438.0,
                        80.0,
                        22.0
                    ],
                    "text": "loadmess 0.8"
                }
            },
            {
                "box": {
                    "id": "obj-43",
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [
                        180.0,
                        379.0,
                        35.0,
                        20.0
                    ],
                    "text": "stop"
                }
            },
            {
                "box": {
                    "id": "obj-41",
                    "maxclass": "message",
                    "numinlets": 2,
                    "numoutlets": 1,
                    "outlettype": [
                        ""
                    ],
                    "patching_rect": [
                        183.0,
                        401.0,
                        29.5,
                        22.0
                    ],
                    "text": "0"
                }
            },
            {
                "box": {
                    "id": "obj-35",
                    "maxclass": "live.dial",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "float"
                    ],
                    "parameter_enable": 1,
                    "patching_rect": [
                        241.0,
                        462.0,
                        47.0,
                        48.0
                    ],
                    "saved_attribute_attributes": {
                        "valueof": {
                            "parameter_initial": [
                                -70
                            ],
                            "parameter_initial_enable": 1,
                            "parameter_longname": "Gain",
                            "parameter_mmax": 1.0,
                            "parameter_modmode": 0,
                            "parameter_shortname": "Gain",
                            "parameter_type": 0,
                            "parameter_units": "dB",
                            "parameter_unitstyle": 9
                        }
                    },
                    "varname": "live.dial[5]"
                }
            },
            {
                "box": {
                    "fontsize": 18.0,
                    "id": "obj-56",
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [
                        13.0,
                        122.0,
                        108.0,
                        27.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        338.0,
                        154.0,
                        108.0,
                        27.0
                    ],
                    "text": "Shai Cohen "
                }
            },
            {
                "box": {
                    "bgcolor": [
                        0.866667,
                        0.866667,
                        0.866667,
                        0.0
                    ],
                    "bgfillcolor_angle": 270.0,
                    "bgfillcolor_autogradient": 0.79,
                    "bgfillcolor_color": [
                        0.228311182788346,
                        0.228311120731904,
                        0.228311136948243,
                        1
                    ],
                    "bgfillcolor_color1": [
                        0.866667,
                        0.866667,
                        0.866667,
                        0.0
                    ],
                    "bgfillcolor_color2": [
                        0.07451,
                        0.027451,
                        1.0,
                        1.0
                    ],
                    "bgfillcolor_proportion": 0.39,
                    "bgfillcolor_type": "gradient",
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "gradient": 0,
                    "id": "obj-54",
                    "maxclass": "message",
                    "numinlets": 2,
                    "numoutlets": 1,
                    "outlettype": [
                        ""
                    ],
                    "patching_rect": [
                        96.0,
                        775.0,
                        252.0,
                        22.0
                    ],
                    "text": "https://mashav.com/sha/Praat%20AudioTools/",
                    "textcolor": [
                        0.0,
                        0.0,
                        0.0,
                        1.0
                    ]
                }
            },
            {
                "box": {
                    "hidden": 1,
                    "id": "obj-47",
                    "linecount": 2,
                    "maxclass": "message",
                    "numinlets": 2,
                    "numoutlets": 1,
                    "outlettype": [
                        ""
                    ],
                    "patching_rect": [
                        96.0,
                        816.0,
                        129.0,
                        36.0
                    ],
                    "text": ";\r\nmax launchbrowser $1"
                }
            },
            {
                "box": {
                    "fontsize": 18.898859142938228,
                    "id": "obj-42",
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [
                        50.0,
                        621.0,
                        49.0,
                        28.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        81.0,
                        816.5,
                        49.0,
                        28.0
                    ],
                    "text": "input"
                }
            },
            {
                "box": {
                    "checkedcolor": [
                        0.192156862745098,
                        0.815686274509804,
                        0.643137254901961,
                        1.0
                    ],
                    "id": "obj-40",
                    "maxclass": "toggle",
                    "numinlets": 1,
                    "numoutlets": 1,
                    "outlettype": [
                        "int"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        18.0,
                        619.0,
                        24.0,
                        24.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        13.0,
                        803.0,
                        55.0,
                        55.0
                    ]
                }
            },
            {
                "box": {
                    "id": "obj-38",
                    "maxclass": "newobj",
                    "numinlets": 2,
                    "numoutlets": 0,
                    "patching_rect": [
                        18.0,
                        696.0,
                        57.0,
                        22.0
                    ],
                    "text": "dac~"
                }
            },
            {
                "box": {
                    "id": "obj-37",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "signal",
                        "bang"
                    ],
                    "patching_rect": [
                        18.0,
                        659.0,
                        84.0,
                        22.0
                    ],
                    "text": "play~ myInput"
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 18.4868154158215,
                    "id": "obj-86",
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [
                        356.0,
                        85.0,
                        583.0,
                        28.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        85.0,
                        124.0,
                        614.0,
                        28.0
                    ],
                    "saved_attribute_attributes": {
                        "textcolor": {
                            "expression": "themecolor.theme_textcolor"
                        }
                    },
                    "text": "An Offline Analysis–Resynthesis Toolkit  for Experimental Composition"
                }
            },
            {
                "box": {
                    "fontface": 1,
                    "fontname": "Arial",
                    "fontsize": 68.2962651120731,
                    "id": "obj-34",
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [
                        356.0,
                        10.0,
                        605.0,
                        85.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        85.0,
                        37.0,
                        614.0,
                        85.0
                    ],
                    "saved_attribute_attributes": {
                        "textcolor": {
                            "expression": "themecolor.live_active_automation"
                        }
                    },
                    "text": "AudioTools.praat~",
                    "textcolor": [
                        1.0,
                        0.4,
                        0.3,
                        1.0
                    ]
                }
            },
            {
                "box": {
                    "id": "obj-28",
                    "linecount": 2,
                    "maxclass": "message",
                    "numinlets": 2,
                    "numoutlets": 1,
                    "outlettype": [
                        ""
                    ],
                    "patching_rect": [
                        151.0,
                        596.0,
                        123.0,
                        36.0
                    ],
                    "text": ";\r\nmax clearmaxwindow"
                }
            },
            {
                "box": {
                    "id": "obj-24",
                    "maxclass": "newobj",
                    "numinlets": 2,
                    "numoutlets": 1,
                    "outlettype": [
                        "multichannelsignal"
                    ],
                    "patching_rect": [
                        118.0,
                        513.0,
                        142.0,
                        22.0
                    ],
                    "text": "mc.*~ 0.5"
                }
            },
            {
                "box": {
                    "id": "obj-22",
                    "maxclass": "newobj",
                    "numinlets": 8,
                    "numoutlets": 1,
                    "outlettype": [
                        "multichannelsignal"
                    ],
                    "patching_rect": [
                        118.0,
                        479.0,
                        128.71428571428578,
                        22.0
                    ],
                    "text": "mc.pack~ 8"
                }
            },
            {
                "box": {
                    "id": "obj-31",
                    "maxclass": "message",
                    "numinlets": 2,
                    "numoutlets": 1,
                    "outlettype": [
                        ""
                    ],
                    "patching_rect": [
                        254.0,
                        652.0,
                        48.0,
                        22.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        493.0,
                        300.0,
                        48.0,
                        22.0
                    ],
                    "text": "replace"
                }
            },
            {
                "box": {
                    "id": "obj-27",
                    "maxclass": "message",
                    "numinlets": 2,
                    "numoutlets": 1,
                    "outlettype": [
                        ""
                    ],
                    "patching_rect": [
                        311.0,
                        269.0,
                        31.0,
                        22.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        411.0,
                        300.0,
                        31.0,
                        22.0
                    ],
                    "text": "stop"
                }
            },
            {
                "box": {
                    "id": "obj-25",
                    "maxclass": "message",
                    "numinlets": 2,
                    "numoutlets": 1,
                    "outlettype": [
                        ""
                    ],
                    "patching_rect": [
                        150.0,
                        401.0,
                        29.5,
                        22.0
                    ],
                    "text": "1"
                }
            },
            {
                "box": {
                    "id": "obj-23",
                    "maxclass": "button",
                    "numinlets": 1,
                    "numoutlets": 1,
                    "outlettype": [
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        150.0,
                        361.0,
                        24.0,
                        24.0
                    ]
                }
            },
            {
                "box": {
                    "id": "obj-14",
                    "maxclass": "message",
                    "numinlets": 2,
                    "numoutlets": 1,
                    "outlettype": [
                        ""
                    ],
                    "patching_rect": [
                        105.0,
                        614.0,
                        35.0,
                        22.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        452.0,
                        300.0,
                        35.0,
                        22.0
                    ],
                    "text": "clear"
                }
            },
            {
                "box": {
                    "fontface": 0,
                    "fontsize": 19.60481601731602,
                    "id": "obj-20",
                    "maxclass": "number",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        10.5,
                        148.0,
                        100.0,
                        31.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        22.0,
                        255.0,
                        84.0,
                        31.0
                    ],
                    "style": "MP-M4L",
                    "textcolor": [
                        0.192156862745098,
                        0.815686274509804,
                        0.643137254901961,
                        1.0
                    ]
                }
            },
            {
                "box": {
                    "id": "obj-17",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 1,
                    "outlettype": [
                        ""
                    ],
                    "patching_rect": [
                        149.0,
                        236.0,
                        85.0,
                        22.0
                    ],
                    "text": "prepend script"
                }
            },
            {
                "box": {
                    "autopopulate": 1,
                    "depth": 1,
                    "id": "obj-12",
                    "maxclass": "umenu",
                    "numinlets": 1,
                    "numoutlets": 3,
                    "outlettype": [
                        "int",
                        "",
                        ""
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        12.0,
                        200.0,
                        293.0,
                        22.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        15.0,
                        301.0,
                        239.0,
                        22.0
                    ]
                }
            },
            {
                "box": {
                    "id": "obj-11",
                    "maxclass": "toggle",
                    "numinlets": 1,
                    "numoutlets": 1,
                    "outlettype": [
                        "int"
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        118.0,
                        400.0,
                        24.0,
                        24.0
                    ]
                }
            },
            {
                "box": {
                    "id": "obj-8",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [
                        118.0,
                        549.0,
                        54.0,
                        22.0
                    ],
                    "text": "mc.dac~"
                }
            },
            {
                "box": {
                    "id": "obj-4",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 9,
                    "outlettype": [
                        "signal",
                        "signal",
                        "signal",
                        "signal",
                        "signal",
                        "signal",
                        "signal",
                        "signal",
                        "bang"
                    ],
                    "patching_rect": [
                        118.0,
                        438.0,
                        144.0,
                        22.0
                    ],
                    "text": "play~ myOutput 8"
                }
            },
            {
                "box": {
                    "id": "obj-9",
                    "maxclass": "message",
                    "numinlets": 2,
                    "numoutlets": 1,
                    "outlettype": [
                        ""
                    ],
                    "patching_rect": [
                        263.0,
                        269.0,
                        47.0,
                        22.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        355.0,
                        300.0,
                        47.0,
                        22.0
                    ],
                    "text": "receive"
                }
            },
            {
                "box": {
                    "id": "obj-6",
                    "maxclass": "message",
                    "numinlets": 2,
                    "numoutlets": 1,
                    "outlettype": [
                        ""
                    ],
                    "patching_rect": [
                        219.0,
                        269.0,
                        35.0,
                        22.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        311.0,
                        300.0,
                        35.0,
                        22.0
                    ],
                    "text": "send"
                }
            },
            {
                "box": {
                    "id": "obj-2",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "float",
                        "bang"
                    ],
                    "patching_rect": [
                        105.0,
                        652.0,
                        141.0,
                        22.0
                    ],
                    "text": "buffer~ myOutput 5000 8"
                }
            },
            {
                "box": {
                    "id": "obj-7",
                    "maxclass": "message",
                    "numinlets": 2,
                    "numoutlets": 1,
                    "outlettype": [
                        ""
                    ],
                    "patching_rect": [
                        174.0,
                        269.0,
                        35.0,
                        22.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        266.0,
                        300.0,
                        35.0,
                        22.0
                    ],
                    "text": "open"
                }
            },
            {
                "box": {
                    "id": "obj-3",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "float",
                        "bang"
                    ],
                    "patching_rect": [
                        106.0,
                        689.0,
                        205.0,
                        22.0
                    ],
                    "text": "buffer~ myInput drumLoop.aif 5000 2"
                }
            },
            {
                "box": {
                    "id": "obj-1",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 3,
                    "outlettype": [
                        "bang",
                        "bang",
                        ""
                    ],
                    "patching_rect": [
                        150.0,
                        327.0,
                        206.0,
                        22.0
                    ],
                    "text": "AudioTools.praat~ myInput myOutput"
                }
            },
            {
                "box": {
                    "attr": "visible",
                    "id": "obj-33",
                    "maxclass": "attrui",
                    "numinlets": 1,
                    "numoutlets": 1,
                    "outlettype": [
                        ""
                    ],
                    "parameter_enable": 0,
                    "patching_rect": [
                        325.0,
                        517.0,
                        150.0,
                        22.0
                    ],
                    "presentation": 1,
                    "presentation_rect": [
                        549.0,
                        300.0,
                        150.0,
                        22.0
                    ]
                }
            },
            {
                "box": {
                    "id": "obj-libscan-js",
                    "maxclass": "newobj",
                    "numinlets": 2,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        ""
                    ],
                    "patching_rect": [
                        10.0,
                        650.0,
                        190.0,
                        22.0
                    ],
                    "text": "js AudioTools.praat.library.js"
                }
            },
            {
                "box": {
                    "id": "obj-libscan-loadbang",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 1,
                    "outlettype": [
                        "bang"
                    ],
                    "patching_rect": [
                        10.0,
                        590.0,
                        60.0,
                        22.0
                    ],
                    "text": "loadbang"
                }
            },
            {
                "box": {
                    "id": "obj-libscan-deferlow",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 1,
                    "outlettype": [
                        ""
                    ],
                    "patching_rect": [
                        80.0,
                        590.0,
                        55.0,
                        22.0
                    ],
                    "text": "deferlow"
                }
            },
            {
                "box": {
                    "id": "obj-libscan-scan",
                    "maxclass": "message",
                    "numinlets": 2,
                    "numoutlets": 1,
                    "outlettype": [
                        ""
                    ],
                    "patching_rect": [
                        145.0,
                        590.0,
                        35.0,
                        22.0
                    ],
                    "text": "scan"
                }
            }
        ],
        "lines": [
            {
                "patchline": {
                    "destination": [
                        "obj-23",
                        0
                    ],
                    "source": [
                        "obj-1",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-244",
                        0
                    ],
                    "order": 2,
                    "source": [
                        "obj-1",
                        2
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-30",
                        0
                    ],
                    "order": 1,
                    "source": [
                        "obj-1",
                        2
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-39",
                        0
                    ],
                    "hidden": 1,
                    "order": 0,
                    "source": [
                        "obj-1",
                        2
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-50",
                        0
                    ],
                    "order": 3,
                    "source": [
                        "obj-1",
                        2
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-35",
                        0
                    ],
                    "hidden": 1,
                    "source": [
                        "obj-10",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-4",
                        0
                    ],
                    "source": [
                        "obj-11",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-2",
                        0
                    ],
                    "source": [
                        "obj-14",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-1",
                        0
                    ],
                    "source": [
                        "obj-17",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-12",
                        0
                    ],
                    "source": [
                        "obj-20",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-24",
                        0
                    ],
                    "source": [
                        "obj-22",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-25",
                        0
                    ],
                    "source": [
                        "obj-23",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-18",
                        0
                    ],
                    "hidden": 1,
                    "order": 1,
                    "source": [
                        "obj-24",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-8",
                        0
                    ],
                    "order": 0,
                    "source": [
                        "obj-24",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-245",
                        0
                    ],
                    "source": [
                        "obj-244",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-246",
                        0
                    ],
                    "source": [
                        "obj-245",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-294",
                        1
                    ],
                    "source": [
                        "obj-246",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-4",
                        0
                    ],
                    "source": [
                        "obj-25",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-1",
                        0
                    ],
                    "order": 1,
                    "source": [
                        "obj-27",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-41",
                        0
                    ],
                    "order": 0,
                    "source": [
                        "obj-27",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-247",
                        0
                    ],
                    "source": [
                        "obj-294",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-294",
                        0
                    ],
                    "source": [
                        "obj-296",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-295",
                        0
                    ],
                    "source": [
                        "obj-299",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-54",
                        0
                    ],
                    "source": [
                        "obj-307",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-3",
                        0
                    ],
                    "source": [
                        "obj-31",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-32",
                        0
                    ],
                    "source": [
                        "obj-33",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-24",
                        1
                    ],
                    "source": [
                        "obj-35",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-38",
                        1
                    ],
                    "order": 0,
                    "source": [
                        "obj-37",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-38",
                        0
                    ],
                    "order": 1,
                    "source": [
                        "obj-37",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-1",
                        0
                    ],
                    "hidden": 1,
                    "source": [
                        "obj-39",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-22",
                        7
                    ],
                    "source": [
                        "obj-4",
                        7
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-22",
                        6
                    ],
                    "source": [
                        "obj-4",
                        6
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-22",
                        5
                    ],
                    "source": [
                        "obj-4",
                        5
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-22",
                        4
                    ],
                    "source": [
                        "obj-4",
                        4
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-22",
                        3
                    ],
                    "source": [
                        "obj-4",
                        3
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-22",
                        2
                    ],
                    "source": [
                        "obj-4",
                        2
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-22",
                        1
                    ],
                    "source": [
                        "obj-4",
                        1
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-22",
                        0
                    ],
                    "source": [
                        "obj-4",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-37",
                        0
                    ],
                    "source": [
                        "obj-40",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-4",
                        0
                    ],
                    "source": [
                        "obj-41",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-32",
                        0
                    ],
                    "source": [
                        "obj-50",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-47",
                        0
                    ],
                    "hidden": 1,
                    "source": [
                        "obj-54",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-1",
                        0
                    ],
                    "source": [
                        "obj-6",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-1",
                        0
                    ],
                    "source": [
                        "obj-7",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-7721",
                        0
                    ],
                    "source": [
                        "obj-7711",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-7711",
                        0
                    ],
                    "source": [
                        "obj-7718",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-20",
                        0
                    ],
                    "source": [
                        "obj-7721",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "destination": [
                        "obj-1",
                        0
                    ],
                    "source": [
                        "obj-9",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-libscan-loadbang",
                        0
                    ],
                    "destination": [
                        "obj-libscan-deferlow",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-libscan-deferlow",
                        0
                    ],
                    "destination": [
                        "obj-libscan-scan",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-libscan-scan",
                        0
                    ],
                    "destination": [
                        "obj-libscan-js",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-libscan-js",
                        0
                    ],
                    "destination": [
                        "obj-12",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-12",
                        0
                    ],
                    "destination": [
                        "obj-libscan-js",
                        1
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-libscan-js",
                        1
                    ],
                    "destination": [
                        "obj-17",
                        0
                    ]
                }
            }
        ],
        "parameters": {
            "obj-35": [
                "Gain",
                "Gain",
                0
            ],
            "inherited_shortname": 1
        },
        "autosave": 0,
        "styles": [
            {
                "name": "MP-M4L",
                "default": {
                    "accentcolor": [
                        0.411764705882353,
                        0.411764705882353,
                        0.411764705882353,
                        1.0
                    ],
                    "bgcolor": [
                        0.098039215686275,
                        0.098039215686275,
                        0.098039215686275,
                        1.0
                    ],
                    "bgfillcolor": {
                        "color": [
                            0.266666666666667,
                            0.266666666666667,
                            0.266666666666667,
                            1.0
                        ],
                        "color1": [
                            0.376470588235294,
                            0.384313725490196,
                            0.4,
                            1.0
                        ],
                        "color2": [
                            0.290196078431373,
                            0.309803921568627,
                            0.301960784313725,
                            1.0
                        ],
                        "dynamiccolor": [
                            0.266666666666667,
                            0.266666666666667,
                            0.266666666666667,
                            1.0,
                            "live_contrast_frame",
                            1,
                            0.266666666666667,
                            0.266666666666667,
                            0.266666666666667,
                            1.0,
                            "Control Border"
                        ],
                        "type": "color"
                    },
                    "color": [
                        0.333333333333333,
                        0.870588235294118,
                        0.964705882352941,
                        1.0
                    ],
                    "editing_bgcolor": [
                        0.56078431372549,
                        0.56078431372549,
                        0.56078431372549,
                        1.0
                    ],
                    "elementcolor": [
                        0.313725490196078,
                        0.313725490196078,
                        0.313725490196078,
                        1.0
                    ],
                    "locked_bgcolor": [
                        0.56078431372549,
                        0.56078431372549,
                        0.56078431372549,
                        1.0
                    ],
                    "patchlinecolor": [
                        0.313725490196078,
                        0.313725490196078,
                        0.313725490196078,
                        1.0
                    ],
                    "selectioncolor": [
                        1.0,
                        0.694117647058824,
                        0.0,
                        1.0
                    ],
                    "stripecolor": [
                        0.313725490196078,
                        0.313725490196078,
                        0.313725490196078,
                        1.0
                    ],
                    "textcolor": [
                        0.0,
                        0.0,
                        0.0,
                        1.0
                    ]
                },
                "parentstyle": "",
                "multi": 0
            }
        ]
    }
}
