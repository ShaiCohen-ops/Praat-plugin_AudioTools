# Praat AudioTools for Max - macOS

**Praat AudioTools** is an offline analysis-resynthesis toolkit for experimental
composition, sound design, and research. This Max package hosts Praat scripts
through the `AudioTools.praat~` external and exposes parameters, presets, Praat
Info, visualization, audio input/output, and script execution from Max.

**Author:** Shai Cohen  
**Affiliation:** Department of Music, Bar-Ilan University, Israel  
**Package version:** 1.0.0  
**AudioTools.praat~:** 1.36.1  
**Platform:** macOS Universal 2 (`x86_64` + `arm64`)  
**Minimum macOS:** 11.0  
**Minimum Max:** Max 9

## Installation

Copy the complete `praat` folder to:

```text
~/Documents/Max 9/Packages/praat
```

Restart Max because the package contains a compiled external.

Open:

```text
Extras -> Praat AudioTools
```

or open `patchers/praat.maxpat` directly.

## Core object

```text
[AudioTools.praat~ inputBuffer outputBuffer]
```

The first outlet reports successful completion, the second reports failure /
timeout / stop, and the third carries structured host information including
script descriptors, state, output paths, Praat Info, and visualization output.

## Bundled Praat

The self-contained macOS package expects:

```text
externals/Praat.app/Contents/MacOS/Praat
```

The host prefers this bundled executable. `/Applications/Praat.app` is only a
development fallback used before package assembly.

## Script-library discovery

Priority on macOS:

```text
1. <package>/misc/plugin_AudioTools
2. ~/Library/Application Support/Praat/plugin_AudioTools
3. ~/Library/Preferences/Praat Prefs/plugin_AudioTools
```

Duplicate scripts are resolved by relative path; the first root wins. The exact
script count depends on the library version bundled with this build.

## Optional dependencies

Some individual scripts use optional software such as Python, FFmpeg, VST3,
Ableton Live / Max for Live, IRCAM tools, or additional Python packages. These
are script-specific and are not required by the core `AudioTools.praat~`
external.

On macOS the host's default Python command is `python3` when a script requests
Python capability.

## Visualization

Praat AudioTools host visualization supports 150, 300, and 600 modes. For the
150-equivalent screen mode, Praat exports its native 300-dpi PNG and the macOS
host halves the raster using the built-in `/usr/bin/sips` utility. 300 and 600
modes retain Praat's native export size.

## Documentation

Project documentation:

https://mashav.com/sha/Praat%20AudioTools/

Repository:

https://github.com/ShaiCohen-ops/Praat-plugin_AudioTools

## License

Praat AudioTools code/scripts authored by Shai Cohen are distributed under the
MIT License except where otherwise noted. Bundled Praat is third-party software
under the GNU General Public License, version 3 or later.

See `LICENSE.md`, `THIRD_PARTY_NOTICES.md`, and
`licenses/Praat-GPL-3.0.txt`.
