This directory is intentionally empty in the build kit.

The final package assembler replaces this folder with the exact current
plugin_AudioTools library supplied as its first argument.

Do not test the main library menu until the assembler has populated this folder.
