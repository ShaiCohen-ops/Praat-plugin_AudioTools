# Third-Party Notices

Praat AudioTools includes or interfaces with third-party software. Those
components remain under their own licenses.

## Praat

**Software:** Praat: doing phonetics by computer  
**macOS application:** `externals/Praat.app`  
**Authors:** Paul Boersma, David Weenink, Anastasia Shchupak  
**Project website:** https://praat.org/  
**Source:** https://praat.org/download_sources.html  
**License:** GNU General Public License, version 3 or later

A copy of GNU GPL version 3 is included at:

```text
licenses/Praat-GPL-3.0.txt
```

The Praat application is a separate third-party component and is not covered by
the Praat AudioTools MIT License.

When redistributing a package containing a specific `Praat.app` build, keep
this notice and the GPL license text with the distribution and make the
corresponding source for that exact bundled Praat version available to
recipients in accordance with the GPL.

## Optional external software

Some Praat AudioTools scripts can optionally call software that is not bundled
with the core package, including Python packages, FFmpeg, VST3 plug-ins,
Ableton Live / Max for Live, and IRCAM software. Such software remains subject
to its own license terms.
