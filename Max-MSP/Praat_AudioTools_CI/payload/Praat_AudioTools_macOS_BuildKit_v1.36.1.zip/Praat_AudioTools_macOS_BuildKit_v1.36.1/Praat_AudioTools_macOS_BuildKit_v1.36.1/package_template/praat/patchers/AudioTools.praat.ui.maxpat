{
  "patcher": {
    "fileversion": 1,
    "appversion": {
      "major": 9,
      "minor": 0,
      "revision": 0,
      "architecture": "x64",
      "modernui": 1
    },
    "classnamespace": "box",
    "rect": [100.0, 100.0, 520.0, 540.0],
    "bglocked": 0,
    "openinpresentation": 1,
    "default_fontsize": 12.0,
    "default_fontface": 0,
    "default_fontname": "Arial",
    "gridonopen": 1,
    "gridsize": [15.0, 15.0],
    "toolbarvisible": 0,
    "boxes": [
      {
        "box": {
          "id": "in-1",
          "maxclass": "inlet",
          "patching_rect": [8.0, 8.0, 25.0, 25.0],
          "comment": "structured info from AudioTools.praat~ outlet 3"
        }
      },
      {
        "box": {
          "id": "ui-1",
          "maxclass": "jsui",
          "filename": "AudioTools.praat.ui.js",
          "jsarguments": [],
          "numinlets": 1,
          "numoutlets": 1,
          "patching_rect": [40.0, 8.0, 460.0, 500.0],
          "presentation": 1,
          "presentation_rect": [0.0, 0.0, 460.0, 500.0]
        }
      },
      {
        "box": {
          "id": "out-1",
          "maxclass": "outlet",
          "patching_rect": [505.0, 8.0, 25.0, 25.0],
          "comment": "commands back to AudioTools.praat~"
        }
      }
    ],
    "lines": [
      {
        "patchline": {
          "source": ["in-1", 0],
          "destination": ["ui-1", 0]
        }
      },
      {
        "patchline": {
          "source": ["ui-1", 0],
          "destination": ["out-1", 0]
        }
      }
    ]
  }
}
