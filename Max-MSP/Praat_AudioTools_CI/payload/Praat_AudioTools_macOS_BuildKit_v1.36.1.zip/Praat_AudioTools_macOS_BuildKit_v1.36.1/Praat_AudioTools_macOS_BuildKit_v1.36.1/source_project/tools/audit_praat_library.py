#!/usr/bin/env python3
"""Static migration audit for a Praat AudioTools library. No external packages."""
from __future__ import annotations
import argparse, csv, json, re
from pathlib import Path

def scan(path: Path):
    text=path.read_text(encoding='utf-8', errors='replace')
    lo=text.lower()
    fields=[]
    in_form=False
    for raw in text.splitlines():
        t=raw.strip()
        if re.match(r'^form\s*:?',t,re.I): in_form=True; continue
        if in_form and re.match(r'^endform\s*:?',t,re.I): in_form=False; continue
        if in_form:
            m=re.match(r'^(real|positive|integer|natural|boolean|choice|optionmenu|sentence|text|word|infile|outfile|folder)\s*:?[ \t]*(.*)$',t,re.I)
            if m: fields.append(m.group(1).lower())
    has_meta='#@tool' in lo or '#@param' in lo or '#@preset' in lo or '#@output' in lo
    blocking=[]
    if 'beginpause' in lo or 'endpause' in lo: blocking.append('beginPause/endPause')
    if 'pausescript' in lo: blocking.append('pauseScript')
    chooser=[]
    for q in ('choosefolder$','choosereadfile$','choosewritefile$'):
        if q in lo: chooser.append(q)
    flags=[]
    if re.search(r'(?mi)^\s*play\s*(?::|$)',text): flags.append('Praat Play')
    if 'picture' in lo or 'draw' in lo: flags.append('visual/Picture')
    if 'runsubprocess' in lo or 'system' in lo or 'python' in lo: flags.append('subprocess/python')
    if re.search(r'(?i)save as .*file|write.*file',text): flags.append('file output')
    if blocking: status='blocked-interactive'
    elif chooser and not has_meta: status='needs-metadata'
    elif has_meta: status='enhanced'
    else: status='legacy-safe'
    if '#@tool' in lo and '#@output' in lo and '#@param' in lo: status='fully-hosted' if not blocking else status
    return {
        'path': str(path), 'status': status, 'form_fields': len(fields),
        'field_types': ','.join(sorted(set(fields))), 'metadata': has_meta,
        'blocking': '; '.join(blocking), 'choosers': '; '.join(chooser),
        'flags': '; '.join(flags)
    }

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('root', type=Path)
    ap.add_argument('--out', type=Path, default=Path('AudioToolsPraat_audit'))
    a=ap.parse_args()
    rows=[scan(p) for p in sorted(a.root.rglob('*.praat'))]
    a.out.parent.mkdir(parents=True,exist_ok=True)
    with (a.out.with_suffix('.csv')).open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys()) if rows else ['path']); w.writeheader(); w.writerows(rows)
    a.out.with_suffix('.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
    from collections import Counter
    print(f'scanned {len(rows)} scripts')
    for k,v in Counter(r['status'] for r in rows).most_common(): print(f'{k}: {v}')

if __name__=='__main__': main()
