#include <algorithm>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <cctype>

static std::string trim(const std::string& s){size_t a=0,b=s.size();while(a<b&&std::isspace((unsigned char)s[a]))++a;while(b>a&&std::isspace((unsigned char)s[b-1]))--b;return s.substr(a,b-a);} 
static std::string lower(std::string s){for(char& c:s)c=(char)std::tolower((unsigned char)c);return s;}
static std::vector<std::string> linesOf(const std::string& s){std::vector<std::string> r;std::istringstream is(s);std::string l;while(std::getline(is,l))r.push_back(l);return r;}
struct PictureBounds { bool found=false; double x1=0.0,x2=8.0,y1=0.0,y2=8.0; };
static PictureBounds infer_picture_bounds(const std::string& script){PictureBounds b;for(const auto& line:linesOf(script)){std::string t=trim(line),lo=lower(t);const std::string key="select outer viewport:";if(lo.rfind(key,0)!=0)continue;size_t colon=t.find(':');if(colon==std::string::npos)continue;std::string tail=t.substr(colon+1);for(char& c:tail)if(c==',')c=' ';std::istringstream iss(tail);double a=0,c=0,d=0,e=0;if(!(iss>>a>>c>>d>>e))continue;const double lx=(std::min)(a,c),rx=(std::max)(a,c),by=(std::min)(d,e),ty=(std::max)(d,e);if(!b.found){b.found=true;b.x1=lx;b.x2=rx;b.y1=by;b.y2=ty;}else{b.x1=(std::min)(b.x1,lx);b.x2=(std::max)(b.x2,rx);b.y1=(std::min)(b.y1,by);b.y2=(std::max)(b.y2,ty);}}return b;}
int main(){std::string s="Select outer viewport: 0, 8, 0, 0.65\nSelect outer viewport: 0, 4.2, 0.75, 4.60\nSelect outer viewport: 4.2, 8, 0.75, 4.60\nSelect outer viewport: 0, 8, 0, 8\nSelect outer viewport: 0, 8, 6.62, 7.30\n";auto b=infer_picture_bounds(s);std::cout<<b.found<<" "<<b.x1<<" "<<b.x2<<" "<<b.y1<<" "<<b.y2<<"\n";return !(b.found&&b.x1==0&&b.x2==8&&b.y1==0&&b.y2==8);}
