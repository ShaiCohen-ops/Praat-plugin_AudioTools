/**
 * AudioTools.praat~.cpp  v1.36.1
 * ===========================
 * Max/MSP external — bridges Max buffer~ objects to Praat.
 *
 * Instantiation:
 *   [AudioTools.praat~ input_buf output_buf]
 *
 * Inlets  : 1  (messages + bang)
 * Outlets : 3  (bang on success / bang on error / structured host info)
 *
 * ─── MESSAGES ────────────────────────────────────────────────────────────────
 *
 *  script <path>  — set Praat script path (spaces in path supported)
 *  praat <path>   — set path to the Praat executable (spaces supported)
 *  send           — export buffer + open Praat GUI with the audio loaded
 *  receive        — read the manual _out.wav → output buffer → bang outlet
 *  bang           — fully automated: export + run script headless + import
 *  open           — open Praat GUI (no file loaded)
 *  stop           — abort a running pipeline (now actually kills Praat)
 *  timeout <ms>   — polling timeout (default 30000)
 *  status         — post external version, paths, workspace and run state
 *  debug <0|1>    — 1 = keep the run workspace after success for inspection
 *  set in  <n>    — change input  buffer at runtime
 *  set out <n>    — change output buffer at runtime
 *
 * ─── SCRIPT TEMPLATE (for bang/auto mode, non-form scripts) ─────────────────
 *
 *   Read from file: "{{IN}}"
 *   # ... your processing ...
 *   Save as WAV file: "{{OUT}}"
 *
 * ═════════════════════════════════════════════════════════════════════════════
 * Changes v1.36.1 — Pause virtualization ordering / variable-default fix
 *   - Pause fields whose defaults reference pre-initialized script variables are
 *     resolved for Max UI and injected at the original beginPause location.
 *   - Bare boolean conditions (if edit_details) now drive conditional UI groups.
 *
 * Changes v1.36  — headless Pause virtualization
 *   - beginPause/endPause configuration dialogs are parsed into persistent
 *     host parameters and removed from the generated headless run script.
 *   - Simple if/elsif equality conditions become conditional Max UI groups.
 *   - Button-only/confirmation pauses that assign endPause are resolved to
 *     their declared default button, preserving deterministic headless flow.
 *   - Pauses inside for/while/repeat loops or procedures remain Safety Gate
 *     blockers because they require true runtime suspend/resume interaction.
 *
 * Changes v1.35  — Praat Info + screen visualization
 * ═════════════════════════════════════════════════════════════════════════════
 *   - v1.35.1 correction: in Praat --run mode, writeInfo/appendInfo output is
 *     stdout by definition. Capture that stdout from the hosted Praat process
 *     and emit it on outlet 3 as praat_info_begin / praat_info_line /
 *     praat_info_end. No info$() command is injected into the user script.
 *   - Visualization is explicitly OFF by default in the external itself.
 *   - visualdpi 150|300|600 added. 150 is the default screen mode: Praat
 *     exports its supported 300-dpi PNG, then the Windows host downsamples it
 *     2x before publishing output image. 300 and 600 keep native Praat export.
 *   - Existing stereo audio import, preset state, safety and output strategy
 *     paths are intentionally unchanged.
 *
 * Changes v1.34  — dynamic Max UI preview
 * ═════════════════════════════════════════════════════════════════════════════
 *
 * FIX 1 — form header detection missed modern colon syntax.
 *         v1.24 tested  tl.substr(0,5)=="form "  which matches neither
 *         `form: "My Tool"` nor `form:"My Tool"`. Those scripts had their form
 *         block left intact, Praat tried to draw a dialog under --run, and the
 *         run died at the timeout. Detection is now token-based.
 *         Consequence of fixing it: scripts using the modern header usually
 *         also use the modern FIELD syntax (`real: "Frequency (Hz)", 440`),
 *         which the old field parser would have mangled. A second parse path
 *         for comma/quote syntax is therefore included — see NEW below.
 *
 * FIX 2 — a `comment` line inside a choice/optionmenu block killed the block.
 *         v1.24 order was: handle option/button → flushChoice() → skip comment.
 *         A comment between options flushed the choice early, cleared
 *         choiceVar, and every later `option` was silently dropped. If the
 *         default index pointed past the options collected before the comment,
 *         the `$` string variable was never assigned at all → undefined
 *         variable → script error → timeout. comment is now skipped BEFORE
 *         the flush.
 *
 * FIX 3 — scripts were truncated at 64 KB.
 *         `char raw[65536]` with an unchecked fread: anything larger was cut
 *         mid-line and the truncated remainder was written to the run script
 *         and executed. The whole file is now read into a std::string.
 *
 * FIX 4 — script errors cost the full timeout.
 *         v1.24 used run_detached, which closed the process handle
 *         immediately, so the exit code was discarded and completion was
 *         inferred purely from _out.wav appearing. The process handle is now
 *         retained: the poll loop watches the process AND the file, so a
 *         script that errors reports in ~200 ms with its exit code instead of
 *         30 s of silence.
 *         Praat's stdout/stderr is redirected to log.txt in the run workspace
 *         and the tail is posted on failure. NOTE: this is best-effort — the
 *         handle-inheriting launch is attempted first and falls back to the
 *         exact v1.24 CreateProcessA pattern if it fails, so a sandbox
 *         rejection degrades to v1.24 behaviour rather than breaking the run.
 *         Praat.exe is a GUI binary; the log may legitimately be empty.
 *
 * FIX 5 — two failure paths hung the patch with no bang on either outlet.
 *         import_output_buffer() failing in bang_worker (v1.24 line 928) and
 *         in receive_worker (line 572) both returned without firing the error
 *         outlet. Every exit path now reports.
 *
 * FIX 6 — AudioToolsPraat_free destroyed the mutex and atomics while detached
 *         workers could still hold them. Threads are now owned (joinable) and
 *         joined in free(); main-thread notification moved from defer() to an
 *         owned qelem so pending notifications are cancelled by qelem_unset()
 *         instead of firing into freed memory.
 *
 * NEW (Phase 1 — host core):
 *   - Per-instance workspace under the system temp dir, and a per-run
 *     subdirectory with a run-id (principle P4). Nothing is written next to
 *     the external any more, so two instances no longer collide on
 *     _in.wav/_out.wav/_run.praat.
 *       <temp>/AudioToolsPraat/inst-<pid>-<n>/run-<k>/{input_0.wav,run.praat,
 *                                                      outputs/out.wav,log.txt}
 *     Manual send/receive keeps stable paths in the instance directory.
 *   - [stop] now terminates the Praat process it launched, instead of only
 *     abandoning the poll loop and leaving Praat running.
 *   - [status] and [debug <0|1>] messages.
 *   - Failed/cancelled run workspaces are removed unless debug=1. The most recent
 *     successful workspace is retained until the next run so structured output
 *     paths remain valid for Max/Jitter consumers.
 *
 * NEW (form parser):
 *   - Modern Praat field syntax parsed: `real: "Frequency (Hz)", 440`,
 *     `boolean: "Play", 1`, `optionmenu: "Preset", 1`, `option: "Label"`.
 *     Old syntax (`real Frequency 440`, `real Frequency: 440`) is unchanged.
 *   - Field types infile / outfile / folder recognised.
 *   - The `$` string variable is now emitted for `choice` as well as
 *     `optionmenu`; recent Praat sets both, and an unused extra variable is
 *     harmless where a missing one is fatal.
 *   - Variable-name derivation generalised for quoted labels containing
 *     spaces and punctuation.
 *
 * CHANGED (principle P2 — do not break the sound logic of existing scripts):
 *   - v1.24 forced any boolean whose name CONTAINED "play", "draw", "visual",
 *     "display", "show" or "open" to 0. Substring matching on a music library
 *     will eventually hit a musical parameter and silently change the sound.
 *     "open" is the clearest hazard (Open_string_resonance, Open_hi_hat) and
 *     is not a playback word at all; it has been removed entirely.
 *     Matching is now whole-word on the underscore-separated name, split into
 *     two roles, and every forced field is reported with its role.
 *     This is a conservative fallback only — per the v7 plan, semantic
 *     metadata (role=praat-playback) supersedes it.
 *
 * CHANGED (output):
 *   - The blind `Remove` after the auto-save append is gone, per the v7 plan's
 *     output-strategy section: the one-shot Praat process already provides
 *     process-level cleanup, and removing the selected object blindly is wrong
 *     for multi-object tools. The `Save as WAV file` append is UNCHANGED —
 *     output strategy proper is Phase 7.
 *   - Channel-count mismatch on import is no longer silent. The truncating
 *     copy is retained (open decision D6), but dropped channels and discarded
 *     frames are now reported explicitly.
 *
 * NEW v1.34 (dynamic Max UI support):
 *   - Loading a script now automatically emits a complete `describe` stream so
 *     a connected Max UI can rebuild itself without a second manual message.
 *   - `visual 0|1` synchronizes role=visual parameter state and does not turn a
 *     named musical preset into Manual/Custom. Praat playback remains Max-owned.
 *   - Package adds AudioTools.praat.ui.maxpat + AudioTools.praat.ui.js, a native
 *     Max bpatcher panel generated from the descriptor and kept in sync by value,
 *     preset_selected, safety and state messages.
 *
 * NEW v1.32 (legacy preset introspection):
 *   - Legacy `if preset = N / elsif preset = N` blocks are scanned for static
 *     assignments to exposed form parameters. Selecting a preset in Max now
 *     updates those parameter values immediately, before [bang].
 *   - Simple aliases such as `pitch_scatter = varispeed_scatter_semitones` are
 *     resolved, so preset assignments to the internal alias update the correct
 *     exposed Max parameter.
 *   - Preset selection restores form defaults before applying its mapping.
 *     Manual/Custom therefore reliably returns to defaults instead of inheriting
 *     stale values from the previously selected preset.
 *   - Editing a non-preset parameter while a named preset is active switches
 *     the host state to Manual/Custom when such an option exists. This preserves
 *     the selected preset as a starting point while making the user's edit
 *     effective in legacy scripts whose preset block would otherwise overwrite it.
 *
 * NEW v1.31 (v7 host preview):
 *   - Persistent ParamSpec state with describe/param/reset/dump.
 *   - Preset catalogue and #@preset mapped-state support.
 *   - Third structured-info outlet while preserving success/error outlet indices.
 *   - Run Safety Gate for blocking runtime dialogs and unresolved choosers.
 *   - Tool modes and explicit output strategies, including generator/no-input and analyzer/no-audio.
 *   - {{IMAGE}} and {{MANIFEST}} workspace placeholders for script-managed outputs.
 *   - Praat playback is host-disabled; direct Play commands are stripped in headless runs.
 * STILL OPEN:
 *   - D6: output buffer channel/sample-rate reconfiguration remains conservative.
 *   - Full package UI/library installer and migration metadata for all library scripts are separate package-layer work.
 *
 * PLATFORM: the POSIX branches are written but UNTESTED. v1.24 would not
 *   compile off Windows at all (DWORD in the struct, bare Sleep() and
 *   GetLastError() outside the #ifdef); that is fixed, but "compiles" is not
 *   "works".
 */

#ifdef _WIN32
#   define WIN32_LEAN_AND_MEAN
#   ifndef NOMINMAX
#       define NOMINMAX
#   endif
#   include <windows.h>
#   include <wincodec.h>
#   include <direct.h>
#   define DIRSEP '\\'
#else
#   include <unistd.h>
#   include <dlfcn.h>
#   include <sys/types.h>
#   include <sys/stat.h>
#   include <sys/wait.h>
#   include <fcntl.h>
#   include <signal.h>
#   include <dirent.h>
#   include <time.h>
#   define DIRSEP '/'
#endif

#include <cerrno>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <string>
#include <vector>
#include <algorithm>
#include <thread>
#include <atomic>
#include <mutex>
#include <chrono>
#include <map>
#include <sstream>
#include <fstream>
#include <utility>
#include <new>

#include "ext.h"
#include "ext_obex.h"
#include "z_dsp.h"
#include "buffer.h"

// ═════════════════════════════════════════════════════════════════════════════
// SECTION 0 — Small cross-platform helpers
// ═════════════════════════════════════════════════════════════════════════════

static void sleep_ms(unsigned long ms)
{
#ifdef _WIN32
    Sleep((DWORD)ms);
#else
    struct timespec ts;
    ts.tv_sec  = (time_t)(ms / 1000);
    ts.tv_nsec = (long)((ms % 1000) * 1000000L);
    nanosleep(&ts, nullptr);
#endif
}

static bool make_dir(const char* path)
{
#ifdef _WIN32
    if (CreateDirectoryA(path, nullptr)) return true;
    return GetLastError() == ERROR_ALREADY_EXISTS;
#else
    if (mkdir(path, 0777) == 0) return true;
    return errno == EEXIST;
#endif
}

// Create every component of a path.
static bool make_dirs(const char* path)
{
    std::string p(path);
    for (size_t i = 1; i < p.size(); ++i) {
        if (p[i] == '/' || p[i] == '\\') {
            std::string part = p.substr(0, i);
            if (part.size() == 2 && part[1] == ':') continue;   // C:
            make_dir(part.c_str());
        }
    }
    return make_dir(p.c_str());
}

// Recursively delete a directory tree. Used for workspace cleanup.
static void remove_tree(const char* path)
{
#ifdef _WIN32
    std::string pat = std::string(path) + "\\*";
    WIN32_FIND_DATAA fd;
    HANDLE h = FindFirstFileA(pat.c_str(), &fd);
    if (h != INVALID_HANDLE_VALUE) {
        do {
            if (strcmp(fd.cFileName, ".") == 0 || strcmp(fd.cFileName, "..") == 0)
                continue;
            std::string child = std::string(path) + "\\" + fd.cFileName;
            if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
                remove_tree(child.c_str());
            else
                DeleteFileA(child.c_str());
        } while (FindNextFileA(h, &fd));
        FindClose(h);
    }
    RemoveDirectoryA(path);
#else
    DIR* d = opendir(path);
    if (d) {
        struct dirent* e;
        while ((e = readdir(d)) != nullptr) {
            if (strcmp(e->d_name, ".") == 0 || strcmp(e->d_name, "..") == 0)
                continue;
            std::string child = std::string(path) + "/" + e->d_name;
            struct stat st;
            if (stat(child.c_str(), &st) == 0 && S_ISDIR(st.st_mode))
                remove_tree(child.c_str());
            else
                ::remove(child.c_str());
        }
        closedir(d);
    }
    rmdir(path);
#endif
}

static bool get_temp_root(char* buf, size_t bufSize)
{
#ifdef _WIN32
    char t[MAX_PATH];
    DWORD n = GetTempPathA(MAX_PATH, t);
    if (n == 0 || n > MAX_PATH) return false;
    if (n > 0 && (t[n-1] == '\\' || t[n-1] == '/')) t[n-1] = '\0';
    snprintf(buf, bufSize, "%s", t);
    return true;
#else
    const char* t = getenv("TMPDIR");
    if (!t || !*t) t = "/tmp";
    snprintf(buf, bufSize, "%s", t);
    size_t L = strlen(buf);
    while (L > 1 && buf[L-1] == '/') buf[--L] = '\0';
    return true;
#endif
}

static long current_pid()
{
#ifdef _WIN32
    return (long)GetCurrentProcessId();
#else
    return (long)getpid();
#endif
}

// Read the last `maxBytes` of a text file — used to surface Praat's own error
// text after a failed run.
static std::string tail_of_file(const char* path, size_t maxBytes)
{
    FILE* f = fopen(path, "rb");
    if (!f) return std::string();
    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    if (sz <= 0) { fclose(f); return std::string(); }
    size_t want = (size_t)sz < maxBytes ? (size_t)sz : maxBytes;
    fseek(f, (long)((size_t)sz - want), SEEK_SET);
    std::string s(want, '\0');
    size_t got = fread(&s[0], 1, want, f);
    fclose(f);
    s.resize(got);
    // Collapse CR so the Max console does not print stray boxes
    std::string out;
    for (char c : s) if (c != '\r') out += c;
    while (!out.empty() && (out.back() == '\n' || out.back() == ' ')) out.pop_back();
    return out;
}

// Screen-mode PNG helper. Praat itself exposes 300- and 600-dpi PNG
// commands, not 150 dpi. On Windows, v1.35 implements visualdpi 150 by asking
// Praat for 300 dpi and halving the resulting raster with WIC before Max/Jitter
// sees it. Failure is non-fatal: the original 300-dpi PNG is retained.
#ifdef _WIN32
static std::wstring path_to_wide(const char* path)
{
    if (!path) return std::wstring();
    int n = MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, path, -1, nullptr, 0);
    UINT cp = CP_UTF8;
    DWORD flags = MB_ERR_INVALID_CHARS;
    if (n <= 0) {
        cp = CP_ACP; flags = 0;
        n = MultiByteToWideChar(cp, flags, path, -1, nullptr, 0);
    }
    if (n <= 0) return std::wstring();
    std::wstring w((size_t)n, L'\0');
    MultiByteToWideChar(cp, flags, path, -1, &w[0], n);
    if (!w.empty() && w.back() == L'\0') w.pop_back();
    return w;
}

static void safe_release(IUnknown* p) { if (p) p->Release(); }

static bool downsample_png_half_wic(const char* path, UINT& outW, UINT& outH,
                                    std::string& reason)
{
    outW = outH = 0;
    std::wstring srcPath = path_to_wide(path);
    if (srcPath.empty()) { reason = "cannot convert PNG path to UTF-16"; return false; }
    std::wstring tmpPath = srcPath + L".v135tmp.png";

    HRESULT chr = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
    const bool uninit = SUCCEEDED(chr);
    if (FAILED(chr) && chr != RPC_E_CHANGED_MODE) {
        reason = "COM initialization failed";
        return false;
    }

    IWICImagingFactory* factory = nullptr;
    IWICBitmapDecoder* decoder = nullptr;
    IWICBitmapFrameDecode* frame = nullptr;
    IWICBitmapScaler* scaler = nullptr;
    IWICStream* stream = nullptr;
    IWICBitmapEncoder* encoder = nullptr;
    IWICBitmapFrameEncode* encFrame = nullptr;
    IPropertyBag2* props = nullptr;
    IWICFormatConverter* converter = nullptr;
    bool encoded = false;

    do {
        HRESULT hr = CoCreateInstance(CLSID_WICImagingFactory, nullptr,
                                      CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&factory));
        if (FAILED(hr)) { reason = "cannot create WIC factory"; break; }
        hr = factory->CreateDecoderFromFilename(srcPath.c_str(), nullptr, GENERIC_READ,
                                                WICDecodeMetadataCacheOnLoad, &decoder);
        if (FAILED(hr)) { reason = "cannot decode visual.png"; break; }
        hr = decoder->GetFrame(0, &frame);
        if (FAILED(hr)) { reason = "cannot read PNG frame"; break; }

        UINT srcW=0, srcH=0;
        hr = frame->GetSize(&srcW, &srcH);
        if (FAILED(hr) || srcW < 2 || srcH < 2) { reason = "invalid PNG dimensions"; break; }
        outW = (srcW + 1u) / 2u;
        outH = (srcH + 1u) / 2u;

        hr = factory->CreateBitmapScaler(&scaler);
        if (FAILED(hr)) { reason = "cannot create WIC scaler"; break; }
        hr = scaler->Initialize(frame, outW, outH, WICBitmapInterpolationModeFant);
        if (FAILED(hr)) { reason = "cannot scale visual.png"; break; }

        hr = factory->CreateStream(&stream);
        if (FAILED(hr)) { reason = "cannot create WIC stream"; break; }
        DeleteFileW(tmpPath.c_str());
        hr = stream->InitializeFromFilename(tmpPath.c_str(), GENERIC_WRITE);
        if (FAILED(hr)) { reason = "cannot create temporary PNG"; break; }

        hr = factory->CreateEncoder(GUID_ContainerFormatPng, nullptr, &encoder);
        if (FAILED(hr)) { reason = "cannot create PNG encoder"; break; }
        hr = encoder->Initialize(stream, WICBitmapEncoderNoCache);
        if (FAILED(hr)) { reason = "cannot initialize PNG encoder"; break; }
        hr = encoder->CreateNewFrame(&encFrame, &props);
        if (FAILED(hr)) { reason = "cannot create PNG output frame"; break; }
        hr = encFrame->Initialize(props);
        if (FAILED(hr)) { reason = "cannot initialize PNG output frame"; break; }
        hr = encFrame->SetSize(outW, outH);
        if (FAILED(hr)) { reason = "cannot set PNG output size"; break; }

        WICPixelFormatGUID fmt = GUID_WICPixelFormat32bppBGRA;
        hr = encFrame->SetPixelFormat(&fmt);
        if (FAILED(hr)) { reason = "cannot set PNG pixel format"; break; }

        hr = factory->CreateFormatConverter(&converter);
        if (FAILED(hr)) { reason = "cannot create WIC format converter"; break; }
        hr = converter->Initialize(scaler, fmt, WICBitmapDitherTypeNone, nullptr, 0.0,
                                   WICBitmapPaletteTypeCustom);
        if (FAILED(hr)) { reason = "cannot convert scaled PNG pixels"; break; }
        hr = encFrame->WriteSource(converter, nullptr);
        if (FAILED(hr)) { reason = "cannot write scaled PNG"; break; }
        hr = encFrame->Commit();
        if (FAILED(hr)) { reason = "cannot commit scaled PNG frame"; break; }
        hr = encoder->Commit();
        if (FAILED(hr)) { reason = "cannot commit scaled PNG"; break; }
        encoded = true;
    } while(false);

    // Release both source and destination file handles before replacing the file.
    safe_release(converter);
    safe_release(props);
    safe_release(encFrame);
    safe_release(encoder);
    safe_release(stream);
    safe_release(scaler);
    safe_release(frame);
    safe_release(decoder);
    safe_release(factory);

    bool ok = false;
    if (encoded) {
        if (MoveFileExW(tmpPath.c_str(), srcPath.c_str(),
                        MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH)) {
            ok = true;
        } else {
            reason = "cannot replace 300-dpi PNG with screen-size PNG";
        }
    }
    if (!ok) DeleteFileW(tmpPath.c_str());
    if (uninit) CoUninitialize();
    return ok;
}
#elif defined(__APPLE__)
// macOS counterpart to the Windows WIC half-scale path.  `sips` is supplied
// by macOS, so this keeps the external dependency-free while preserving the
// v1.36.1 visual DPI contract: Praat writes the 300-dpi PNG and the host makes
// the 150-equivalent screen copy by halving the raster dimensions.
static bool downsample_png_half_wic(const char* path, unsigned int& outW, unsigned int& outH,
                                    std::string& reason)
{
    outW = outH = 0;
    if (!path || !*path) { reason = "empty PNG path"; return false; }

    // visual.png lives in the host-controlled temporary workspace.  Quote the
    // path because macOS temporary paths may contain spaces.
    std::string qpath = "\"" + std::string(path) + "\"";
    std::string query = "/usr/bin/sips -g pixelWidth -g pixelHeight " + qpath +
                        " 2>/dev/null";
    FILE* pipe = popen(query.c_str(), "r");
    if (!pipe) { reason = "cannot launch /usr/bin/sips"; return false; }

    unsigned int srcW = 0, srcH = 0;
    char line[512];
    while (fgets(line, sizeof(line), pipe)) {
        const char* pw = strstr(line, "pixelWidth:");
        const char* ph = strstr(line, "pixelHeight:");
        if (pw) sscanf(pw, "pixelWidth: %u", &srcW);
        if (ph) sscanf(ph, "pixelHeight: %u", &srcH);
    }
    int rc = pclose(pipe);
    if (rc != 0 || srcW < 2 || srcH < 2) {
        reason = "cannot read PNG dimensions with /usr/bin/sips";
        return false;
    }

    outW = (srcW + 1) / 2;
    outH = (srcH + 1) / 2;
    char cmd[4096];
    snprintf(cmd, sizeof(cmd),
             "/usr/bin/sips -z %u %u \"%s\" >/dev/null 2>&1",
             outH, outW, path);
    if (system(cmd) != 0) {
        reason = "/usr/bin/sips resize failed";
        outW = outH = 0;
        return false;
    }
    return true;
}
#else
static bool downsample_png_half_wic(const char*, unsigned int&, unsigned int&, std::string& reason)
{
    reason = "150-dpi screen downsample is unavailable on this platform";
    return false;
}
#endif

// ═════════════════════════════════════════════════════════════════════════════
// SECTION 1 — Tiny WAV I/O
// ═════════════════════════════════════════════════════════════════════════════

static const uint16_t WAV_FMT_PCM        = 0x0001;
static const uint16_t WAV_FMT_FLOAT      = 0x0003;
static const uint16_t WAV_FMT_EXTENSIBLE = 0xFFFE; // used by Praat for multichannel

static inline void write_u16_le(uint8_t* p, uint16_t v) {
    p[0]=(uint8_t)(v); p[1]=(uint8_t)(v>>8);
}
static inline void write_u32_le(uint8_t* p, uint32_t v) {
    p[0]=(uint8_t)(v); p[1]=(uint8_t)(v>>8);
    p[2]=(uint8_t)(v>>16); p[3]=(uint8_t)(v>>24);
}
static inline uint16_t read_u16_le(const uint8_t* p) {
    return (uint16_t)(p[0])|((uint16_t)(p[1])<<8);
}
static inline uint32_t read_u32_le(const uint8_t* p) {
    return (uint32_t)(p[0])|((uint32_t)(p[1])<<8)|
           ((uint32_t)(p[2])<<16)|((uint32_t)(p[3])<<24);
}

static bool wav_write_float32(const char* path, const float* samples,
                               uint32_t nFrames, uint16_t nChannels,
                               uint32_t sampleRate)
{
    FILE* f = fopen(path,"wb");
    if (!f) return false;
    uint32_t dataBytes=nFrames*nChannels*(uint32_t)sizeof(float);
    uint32_t fmtSize=18;
    uint32_t riffSize=4+8+fmtSize+8+dataBytes;
    uint8_t hdr[46]; size_t pos=0;
    memcpy(hdr+pos,"RIFF",4); pos+=4;
    write_u32_le(hdr+pos,riffSize); pos+=4;
    memcpy(hdr+pos,"WAVE",4); pos+=4;
    memcpy(hdr+pos,"fmt ",4); pos+=4;
    write_u32_le(hdr+pos,fmtSize); pos+=4;
    write_u16_le(hdr+pos,WAV_FMT_FLOAT); pos+=2;
    write_u16_le(hdr+pos,nChannels); pos+=2;
    write_u32_le(hdr+pos,sampleRate); pos+=4;
    write_u32_le(hdr+pos,sampleRate*nChannels*(uint32_t)sizeof(float)); pos+=4;
    write_u16_le(hdr+pos,(uint16_t)(nChannels*sizeof(float))); pos+=2;
    write_u16_le(hdr+pos,32); pos+=2;
    write_u16_le(hdr+pos,0); pos+=2;
    memcpy(hdr+pos,"data",4); pos+=4;
    write_u32_le(hdr+pos,dataBytes); pos+=4;
    fwrite(hdr,1,pos,f);
    fwrite(samples,sizeof(float),(size_t)nFrames*nChannels,f);
    fclose(f);
    return true;
}

struct WavInfo { uint16_t channels; uint32_t sampleRate; uint32_t nFrames; uint16_t fmtTag; };

static float* wav_read_float32(const char* path, WavInfo& info)
{
    FILE* f=fopen(path,"rb");
    if (!f) return nullptr;
    fseek(f,0,SEEK_END); long fsz=ftell(f); fseek(f,0,SEEK_SET);
    if (fsz<44) { fclose(f); return nullptr; }
    std::vector<uint8_t> buf((size_t)fsz);
    if (fread(buf.data(),1,(size_t)fsz,f)!=(size_t)fsz) { fclose(f); return nullptr; }
    fclose(f);
    const uint8_t* p=buf.data();
    if (memcmp(p,"RIFF",4)!=0||memcmp(p+8,"WAVE",4)!=0) return nullptr;
    uint16_t fmtTag=0,nCh=0,bps=0; uint32_t sr=0;
    const uint8_t* dataPtr=nullptr; uint32_t dataLen=0;
    const uint8_t* end=p+fsz; const uint8_t* chunk=p+12;
    while (chunk+8<=end) {
        char tag[5]={}; memcpy(tag,chunk,4);
        uint32_t sz=read_u32_le(chunk+4);
        const uint8_t* body=chunk+8;
        if (body>end) break;
        if (memcmp(tag,"fmt ",4)==0&&sz>=16) {
            fmtTag=read_u16_le(body); nCh=read_u16_le(body+2);
            sr=read_u32_le(body+4); bps=read_u16_le(body+14);
            // WAVE_FORMAT_EXTENSIBLE: actual format is in SubFormat GUID bytes 0-1
            if (fmtTag == WAV_FMT_EXTENSIBLE && sz >= 40)
                fmtTag = read_u16_le(body + 24);
        } else if (memcmp(tag,"data",4)==0) {
            dataPtr=body; dataLen=sz;
            // Guard a truncated/mis-sized data chunk rather than reading past
            // the end of the file buffer.
            uint32_t avail=(uint32_t)(end-body);
            if (dataLen>avail) dataLen=avail;
        }
        chunk=body+((sz+1)&~1u);
    }
    if (!dataPtr||nCh==0||sr==0) return nullptr;
    uint32_t bps8=bps/8; if (!bps8) return nullptr;
    uint32_t total=dataLen/bps8; uint32_t nFrames=total/nCh;
    if (nFrames==0) return nullptr;
    total=nFrames*nCh;
    float* out=new float[total];
    if (fmtTag==WAV_FMT_FLOAT&&bps==32) {
        memcpy(out,dataPtr,total*sizeof(float));
    } else if (fmtTag==WAV_FMT_PCM&&bps==16) {
        for (uint32_t i=0;i<total;++i) {
            int16_t s; memcpy(&s,dataPtr+i*2,2); out[i]=(float)s/32768.f;
        }
    } else if (fmtTag==WAV_FMT_PCM&&bps==24) {
        for (uint32_t i=0;i<total;++i) {
            int32_t s=(int32_t)(dataPtr[i*3])|((int32_t)(dataPtr[i*3+1])<<8)
                     |((int32_t)(dataPtr[i*3+2])<<16);
            if(s&0x800000) s|=(int32_t)0xFF000000; out[i]=(float)s/8388608.f;
        }
    } else if (fmtTag==WAV_FMT_PCM&&bps==32) {
        for (uint32_t i=0;i<total;++i) {
            int32_t s; memcpy(&s,dataPtr+i*4,4); out[i]=(float)s/2147483648.f;
        }
    } else {
        delete[] out; return nullptr;
    }
    info.channels=nCh; info.sampleRate=sr; info.nFrames=nFrames; info.fmtTag=fmtTag;
    return out;
}

// ═════════════════════════════════════════════════════════════════════════════
// SECTION 2 — Owned process execution  (FIX 4)
// ═════════════════════════════════════════════════════════════════════════════
//
// v1.24 fired CreateProcessA and closed the handle immediately, so the exit
// code was thrown away and the only completion signal was _out.wav appearing.
// Every script error therefore cost the full timeout. We now keep the handle
// so the poll loop can see the process die.

struct ProcHandle {
#ifdef _WIN32
    HANDLE h = nullptr;
    bool valid() const { return h != nullptr; }
#else
    pid_t pid = -1;
    bool valid() const { return pid > 0; }
#endif
};

// Launch `exe` with `args`. If logPath is non-null, stdout+stderr are
// redirected there; if the handle-inheriting launch fails for any reason we
// retry with the EXACT v1.24 pattern so behaviour degrades rather than breaks.
// Returns true on launch; launchErr receives the OS error on failure.
static bool proc_launch(const char* exe, const char* args, const char* logPath,
                        ProcHandle& out, int& launchErr, bool& logAttached)
{
    logAttached = false;
    launchErr   = 0;

#ifdef _WIN32
    char cmdLine[4096];
    snprintf(cmdLine, sizeof(cmdLine), "\"%s\" %s", exe, args);

    PROCESS_INFORMATION pi = {};
    BOOL ok = FALSE;

    if (logPath && *logPath) {
        SECURITY_ATTRIBUTES sa = {};
        sa.nLength = sizeof(sa);
        sa.bInheritHandle = TRUE;
        HANDLE hLog = CreateFileA(logPath, GENERIC_WRITE,
                                  FILE_SHARE_READ | FILE_SHARE_WRITE, &sa,
                                  CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
        if (hLog != INVALID_HANDLE_VALUE) {
            STARTUPINFOA si = {};
            si.cb          = sizeof(si);
            si.dwFlags     = STARTF_USESTDHANDLES;
            si.hStdOutput  = hLog;
            si.hStdError   = hLog;
            si.hStdInput   = GetStdHandle(STD_INPUT_HANDLE);
            std::vector<char> buf(cmdLine, cmdLine + strlen(cmdLine) + 1);
            ok = CreateProcessA(nullptr, buf.data(), nullptr, nullptr,
                                TRUE,          // inherit handles — needed for the log
                                0,             // flags 0, as in v1.24
                                nullptr, nullptr, &si, &pi);
            CloseHandle(hLog);
            if (ok) logAttached = true;
        }
    }

    if (!ok) {
        // Fallback: byte-for-byte the launch that v1.24 used and that is known
        // to work under Max. No log capture on this path.
        STARTUPINFOA si = {};
        si.cb = sizeof(si);
        std::vector<char> buf(cmdLine, cmdLine + strlen(cmdLine) + 1);
        ok = CreateProcessA(nullptr, buf.data(), nullptr, nullptr,
                            FALSE, 0, nullptr, nullptr, &si, &pi);
    }

    if (!ok) { launchErr = (int)GetLastError(); return false; }

    CloseHandle(pi.hThread);
    out.h = pi.hProcess;
    return true;
#else
    // POSIX branch — written for the macOS port, UNTESTED.
    pid_t pid = fork();
    if (pid < 0) { launchErr = errno; return false; }
    if (pid == 0) {
        if (logPath && *logPath) {
            int fd = open(logPath, O_WRONLY | O_CREAT | O_TRUNC, 0644);
            if (fd >= 0) { dup2(fd, 1); dup2(fd, 2); close(fd); }
        }
        std::string cmd = std::string("\"") + exe + "\" " + args;
        execl("/bin/sh", "sh", "-c", cmd.c_str(), (char*)nullptr);
        _exit(127);
    }
    out.pid = pid;
    logAttached = (logPath && *logPath);
    return true;
#endif
}

// Non-blocking check. Returns true if still running; if it exited, `exitCode`
// receives its status.
static bool proc_is_running(ProcHandle& p, int& exitCode)
{
    exitCode = 0;
    if (!p.valid()) return false;
#ifdef _WIN32
    DWORD wr = WaitForSingleObject(p.h, 0);
    if (wr == WAIT_TIMEOUT) return true;
    DWORD code = 0;
    GetExitCodeProcess(p.h, &code);
    exitCode = (int)code;
    return false;
#else
    int st = 0;
    pid_t r = waitpid(p.pid, &st, WNOHANG);
    if (r == 0) return true;
    if (r < 0) return false;
    exitCode = WIFEXITED(st) ? WEXITSTATUS(st) : -1;
    return false;
#endif
}

static void proc_terminate(ProcHandle& p)
{
    if (!p.valid()) return;
#ifdef _WIN32
    TerminateProcess(p.h, 1);
    WaitForSingleObject(p.h, 2000);
#else
    kill(p.pid, SIGTERM);
    for (int i = 0; i < 20; ++i) {
        int st = 0;
        if (waitpid(p.pid, &st, WNOHANG) != 0) return;
        sleep_ms(100);
    }
    kill(p.pid, SIGKILL);
    int st = 0; waitpid(p.pid, &st, 0);
#endif
}

static void proc_close(ProcHandle& p)
{
#ifdef _WIN32
    if (p.h) { CloseHandle(p.h); p.h = nullptr; }
#else
    p.pid = -1;
#endif
}

// Detached launch — still used for 'open' and 'send', where we deliberately do
// not want to own or wait on the Praat GUI.
static bool run_detached(const char* cmd)
{
#ifdef _WIN32
    STARTUPINFOA si={}; si.cb=sizeof(si);
    PROCESS_INFORMATION pi={};
    std::vector<char> buf(cmd,cmd+strlen(cmd)+1);
    BOOL ok=CreateProcessA(nullptr,buf.data(),nullptr,nullptr,
                           FALSE,0,nullptr,nullptr,&si,&pi);
    if (ok) { CloseHandle(pi.hProcess); CloseHandle(pi.hThread); }
    return ok==TRUE;
#else
    std::string c=std::string(cmd)+" &";
    return system(c.c_str())==0;
#endif
}

// ═════════════════════════════════════════════════════════════════════════════
// SECTION 3 — Platform utilities
// ═════════════════════════════════════════════════════════════════════════════

static bool get_external_directory(char* buf, size_t bufSize)
{
#ifdef _WIN32
    HMODULE hMod=nullptr;
    GetModuleHandleExA(
        GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|
        GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
        (LPCSTR)&get_external_directory,&hMod);
    if (!GetModuleFileNameA(hMod,buf,(DWORD)bufSize)) return false;
    char* s=strrchr(buf,'\\'); if (!s) s=strrchr(buf,'/');
    if (s) *s='\0';
    return true;
#else
    Dl_info di;
    if (dladdr((void*)&get_external_directory,&di)&&di.dli_fname) {
        strncpy(buf,di.dli_fname,bufSize-1); buf[bufSize-1]='\0';
        char* sl=strrchr(buf,'/'); if(sl) *sl='\0';
        return true;
    }
    return false;
#endif
}

static std::string parent_path_copy(std::string p)
{
    while (p.size() > 1 && (p.back() == '/' || p.back() == '\\')) p.pop_back();
    size_t pos = p.find_last_of("/\\");
    if (pos == std::string::npos) return std::string();
    if (pos == 0) return std::string(1, p[0]);
    return p.substr(0, pos);
}

static std::string default_praat_executable(const char* externalBinaryDir)
{
#ifdef _WIN32
    return std::string(externalBinaryDir ? externalBinaryDir : "") + "\\Praat.exe";
#elif defined(__APPLE__)
    // dladdr() resolves the external binary directory as:
    //   <package>/externals/AudioTools.praat~.mxo/Contents/MacOS
    // The packaged Praat application is staged beside the .mxo bundle:
    //   <package>/externals/Praat.app/Contents/MacOS/Praat
    std::string binDir = externalBinaryDir ? externalBinaryDir : "";
    std::string contentsDir = parent_path_copy(binDir);
    std::string mxoDir = parent_path_copy(contentsDir);
    std::string externalsDir = parent_path_copy(mxoDir);
    std::string bundled = externalsDir + "/Praat.app/Contents/MacOS/Praat";
    if (!bundled.empty() && access(bundled.c_str(), X_OK) == 0) return bundled;

    // Development fallback: useful before package assembly when Praat is already
    // installed in the standard Applications folder. The assembled release
    // should resolve the bundled candidate above.
    const char* systemPraat = "/Applications/Praat.app/Contents/MacOS/Praat";
    if (access(systemPraat, X_OK) == 0) return std::string(systemPraat);
    return bundled;
#else
    return std::string(externalBinaryDir ? externalBinaryDir : "") + "/praat";
#endif
}

static std::string atoms_to_path(long argc, t_atom* argv)
{
    std::string path;
    for (long i=0; i<argc; ++i) {
        if (i>0) path += " ";
        switch (atom_gettype(argv+i)) {
            case A_SYM:
                path += atom_getsym(argv+i)->s_name;
                break;
            case A_LONG:
                path += std::to_string((long)atom_getlong(argv+i));
                break;
            case A_FLOAT:
                path += std::to_string(atom_getfloat(argv+i));
                break;
            default: break;
        }
    }
    while (!path.empty() &&
           (path.back()==' '||path.back()=='\t'||
            path.back()=='\r'||path.back()=='\n'))
        path.pop_back();
    return path;
}

// ═════════════════════════════════════════════════════════════════════════════
// SECTION 4 — Max/MSP object struct
// ═════════════════════════════════════════════════════════════════════════════

static t_class* s_AudioToolsPraat_class = nullptr;

enum { RESULT_OK = 0, RESULT_ERROR = 1, RESULT_CANCELLED = 2, RESULT_PARTIAL = 3 };

struct ParamSpec {
    std::string id;
    std::string label;
    std::string type;
    std::string defaultValue;
    std::string currentValue;
    std::string unit;
    std::string role;
    // v1.36: optional dialog-group and simple conditional-visibility metadata.
    // These affect only the Max descriptor UI; Praat variable semantics remain
    // unchanged. whenValue is either an option label or a scalar literal.
    std::string group;
    std::string whenParam;
    std::string whenValue;
    bool fromPause = false;
    bool hasMin = false, hasMax = false, hasStep = false;
    double minValue = 0.0, maxValue = 0.0, stepValue = 0.0;
    std::vector<std::string> options;
};

struct PresetSpec {
    std::string name;
    std::vector<std::pair<std::string,std::string>> values;
    std::string mappingSource; // metadata | legacy-inferred | legacy
};

struct OutputItem {
    std::string type;
    std::string path;
};

struct SafetyReport {
    bool allowed = true;
    std::vector<std::string> blockers;
    std::vector<std::string> warnings;
};

typedef struct _AudioToolsPraat {
    t_pxobject    ob;
    t_buffer_ref* inBufRef;
    t_buffer_ref* outBufRef;
    t_symbol*     inBufName;
    t_symbol*     outBufName;
    t_symbol*     scriptPath;
    void*         outlet;        // outlet 0 (left):  bang on success
    void*         errorOutlet;   // outlet 1: bang on error / timeout / stop
    void*         infoOutlet;    // outlet 2 (right): structured host messages
    void*         qelem;         // owned, cancellable main-thread notify

    char          exeDir[2048];
    char          praatExe[2048];

    // Per-instance workspace (P4). Manual send/receive use these stable paths.
    char          instDir[2048];
    char          wavIn[2048];
    char          wavOut[2048];
    char          runScript[2048];

    // Most recent run workspace, kept for [status] and for debug retention.
    char          lastRunDir[2048];

    long          instanceId;
    long          runCounter;
    unsigned long timeoutMs;
    bool          debugKeep;
    bool          visualEnabled;
    long          visualDpi;       // 150 screen mode, or native Praat 300/600
    bool          praatInfoCaptured;
    bool          fullTrust;       // Praat 7+: required for hosted file output; user can disable with [trust 0]
    bool          descriptorLoaded;

    // v7 host state. Heap allocation avoids relying on Max object_alloc to run
    // C++ constructors for STL members.
    std::vector<ParamSpec>* params;
    std::vector<PresetSpec>* presets;
    std::vector<std::string>* dependencies;
    std::vector<OutputItem>* pendingOutputs;
    std::vector<std::string>* pendingPraatInfo;
    std::string* scriptTitle;
    std::string* toolMode;          // auto|processor|generator|analyzer|browser
    std::string* outputStrategy;    // auto|host_save_selected_sound|script_managed|none
    std::string* safetyState;       // unknown|allow|block
    std::string* safetyReason;
    std::string* libraryRoot;
    std::string* pythonExe;
    std::string* pendingState;

    std::atomic<int>  result;        // RESULT_OK / RESULT_ERROR for the qelem
    std::atomic<bool> processing;
    std::atomic<bool> abort_flag;
    std::atomic<bool> quitting;      // FIX 6: set in free() before joining
    std::mutex        ioMutex;
    std::thread       worker;        // FIX 6: owned, joinable — never detached
} t_AudioToolsPraat;

// Forward declarations
void* AudioToolsPraat_new(t_symbol* s, long argc, t_atom* argv);
void  AudioToolsPraat_free(t_AudioToolsPraat* x);
void  AudioToolsPraat_bang(t_AudioToolsPraat* x);
void  AudioToolsPraat_send(t_AudioToolsPraat* x);
void  AudioToolsPraat_receive(t_AudioToolsPraat* x);
void  AudioToolsPraat_open(t_AudioToolsPraat* x);
void  AudioToolsPraat_stop(t_AudioToolsPraat* x);
void  AudioToolsPraat_status(t_AudioToolsPraat* x);
void  AudioToolsPraat_describe(t_AudioToolsPraat* x);
void  AudioToolsPraat_dump(t_AudioToolsPraat* x);
void  AudioToolsPraat_reset(t_AudioToolsPraat* x);
void  AudioToolsPraat_scan(t_AudioToolsPraat* x);
void  AudioToolsPraat_param(t_AudioToolsPraat* x, t_symbol* s, long argc, t_atom* argv);
void  AudioToolsPraat_preset(t_AudioToolsPraat* x, t_symbol* s, long argc, t_atom* argv);
void  AudioToolsPraat_mode(t_AudioToolsPraat* x, t_symbol* s, long argc, t_atom* argv);
void  AudioToolsPraat_strategy(t_AudioToolsPraat* x, t_symbol* s, long argc, t_atom* argv);
void  AudioToolsPraat_visual(t_AudioToolsPraat* x, t_symbol* s, long argc, t_atom* argv);
void  AudioToolsPraat_visualdpi(t_AudioToolsPraat* x, t_symbol* s, long argc, t_atom* argv);
void  AudioToolsPraat_trust(t_AudioToolsPraat* x, t_symbol* s, long argc, t_atom* argv);
void  AudioToolsPraat_library(t_AudioToolsPraat* x, t_symbol* s, long argc, t_atom* argv);
void  AudioToolsPraat_python(t_AudioToolsPraat* x, t_symbol* s, long argc, t_atom* argv);
void  AudioToolsPraat_debug(t_AudioToolsPraat* x, t_symbol* s, long argc, t_atom* argv);
void  AudioToolsPraat_timeout(t_AudioToolsPraat* x, t_symbol* s, long argc, t_atom* argv);
void  AudioToolsPraat_set(t_AudioToolsPraat* x, t_symbol* s, long argc, t_atom* argv);
void  AudioToolsPraat_script(t_AudioToolsPraat* x, t_symbol* s, long argc, t_atom* argv);
void  AudioToolsPraat_praatexe(t_AudioToolsPraat* x, t_symbol* s, long argc, t_atom* argv);
void  AudioToolsPraat_dsp64(t_AudioToolsPraat* x, t_object* dsp64, short* count,
                             double samplerate, long maxvectorsize, long flags);
void  AudioToolsPraat_perform64(t_AudioToolsPraat* x, t_object* dsp64,
                                 double** ins, long numins, double** outs, long numouts,
                                 long sampleframes, long flags, void* userparam);
t_max_err AudioToolsPraat_notify(t_AudioToolsPraat* x, t_symbol* s,
                                  t_symbol* msg, void* sender, void* data);
void  AudioToolsPraat_assist(t_AudioToolsPraat* x, void* b, long io, long index, char* s);
void  AudioToolsPraat_qfn(t_AudioToolsPraat* x);

// ── Result reporting (FIX 5 + FIX 6) ─────────────────────────────────────────
// Every worker exit path goes through here. A pending qelem is cancelled by
// qelem_unset() in free(), so a notification can never fire into freed memory.
static void finish_run(t_AudioToolsPraat* x, int result)
{
    x->result.store(result);
    x->processing.store(false);
    if (!x->quitting.load() && x->qelem)
        qelem_set(x->qelem);
}

static void info_message(t_AudioToolsPraat* x, const char* selector,
                         const std::vector<std::string>& values)
{
    if (!x->infoOutlet) return;
    std::vector<t_atom> atoms(values.size());
    for (size_t i=0;i<values.size();++i)
        atom_setsym(&atoms[i], gensym(values[i].c_str()));
    outlet_anything(x->infoOutlet, gensym(selector), (short)atoms.size(),
                    atoms.empty()?nullptr:atoms.data());
}

static void info_kv(t_AudioToolsPraat* x, const char* selector,
                    std::initializer_list<std::string> values)
{
    info_message(x, selector, std::vector<std::string>(values));
}

void AudioToolsPraat_qfn(t_AudioToolsPraat* x)
{
    if (x->pendingState && !x->pendingState->empty())
        info_kv(x, "state", {*x->pendingState});

    if (x->praatInfoCaptured && x->pendingPraatInfo) {
        info_message(x, "praat_info_begin", {});
        for (const auto& line : *x->pendingPraatInfo)
            info_kv(x, "praat_info_line", {line});
        info_message(x, "praat_info_end", {});
    }

    if (x->pendingOutputs) {
        for (const auto& o : *x->pendingOutputs)
            info_kv(x, "output", {o.type, o.path});
    }

    int r=x->result.load();
    if (r == RESULT_ERROR || r == RESULT_CANCELLED)
        outlet_bang(x->errorOutlet);
    else
        outlet_bang(x->outlet);
}

// Start a worker, taking ownership of the thread (FIX 6).
static void start_worker(t_AudioToolsPraat* x, void (*fn)(t_AudioToolsPraat*))
{
    if (x->worker.joinable()) x->worker.join();   // previous run already finished
    x->abort_flag.store(false);
    x->worker = std::thread(fn, x);
}

// ═════════════════════════════════════════════════════════════════════════════
// SECTION 5 — Workspace management (Phase 1, principle P4)
// ═════════════════════════════════════════════════════════════════════════════

static bool make_instance_workspace(t_AudioToolsPraat* x)
{
    char root[1024];
    if (!get_temp_root(root, sizeof(root))) return false;

    char base[1200];
    snprintf(base, sizeof(base), "%s%cAudioToolsPraat", root, DIRSEP);
    if (!make_dirs(base)) return false;

    snprintf(x->instDir, sizeof(x->instDir), "%s%cinst-%ld-%ld",
             base, DIRSEP, current_pid(), x->instanceId);
    if (!make_dirs(x->instDir)) return false;

    // Stable paths for the manual send/receive workflow.
    snprintf(x->wavIn,     sizeof(x->wavIn),     "%s%c_in.wav",    x->instDir, DIRSEP);
    snprintf(x->wavOut,    sizeof(x->wavOut),    "%s%c_out.wav",   x->instDir, DIRSEP);
    snprintf(x->runScript, sizeof(x->runScript), "%s%c_run.praat", x->instDir, DIRSEP);
    return true;
}

// Per-run subdirectory: <instDir>/run-<k>/  with outputs/ inside.
static bool make_run_workspace(t_AudioToolsPraat* x, long runId, char* outDir, size_t sz)
{
    snprintf(outDir, sz, "%s%crun-%ld", x->instDir, DIRSEP, runId);
    if (!make_dirs(outDir)) return false;
    char outputs[2100];
    snprintf(outputs, sizeof(outputs), "%s%coutputs", outDir, DIRSEP);
    return make_dirs(outputs);
}

// ═════════════════════════════════════════════════════════════════════════════
// SECTION 6 — Buffer export / import helpers
// ═════════════════════════════════════════════════════════════════════════════

static bool export_input_buffer(t_AudioToolsPraat* x, const char* destPath)
{
    t_buffer_obj* bufObj=buffer_ref_getobject(x->inBufRef);
    if (!bufObj) {
        object_error((t_object*)x,
            "AudioTools.praat~: input buffer '%s' not found.",
            x->inBufName->s_name);
        return false;
    }
    float* bufSamples=buffer_locksamples(bufObj);
    if (!bufSamples) {
        object_error((t_object*)x,
            "AudioTools.praat~: could not lock input buffer.");
        return false;
    }
    t_atom_long nFrames=buffer_getframecount(bufObj);
    t_atom_long nCh=buffer_getchannelcount(bufObj);
    double sr=buffer_getsamplerate(bufObj);
    std::vector<float> local(bufSamples,bufSamples+nFrames*nCh);
    buffer_unlocksamples(bufObj);

    if (nFrames<=0 || nCh<=0) {
        object_error((t_object*)x,
            "AudioTools.praat~: input buffer '%s' is empty (%d frames, %d ch).",
            x->inBufName->s_name,(int)nFrames,(int)nCh);
        return false;
    }

    if (!wav_write_float32(destPath,local.data(),
                           (uint32_t)nFrames,(uint16_t)nCh,(uint32_t)sr))
    {
        object_error((t_object*)x,
            "AudioTools.praat~: failed to write '%s'.",destPath);
        return false;
    }
    object_post((t_object*)x,
        "AudioTools.praat~: exported -> %s (%d frames, %d ch, %.0f Hz)",
        destPath,(int)nFrames,(int)nCh,sr);
    return true;
}

static bool import_output_buffer(t_AudioToolsPraat* x, const char* srcPath)
{
    WavInfo info={};
    float* wavData=wav_read_float32(srcPath,info);
    if (!wavData) {
        object_error((t_object*)x,
            "AudioTools.praat~: could not read '%s'.\n"
            "  File may be missing, corrupt, or an unsupported WAV format.\n"
            "  (supported: PCM 16/24/32-bit, IEEE float 32-bit, WAVE_FORMAT_EXTENSIBLE)",
            srcPath);
        return false;
    }
    t_buffer_obj* bufObj=buffer_ref_getobject(x->outBufRef);
    if (!bufObj) {
        object_error((t_object*)x,
            "AudioTools.praat~: output buffer '%s' not found.",
            x->outBufName->s_name);
        delete[] wavData; return false;
    }
    t_atom_long curFrames=buffer_getframecount(bufObj);
    // Only grow, never shrink. NOTE: this Sleep is still a race, not a fix —
    // sizeinsamps is deferred to Max's main thread. Doing the resize properly
    // (main-thread resize + completion handshake) is queued for Phase 1
    // hardening; it is left as-is here so this build differs from v1.24 in
    // exactly the six ways documented, and no more.
    if ((t_atom_long)info.nFrames > curFrames) {
        t_atom sizeArg;
        atom_setlong(&sizeArg,(t_atom_long)info.nFrames);
        object_method_typed(bufObj,gensym("sizeinsamps"),1,&sizeArg,nullptr);
        sleep_ms(50);
    }
    float* dest=buffer_locksamples(bufObj);
    if (!dest) {
        object_error((t_object*)x,
            "AudioTools.praat~: could not lock output buffer '%s'.",
            x->outBufName->s_name);
        delete[] wavData; return false;
    }
    t_atom_long dF=buffer_getframecount(bufObj);
    t_atom_long dC=buffer_getchannelcount(bufObj);
    t_atom_long cpF=((t_atom_long)info.nFrames<dF)?(t_atom_long)info.nFrames:dF;
    t_atom_long cpC=((t_atom_long)info.channels<dC)?(t_atom_long)info.channels:dC;
    memset(dest,0,(size_t)(dF*dC)*sizeof(float));
    for (t_atom_long fr=0;fr<cpF;++fr)
        for (t_atom_long ch=0;ch<cpC;++ch)
            dest[fr*dC+ch]=wavData[fr*info.channels+ch];
    buffer_unlocksamples(bufObj);
    buffer_setdirty(bufObj);
    delete[] wavData;

    object_post((t_object*)x,
        "AudioTools.praat~: imported -> '%s' (%d frames, %d ch, %d Hz)",
        x->outBufName->s_name,
        (int)info.nFrames,(int)info.channels,(int)info.sampleRate);

    // No longer silent: report what the destination could not represent.
    // Open decision D6 governs whether we should reconfigure the buffer here.
    if ((t_atom_long)info.channels > dC)
        object_warn((t_object*)x,
            "AudioTools.praat~: result has %d channels, buffer~ '%s' has %d — "
            "channels %d-%d were DISCARDED. Resize buffer~ to %d channels to keep them.",
            (int)info.channels, x->outBufName->s_name, (int)dC,
            (int)dC+1, (int)info.channels, (int)info.channels);
    if ((t_atom_long)info.nFrames > dF)
        object_warn((t_object*)x,
            "AudioTools.praat~: result is %d frames, buffer~ '%s' holds %d — "
            "%d frames were DISCARDED.",
            (int)info.nFrames, x->outBufName->s_name, (int)dF,
            (int)((t_atom_long)info.nFrames-dF));
    return true;
}

// ═════════════════════════════════════════════════════════════════════════════
// SECTION 7 — Form parsing, metadata, host state and Run Safety Gate
// ═════════════════════════════════════════════════════════════════════════════

namespace formparse {

static std::string toLower(std::string s) {
    for(char& c:s) c=(char)tolower((unsigned char)c);
    return s;
}
static std::string trim(const std::string& s) {
    size_t a=s.find_first_not_of(" \t\r\n");
    if(a==std::string::npos) return "";
    size_t b=s.find_last_not_of(" \t\r\n");
    return s.substr(a,b-a+1);
}
static std::string unquote(const std::string& s) {
    std::string t=trim(s);
    if(t.size()>=2 && t.front()=='"' && t.back()=='"')
        return t.substr(1,t.size()-2);
    return t;
}
static std::vector<std::string> splitWS(const std::string& s) {
    std::vector<std::string> out; std::string cur; bool q=false;
    for(char c:s) {
        if(c=='"') { q=!q; cur+=c; continue; }
        if(!q && (c==' '||c=='\t')) {
            if(!cur.empty()) { out.push_back(cur); cur.clear(); }
        } else cur+=c;
    }
    if(!cur.empty()) out.push_back(cur);
    return out;
}
static std::vector<std::string> splitComma(const std::string& s) {
    std::vector<std::string> out; std::string cur; bool q=false;
    for(char c:s) {
        if(c=='"') { q=!q; cur+=c; continue; }
        if(!q && c==',') { out.push_back(cur); cur.clear(); }
        else cur+=c;
    }
    out.push_back(cur);
    return out;
}
static std::string varName(const std::string& field) {
    std::string v=field;
    size_t p=v.find('(');
    if(p!=std::string::npos) v=v.substr(0,p);
    v=trim(v);
    std::string o;
    for(char c:v) {
        if(isalnum((unsigned char)c)) o+=c;
        else if(!o.empty() && o.back()!='_') o+='_';
    }
    while(!o.empty() && o.back()=='_') o.pop_back();
    if(!o.empty()) o[0]=(char)tolower((unsigned char)o[0]);
    return o;
}
static std::vector<std::string> words(const std::string& v) {
    std::vector<std::string> out; std::string cur;
    for(char c:toLower(v)) {
        if(c=='_') { if(!cur.empty()){out.push_back(cur);cur.clear();} }
        else cur+=c;
    }
    if(!cur.empty()) out.push_back(cur);
    return out;
}
static int force_role(const std::string& varname) {
    static const char* playbackWords[] = {
        "play","plays","playing","playback","audition","auditions","preview",
        "previews", nullptr
    };
    static const char* visualWords[] = {
        "draw","draws","drawing","visual","visuals","visualise","visualize",
        "visualisation","visualization","display","displays","picture",
        "pictures","plot","plots","graph","graphs", nullptr
    };
    std::vector<std::string> w=words(varname);
    for(const std::string& t:w)
        for(int i=0;playbackWords[i];++i) if(t==playbackWords[i]) return 1;
    for(const std::string& t:w)
        for(int i=0;visualWords[i];++i) if(t==visualWords[i]) return 2;
    return 0;
}
static std::vector<std::string> linesOf(const std::string& script) {
    std::vector<std::string> lines; std::string line;
    for(char c:script) {
        if(c=='\n') { lines.push_back(line); line.clear(); }
        else if(c!='\r') line+=c;
    }
    if(!line.empty()) lines.push_back(line);
    return lines;
}
static std::map<std::string,std::string> parseKV(const std::vector<std::string>& tok,
                                                 size_t start) {
    std::map<std::string,std::string> kv;
    for(size_t i=start;i<tok.size();++i) {
        size_t eq=tok[i].find('=');
        if(eq==std::string::npos) continue;
        kv[toLower(tok[i].substr(0,eq))]=unquote(tok[i].substr(eq+1));
    }
    return kv;
}
static bool parseDouble(const std::string& s,double& v) {
    char* e=nullptr; errno=0; v=strtod(s.c_str(),&e);
    return e && e!=s.c_str() && *e=='\0' && errno==0;
}
static std::string atomString(const t_atom* a) {
    if(atom_gettype(a)==A_SYM) return atom_getsym(a)->s_name;
    if(atom_gettype(a)==A_LONG) return std::to_string((long)atom_getlong(a));
    if(atom_gettype(a)==A_FLOAT) {
        char b[64]; snprintf(b,sizeof(b),"%.12g",(double)atom_getfloat(a)); return b;
    }
    return "";
}
static std::string atomsString(long argc,t_atom* argv,long start=0) {
    std::string s;
    for(long i=start;i<argc;++i) { if(i>start) s+=' '; s+=atomString(argv+i); }
    return s;
}
static bool fileExists(const std::string& p) {
    FILE* f=fopen(p.c_str(),"rb"); if(!f) return false; fclose(f); return true;
}
static bool pathParamNonEmpty(const std::vector<ParamSpec>& ps, const char* kind) {
    for(const auto& p:ps) {
        std::string t=toLower(p.type), id=toLower(p.id);
        if((t==kind || id.find(kind)!=std::string::npos) && !trim(p.currentValue).empty())
            return true;
    }
    return false;
}
static bool readPathNonEmpty(const std::vector<ParamSpec>& ps) {
    for(const auto& p:ps){std::string t=toLower(p.type),id=toLower(p.id);if(!trim(p.currentValue).empty()&&(t=="infile"||id.find("file")!=std::string::npos||id.find("input")!=std::string::npos||id.find("source")!=std::string::npos))return true;}return false;
}
static bool writePathNonEmpty(const std::vector<ParamSpec>& ps) {
    for(const auto& p:ps){std::string t=toLower(p.type),id=toLower(p.id);if(!trim(p.currentValue).empty()&&(t=="outfile"||id.find("output")!=std::string::npos||id.find("outfile")!=std::string::npos))return true;}return false;
}
static bool isPlaybackCommand(const std::string& line) {
    std::string t=toLower(trim(line));
    if(t.empty()||t[0]=='#') return false;
    if(t=="play") return true;
    if(t.rfind("play:",0)==0) return true;
    if(t.rfind("play ",0)==0 && t.find('=')==std::string::npos) return true;
    return false;
}
static std::string praatQuote(std::string s) {
    size_t p=0; while((p=s.find('"',p))!=std::string::npos){s.insert(p,"\"");p+=2;}
    return s;
}

} // namespace formparse

static bool read_whole_file(const char* path, std::string& out, int& err)
{
    err=0; FILE* f=fopen(path,"rb");
    if(!f) { err=errno; return false; }
    fseek(f,0,SEEK_END); long sz=ftell(f); fseek(f,0,SEEK_SET);
    if(sz<0) { fclose(f); err=EIO; return false; }
    out.assign((size_t)sz,'\0');
    size_t got = sz>0 ? fread(&out[0],1,(size_t)sz,f) : 0;
    fclose(f); out.resize(got); return true;
}

static ParamSpec* find_param(t_AudioToolsPraat* x,const std::string& id)
{
    if(!x->params) return nullptr;
    std::string key=formparse::toLower(formparse::varName(id));
    for(auto& p:*x->params)
        if(formparse::toLower(p.id)==key || formparse::toLower(p.label)==formparse::toLower(id))
            return &p;
    return nullptr;
}

static std::string strip_praat_inline_comment(const std::string& line)
{
    bool q=false;
    for(size_t i=0;i<line.size();++i) {
        if(line[i]=='"') q=!q;
        else if(line[i]=='#' && !q) return line.substr(0,i);
    }
    return line;
}

static std::string scalar_name(std::string s)
{
    using namespace formparse;
    s=trim(s);
    if(!s.empty() && s.back()=='$') s.pop_back();
    return varName(s);
}

static bool simple_assignment(const std::string& raw,std::string& lhs,std::string& rhs)
{
    using namespace formparse;
    std::string s=trim(strip_praat_inline_comment(raw));
    if(s.empty() || s[0]=='#') return false;
    size_t eq=s.find('=');
    if(eq==std::string::npos) return false;
    if(eq>0 && (s[eq-1]=='<'||s[eq-1]=='>'||s[eq-1]=='!')) return false;
    if(eq+1<s.size() && s[eq+1]=='=') return false;
    lhs=trim(s.substr(0,eq)); rhs=trim(s.substr(eq+1));
    if(lhs.empty()||rhs.empty()) return false;
    for(char c:lhs) if(!(isalnum((unsigned char)c)||c=='_'||c=='$')) return false;
    return true;
}

static bool identifier_rhs(const std::string& rhs,std::string& id)
{
    using namespace formparse;
    std::string t=trim(rhs);
    if(t.empty()) return false;
    // A numeric literal such as 44100 is not an identifier. Praat scalar
    // names begin with a letter or underscore; '$' is allowed only as the
    // string-variable suffix.
    if(!(isalpha((unsigned char)t[0]) || t[0]=='_')) return false;
    for(size_t i=0;i<t.size();++i) {
        const char c=t[i];
        if(isalnum((unsigned char)c)||c=='_') continue;
        if(c=='$' && i+1==t.size()) continue;
        return false;
    }
    id=scalar_name(t); return !id.empty();
}

// v1.36.1: beginPause fields may use a previously-defined scalar variable as
// their default, e.g. integer: "Sample rate (Hz)", sample_rate_Hz.  The host
// must resolve that value for the Max descriptor instead of emitting the
// symbolic expression before the script has defined it.
static bool resolve_prior_scalar_literal(const std::vector<std::string>& lines,
                                         int beforeLine,
                                         const std::string& id,
                                         std::string& out,
                                         int depth=0)
{
    using namespace formparse;
    if(depth>12) return false;
    const std::string key=toLower(scalar_name(id));
    if(key.empty()) return false;

    for(int i=(std::min)(beforeLine-1,(int)lines.size()-1); i>=0; --i) {
        std::string lhs,rhs;
        if(!simple_assignment(lines[i],lhs,rhs)) continue;
        if(toLower(scalar_name(lhs))!=key) continue;

        std::string t=trim(rhs);
        if(t.size()>=2 && t.front()=='"' && t.back()=='"') {
            out=unquote(t);
            return true;
        }
        double d=0;
        if(parseDouble(t,d)) {
            out=t;
            return true;
        }
        std::string low=toLower(t);
        if(low=="yes"||low=="true") { out="1"; return true; }
        if(low=="no"||low=="false") { out="0"; return true; }

        std::string ref;
        if(identifier_rhs(t,ref))
            return resolve_prior_scalar_literal(lines,i,ref,out,depth+1);
        return false;
    }
    return false;
}

static bool literal_for_param(const ParamSpec& p,const std::string& rhs,std::string& out)
{
    using namespace formparse;
    std::string t=trim(rhs);
    if(t.empty()) return false;
    if(t.size()>=2 && t.front()=='"' && t.back()=='"') {
        std::string q=unquote(t);
        if(p.type=="choice"||p.type=="optionmenu") {
            for(size_t i=0;i<p.options.size();++i)
                if(toLower(p.options[i])==toLower(q)) { out=std::to_string(i+1); return true; }
            return false;
        }
        out=q; return true;
    }
    std::string low=toLower(t);
    if(p.type=="boolean") {
        if(low=="yes"||low=="true") { out="1"; return true; }
        if(low=="no"||low=="false") { out="0"; return true; }
    }
    double d=0;
    if(parseDouble(t,d)) {
        if((p.type=="choice"||p.type=="optionmenu") && (d<1 || d>(double)p.options.size())) return false;
        out=t; return true;
    }
    return false;
}

static bool preset_condition(const std::string& raw,const std::string& presetId,int& index,bool& isElsif)
{
    using namespace formparse;
    std::string s=trim(strip_praat_inline_comment(raw));
    std::string low=toLower(s); isElsif=false;
    size_t off=std::string::npos;
    if(low.rfind("elsif ",0)==0) { off=6; isElsif=true; }
    else if(low.rfind("elseif ",0)==0) { off=7; isElsif=true; }
    else if(low.rfind("if ",0)==0) off=3;
    else return false;
    std::string expr=trim(s.substr(off));
    std::string exprLow=toLower(expr);
    if(exprLow.size()>=4 && exprLow.substr(exprLow.size()-4)=="then") expr=trim(expr.substr(0,expr.size()-4));
    size_t eq=expr.find('='); if(eq==std::string::npos) return false;
    std::string left=scalar_name(expr.substr(0,eq));
    std::string right=trim(expr.substr(eq+1));
    if(!right.empty() && right[0]=='=') right=trim(right.substr(1));
    if(toLower(left)!=toLower(presetId)) return false;
    char* e=nullptr; long n=strtol(right.c_str(),&e,10);
    if(!e||e==right.c_str()) return false;
    while(*e && isspace((unsigned char)*e)) ++e;
    if(*e!='\0' || n<1) return false;
    index=(int)n; return true;
}

static int manual_or_custom_preset_index(t_AudioToolsPraat* x)
{
    using namespace formparse;
    if(!x->presets) return 0;
    int custom=0;
    for(size_t i=0;i<x->presets->size();++i) {
        std::string n=toLower(trim((*x->presets)[i].name));
        if(n=="manual" || n.find("manual")!=std::string::npos) return (int)i+1;
        if(custom==0 && (n=="custom" || n.find("custom")!=std::string::npos)) custom=(int)i+1;
    }
    return custom;
}

static void infer_legacy_preset_mappings(t_AudioToolsPraat* x,const std::vector<std::string>& lines)
{
    using namespace formparse;
    ParamSpec* presetParam=find_param(x,"preset");
    if(!presetParam || x->presets->empty()) return;
    const std::string presetId=presetParam->id;

    // Resolve simple aliases declared before the preset block, e.g.
    // pitch_scatter = varispeed_scatter_semitones.
    std::map<std::string,std::string> aliases;
    bool seenPreset=false;
    for(const auto& raw:lines) {
        int pi=0; bool ei=false;
        if(preset_condition(raw,presetId,pi,ei)) { seenPreset=true; break; }
        if(seenPreset) break;
        std::string lhs,rhs,rid;
        if(!simple_assignment(raw,lhs,rhs) || !identifier_rhs(rhs,rid)) continue;
        ParamSpec* src=find_param(x,rid);
        std::string target;
        if(src) target=src->id;
        else {
            auto it=aliases.find(toLower(rid)); if(it!=aliases.end()) target=it->second;
        }
        if(!target.empty()) aliases[toLower(scalar_name(lhs))]=target;
    }

    int depth=0,activePreset=0,presetDepth=0;
    for(const auto& raw:lines) {
        std::string t=trim(strip_praat_inline_comment(raw));
        if(t.empty()) continue;
        std::string low=toLower(t);
        int idx=0; bool isElsif=false;
        bool isPresetCond=preset_condition(raw,presetId,idx,isElsif);

        if(low.rfind("if ",0)==0) {
            ++depth;
            if(isPresetCond) { activePreset=idx; presetDepth=depth; }
            continue;
        }
        if(low.rfind("elsif ",0)==0 || low.rfind("elseif ",0)==0) {
            if(activePreset && depth==presetDepth) activePreset=0;
            if(isPresetCond) { activePreset=idx; presetDepth=depth; }
            continue;
        }
        if(low=="else" || low.rfind("else ",0)==0) {
            if(activePreset && depth==presetDepth) activePreset=0;
            continue;
        }
        if(low=="endif" || low.rfind("endif ",0)==0) {
            if(activePreset && depth==presetDepth) activePreset=0;
            if(depth>0) --depth;
            continue;
        }
        if(activePreset<1 || activePreset>(int)x->presets->size() || depth!=presetDepth) continue;

        PresetSpec& pr=(*x->presets)[activePreset-1];
        if(pr.mappingSource=="metadata") continue; // explicit metadata wins
        std::string lhs,rhs;
        if(!simple_assignment(raw,lhs,rhs)) continue;
        std::string lhsId=scalar_name(lhs),targetId;
        ParamSpec* target=find_param(x,lhsId);
        if(target) targetId=target->id;
        else {
            auto ai=aliases.find(toLower(lhsId)); if(ai!=aliases.end()) targetId=ai->second;
            if(!targetId.empty()) target=find_param(x,targetId);
        }
        if(!target || targetId==presetId) continue;
        std::string value;
        if(!literal_for_param(*target,rhs,value)) continue;
        bool replaced=false;
        for(auto& kv:pr.values) if(toLower(kv.first)==toLower(targetId)) { kv.second=value; replaced=true; break; }
        if(!replaced) pr.values.push_back({targetId,value});
        pr.mappingSource="legacy-inferred";
    }
}

// ---------------------------------------------------------------------------
// v1.36 headless Pause virtualization
// ---------------------------------------------------------------------------

struct PauseBlockInfo {
    int startLine = -1;
    int endLine = -1;
    std::string title;
    std::string whenParam;
    std::string whenValue;
    bool virtualizable = true;
    std::string blocker;
    bool endAssigned = false;
    std::string endTarget;
    int defaultButton = 1;
    std::vector<std::string> buttons;
};

struct PauseConditionFrame {
    bool simple = false;
    std::string param;
    std::string value;
};

static std::string leading_command(const std::string& raw)
{
    using namespace formparse;
    std::string t=trim(strip_praat_inline_comment(raw));
    size_t n=0;
    while(n<t.size() && isalpha((unsigned char)t[n])) ++n;
    return toLower(t.substr(0,n));
}

static bool parse_simple_pause_condition(const std::string& raw,
                                         std::string& param,
                                         std::string& value)
{
    using namespace formparse;
    std::string s=trim(strip_praat_inline_comment(raw));
    std::string low=toLower(s);
    size_t off=std::string::npos;
    if(low.rfind("if ",0)==0) off=3;
    else if(low.rfind("elsif ",0)==0) off=6;
    else if(low.rfind("elseif ",0)==0) off=7;
    else return false;

    std::string expr=trim(s.substr(off));
    std::string elow=toLower(expr);
    if(elow.size()>=4 && elow.substr(elow.size()-4)=="then")
        expr=trim(expr.substr(0,expr.size()-4));

    size_t eq=expr.find('=');
    if(eq==std::string::npos) {
        // Common advanced-dialog idiom: if edit_details ... beginPause ...
        // Treat a bare scalar as a boolean visibility condition.
        std::string lhs=trim(expr);
        bool neg=false;
        std::string ll=toLower(lhs);
        if(ll.rfind("not ",0)==0) { neg=true; lhs=trim(lhs.substr(4)); }
        if(lhs.empty()) return false;
        if(!(isalpha((unsigned char)lhs[0]) || lhs[0]=='_')) return false;
        for(size_t i=0;i<lhs.size();++i) {
            const char c=lhs[i];
            if(isalnum((unsigned char)c)||c=='_') continue;
            if(c=='$' && i+1==lhs.size()) continue;
            return false;
        }
        param=scalar_name(lhs);
        if(param.empty()) return false;
        value=neg?"0":"1";
        return true;
    }
    if(eq>0 && (expr[eq-1]=='<'||expr[eq-1]=='>'||expr[eq-1]=='!')) return false;
    if(eq+1<expr.size() && expr[eq+1]=='=') return false;

    std::string lhs=trim(expr.substr(0,eq));
    std::string rhs=trim(expr.substr(eq+1));
    if(lhs.empty()||rhs.empty()) return false;

    // Only a scalar variable may control conditional UI.
    for(char c:lhs)
        if(!(isalnum((unsigned char)c)||c=='_'||c=='$')) return false;

    param=scalar_name(lhs);
    if(param.empty()) return false;

    if(rhs.size()>=2 && rhs.front()=='"' && rhs.back()=='"') {
        value=unquote(rhs);
        return true;
    }
    double d=0;
    if(parseDouble(rhs,d)) {
        value=rhs;
        return true;
    }
    return false;
}

static bool parse_endpause_line(const std::string& raw,
                                bool& assigned,
                                std::string& target,
                                std::vector<std::string>& buttons,
                                int& defaultButton)
{
    using namespace formparse;
    assigned=false; target.clear(); buttons.clear(); defaultButton=1;
    std::string s=trim(strip_praat_inline_comment(raw));
    std::string low=toLower(s);
    size_t p=low.find("endpause");
    if(p==std::string::npos) return false;

    // If endPause is the RHS of a scalar assignment, preserve the result by
    // replacing it with the selected default-button index in the run script.
    size_t eq=s.find('=');
    if(eq!=std::string::npos && eq<p) {
        std::string lhs=trim(s.substr(0,eq));
        bool ok=!lhs.empty();
        for(char c:lhs) if(!(isalnum((unsigned char)c)||c=='_'||c=='$')) ok=false;
        if(ok) { assigned=true; target=lhs; }
    }

    size_t colon=s.find(':',p);
    if(colon==std::string::npos) return true;
    auto parts=splitComma(s.substr(colon+1));
    if(parts.empty()) return true;

    // Praat endPause uses the final integer as the default/continue button.
    std::string last=trim(parts.back());
    char* e=nullptr; long n=strtol(last.c_str(),&e,10);
    if(e && e!=last.c_str()) {
        while(*e && isspace((unsigned char)*e)) ++e;
        if(*e=='\0' && n>=1) {
            defaultButton=(int)n;
            parts.pop_back();
        }
    }
    for(const auto& part:parts) {
        std::string q=unquote(trim(part));
        if(!q.empty()) buttons.push_back(q);
    }
    return true;
}

static std::vector<PauseBlockInfo> analyze_pause_blocks(const std::string& script)
{
    using namespace formparse;
    auto lines=linesOf(script);
    std::vector<PauseBlockInfo> out;
    std::vector<PauseConditionFrame> cond;
    int loopDepth=0,procDepth=0;

    for(int i=0;i<(int)lines.size();++i) {
        std::string t=trim(strip_praat_inline_comment(lines[i]));
        if(t.empty()) continue;
        std::string low=toLower(t);
        std::string head=leading_command(lines[i]);

        if(head=="beginpause") {
            PauseBlockInfo pb;
            pb.startLine=i;

            size_t colon=t.find(':');
            std::string rest=(colon==std::string::npos)?trim(t.substr(std::string("beginPause").size())):trim(t.substr(colon+1));
            auto titleParts=splitComma(rest);
            if(!titleParts.empty()) pb.title=unquote(trim(titleParts[0]));
            if(pb.title.empty()) pb.title="Praat Pause";

            // Runtime repetition cannot be represented by a one-shot parameter
            // surface. These remain blocked until a future suspend/resume host.
            if(loopDepth>0 || procDepth>0) {
                pb.virtualizable=false;
                pb.blocker="interactive-runtime: Pause inside loop/procedure requires suspend/resume host support";
            }

            // For UI visibility, expose the innermost simple equality only when
            // it is unambiguous. Complex conditions remain valid but are shown
            // unconditionally in Max; their Praat branch still controls usage.
            if(cond.size()==1 && cond.back().simple) {
                pb.whenParam=cond.back().param;
                pb.whenValue=cond.back().value;
            }

            int j=i+1;
            bool foundEnd=false;
            for(;j<(int)lines.size();++j) {
                bool assigned=false; std::string target; std::vector<std::string> buttons; int def=1;
                if(parse_endpause_line(lines[j],assigned,target,buttons,def)) {
                    pb.endLine=j; pb.endAssigned=assigned; pb.endTarget=target;
                    pb.buttons=buttons; pb.defaultButton=def; foundEnd=true; break;
                }
            }
            if(!foundEnd) {
                pb.virtualizable=false;
                pb.blocker="interactive-runtime: beginPause has no matching endPause";
                pb.endLine=i;
            }

            // Do not silently remove a dialog field whose Praat variable shape
            // the host cannot reproduce. Unsupported Pause field types remain a
            // Safety Gate blocker instead of becoming an undefined variable.
            if(foundEnd && pb.virtualizable) {
                for(int k=pb.startLine+1;k<pb.endLine;++k) {
                    std::string ft=trim(strip_praat_inline_comment(lines[k]));
                    if(ft.empty()) continue;
                    std::string fh=leading_command(lines[k]);
                    if(fh.empty()) continue;
                    const bool supported=(fh=="comment"||fh=="option"||fh=="button"||
                        fh=="sentence"||fh=="text"||fh=="word"||fh=="infile"||
                        fh=="outfile"||fh=="folder"||fh=="real"||fh=="positive"||
                        fh=="integer"||fh=="natural"||fh=="boolean"||fh=="choice"||
                        fh=="optionmenu");
                    if(!supported) {
                        pb.virtualizable=false;
                        pb.blocker="interactive-runtime: Pause field type '"+fh+"' is not yet virtualized";
                        break;
                    }
                }
            }
            out.push_back(pb);
            i=pb.endLine;
            continue;
        }

        // Maintain only the control context outside Pause blocks.
        if(head=="if") {
            PauseConditionFrame f;
            f.simple=parse_simple_pause_condition(lines[i],f.param,f.value);
            cond.push_back(f);
        } else if(head=="elsif" || head=="elseif") {
            if(!cond.empty()) {
                PauseConditionFrame f;
                f.simple=parse_simple_pause_condition(lines[i],f.param,f.value);
                cond.back()=f;
            }
        } else if(head=="else") {
            if(!cond.empty()) cond.back()=PauseConditionFrame();
        } else if(head=="endif") {
            if(!cond.empty()) cond.pop_back();
        } else if(head=="for" || head=="while" || head=="repeat") {
            ++loopDepth;
        } else if(head=="endfor" || head=="endwhile" || head=="until") {
            if(loopDepth>0) --loopDepth;
        } else if(head=="procedure") {
            ++procDepth;
        } else if(head=="endproc" || head=="endprocedure") {
            if(procDepth>0) --procDepth;
        }
    }
    return out;
}

static bool param_id_exists(const std::vector<ParamSpec>& ps,const std::string& id)
{
    const std::string key=formparse::toLower(id);
    for(const auto& p:ps) if(formparse::toLower(p.id)==key) return true;
    return false;
}

static bool parse_script_descriptor(t_AudioToolsPraat* x,const std::string& script,
                                    bool resetValues,std::string& err)
{
    using namespace formparse;
    std::vector<ParamSpec> parsed;
    std::vector<PresetSpec> metaPresets;
    std::vector<std::string> deps;
    std::string title="Praat Tool", metaMode="", metaStrategy="";
    auto lines=linesOf(script);

    // Metadata comments are deliberately simple and valid Praat comments.
    std::map<std::string,std::map<std::string,std::string>> paramMeta;
    for(const auto& raw:lines) {
        std::string t=trim(raw);
        if(t.rfind("#@",0)!=0) continue;
        auto tok=splitWS(t.substr(2)); if(tok.empty()) continue;
        std::string cmd=toLower(tok[0]);
        if(cmd=="tool") {
            auto kv=parseKV(tok,1);
            if(kv.count("mode")) metaMode=toLower(kv["mode"]);
            if(kv.count("output")) metaStrategy=toLower(kv["output"]);
            if(kv.count("title")) title=kv["title"];
        } else if(cmd=="output") {
            auto kv=parseKV(tok,1);
            if(kv.count("strategy")) metaStrategy=toLower(kv["strategy"]);
        } else if(cmd=="param" && tok.size()>=2) {
            paramMeta[toLower(varName(unquote(tok[1])))]=parseKV(tok,2);
        } else if(cmd=="preset" && tok.size()>=2) {
            PresetSpec pr; pr.name=unquote(tok[1]); pr.mappingSource="metadata";
            auto kv=parseKV(tok,2);
            for(const auto& e:kv) pr.values.push_back({varName(e.first),e.second});
            metaPresets.push_back(pr);
        } else if(cmd=="requires" || cmd=="requires-python" || cmd=="requires_python") {
            deps.push_back(cmd + " " + trim(t.substr(2+tok[0].size())));
        }
    }

    int formStart=-1,formEnd=-1;
    for(int i=0;i<(int)lines.size();++i) {
        std::string t=trim(lines[i]); if(t.empty()) continue;
        std::string tl=toLower(t),head;
        size_t n=0; while(n<tl.size()&&isalpha((unsigned char)tl[n])) head+=tl[n++];
        if(formStart<0 && head=="form") {
            formStart=i;
            std::string rest=trim(t.substr(n)); if(!rest.empty()&&rest[0]==':') rest=trim(rest.substr(1));
            if(!rest.empty()) title=unquote(rest);
            continue;
        }
        if(formStart>=0 && i>formStart && head=="endform") { formEnd=i; break; }
    }

    if(formStart>=0 && formEnd>formStart) {
        ParamSpec* activeChoice=nullptr;
        for(int i=formStart+1;i<formEnd;++i) {
            std::string t=trim(lines[i]);
            if(t.empty()||t[0]=='#') continue;
            size_t tlen=0; while(tlen<t.size()&&isalpha((unsigned char)t[tlen])) ++tlen;
            if(tlen==0) continue;
            bool colon=(tlen<t.size()&&t[tlen]==':');
            std::string type=toLower(t.substr(0,tlen));
            std::string rest=trim(t.substr(tlen+(colon?1:0)));
            if(type=="comment") continue;
            if(type=="option"||type=="button") {
                if(activeChoice) activeChoice->options.push_back(unquote(rest));
                continue;
            }
            activeChoice=nullptr;
            std::string rawName,defVal;
            if(colon) {
                auto parts=splitComma(rest); if(parts.empty()) continue;
                rawName=unquote(parts[0]);
                for(size_t j=1;j<parts.size();++j){if(j>1)defVal+=",";defVal+=parts[j];}
                defVal=trim(defVal);
            } else {
                auto tok=splitWS(t); if(tok.size()<2) continue;
                rawName=unquote(tok[1]); if(!rawName.empty()&&rawName.back()==':')rawName.pop_back();
                for(size_t j=2;j<tok.size();++j){if(j>2)defVal+=' ';defVal+=tok[j];}
            }
            if(type!="sentence"&&type!="text"&&type!="word"&&type!="infile"&&
               type!="outfile"&&type!="folder"&&type!="real"&&type!="positive"&&
               type!="integer"&&type!="natural"&&type!="boolean"&&
               type!="choice"&&type!="optionmenu") continue;
            ParamSpec p; p.id=varName(rawName); if(p.id.empty()) continue;
            p.label=rawName; p.type=type; p.defaultValue=unquote(defVal);
            if(type=="real"||type=="positive"||type=="integer"||type=="natural"||type=="boolean"||type=="choice"||type=="optionmenu") {
                auto dv=splitWS(p.defaultValue); if(!dv.empty()) p.defaultValue=unquote(dv[0]);
            }
            if(p.defaultValue.empty()) {
                if(type=="choice"||type=="optionmenu") p.defaultValue="1";
                else if(type=="boolean"||type=="real"||type=="positive"||type=="integer"||type=="natural") p.defaultValue="0";
            }
            p.currentValue=p.defaultValue;
            int fr=force_role(p.id); if(fr==1)p.role="praat-playback"; else if(fr==2)p.role="visual";
            auto mi=paramMeta.find(toLower(p.id));
            if(mi!=paramMeta.end()) {
                auto& kv=mi->second; double d=0;
                if(kv.count("type")) p.type=toLower(kv["type"]);
                if(kv.count("unit")) p.unit=kv["unit"];
                if(kv.count("role")) p.role=toLower(kv["role"]);
                if(kv.count("min")&&parseDouble(kv["min"],d)){p.hasMin=true;p.minValue=d;}
                if(kv.count("max")&&parseDouble(kv["max"],d)){p.hasMax=true;p.maxValue=d;}
                if(kv.count("step")&&parseDouble(kv["step"],d)){p.hasStep=true;p.stepValue=d;}
            }
            parsed.push_back(p);
            if(type=="choice"||type=="optionmenu") activeChoice=&parsed.back();
        }
    }

    // v1.36: parse virtualizable beginPause/endPause dialogs as additional
    // host parameters. This does not execute or delete any Praat DSP logic;
    // it only moves dialog-owned variables into the same persistent state used
    // by ordinary form parameters.
    auto pauseBlocks=analyze_pause_blocks(script);
    if(formStart<0 && title=="Praat Tool") {
        for(const auto& pb:pauseBlocks) if(pb.virtualizable && !pb.title.empty()) { title=pb.title; break; }
    }
    for(const auto& pb:pauseBlocks) {
        if(!pb.virtualizable || pb.endLine<=pb.startLine) continue;
        ParamSpec* activeChoice=nullptr;
        for(int i=pb.startLine+1;i<pb.endLine;++i) {
            std::string t=trim(lines[i]);
            if(t.empty()||t[0]=='#') continue;
            size_t tlen=0; while(tlen<t.size()&&isalpha((unsigned char)t[tlen])) ++tlen;
            if(tlen==0) continue;
            bool colon=(tlen<t.size()&&t[tlen]==':');
            std::string type=toLower(t.substr(0,tlen));
            std::string rest=trim(t.substr(tlen+(colon?1:0)));
            if(type=="comment") continue;
            if(type=="option"||type=="button") {
                if(activeChoice) activeChoice->options.push_back(unquote(rest));
                continue;
            }
            activeChoice=nullptr;
            std::string rawName,defVal;
            if(colon) {
                auto parts=splitComma(rest); if(parts.empty()) continue;
                rawName=unquote(parts[0]);
                for(size_t j=1;j<parts.size();++j){if(j>1)defVal+=",";defVal+=parts[j];}
                defVal=trim(defVal);
            } else {
                auto tok=splitWS(t); if(tok.size()<2) continue;
                rawName=unquote(tok[1]); if(!rawName.empty()&&rawName.back()==':')rawName.pop_back();
                for(size_t j=2;j<tok.size();++j){if(j>2)defVal+=' ';defVal+=tok[j];}
            }
            if(type!="sentence"&&type!="text"&&type!="word"&&type!="infile"&&
               type!="outfile"&&type!="folder"&&type!="real"&&type!="positive"&&
               type!="integer"&&type!="natural"&&type!="boolean"&&
               type!="choice"&&type!="optionmenu") continue;
            std::string defaultRefId;
            const bool defaultIsIdentifier=identifier_rhs(defVal,defaultRefId);
            ParamSpec p; p.id=defaultIsIdentifier?defaultRefId:varName(rawName); if(p.id.empty()) continue;
            if(param_id_exists(parsed,p.id)) {
                // Repeated Pause fields share the same Praat variable. Keep the
                // first descriptor instead of creating two competing controls.
                continue;
            }
            p.label=rawName; p.type=type; p.defaultValue=unquote(defVal);
            if(type=="real"||type=="positive"||type=="integer"||type=="natural"||type=="boolean"||type=="choice"||type=="optionmenu") {
                auto dv=splitWS(p.defaultValue); if(!dv.empty()) p.defaultValue=unquote(dv[0]);
            }
            if(defaultIsIdentifier) {
                std::string resolved;
                if(resolve_prior_scalar_literal(lines,pb.startLine,defaultRefId,resolved))
                    p.defaultValue=resolved;
            }
            if(p.defaultValue.empty()) {
                if(type=="choice"||type=="optionmenu") p.defaultValue="1";
                else if(type=="boolean"||type=="real"||type=="positive"||type=="integer"||type=="natural") p.defaultValue="0";
            }
            p.currentValue=p.defaultValue;
            p.group=pb.title; p.whenParam=pb.whenParam; p.whenValue=pb.whenValue; p.fromPause=true;
            int fr=force_role(p.id); if(fr==1)p.role="praat-playback"; else if(fr==2)p.role="visual";
            auto mi=paramMeta.find(toLower(p.id));
            if(mi!=paramMeta.end()) {
                auto& kv=mi->second; double d=0;
                if(kv.count("type")) p.type=toLower(kv["type"]);
                if(kv.count("unit")) p.unit=kv["unit"];
                if(kv.count("role")) p.role=toLower(kv["role"]);
                if(kv.count("min")&&parseDouble(kv["min"],d)){p.hasMin=true;p.minValue=d;}
                if(kv.count("max")&&parseDouble(kv["max"],d)){p.hasMax=true;p.maxValue=d;}
                if(kv.count("step")&&parseDouble(kv["step"],d)){p.hasStep=true;p.stepValue=d;}
            }
            parsed.push_back(p);
            if(type=="choice"||type=="optionmenu") activeChoice=&parsed.back();
        }
    }

    // Preserve current values when re-describing the same script unless reset was requested.
    if(!resetValues && x->params) {
        for(auto& p:parsed) {
            for(const auto& old:*x->params) if(toLower(old.id)==toLower(p.id)) {
                p.currentValue=old.currentValue; break;
            }
        }
    }

    *x->params=parsed;
    *x->presets=metaPresets;
    *x->dependencies=deps;
    *x->scriptTitle=title;
    if(!metaMode.empty()) *x->toolMode=metaMode;
    if(!metaStrategy.empty()) *x->outputStrategy=metaStrategy;

    // A form parameter named Preset is itself a useful legacy preset catalogue.
    // Keep catalogue order identical to the optionmenu indices even when some
    // entries also have #@preset metadata.
    ParamSpec* pp=find_param(x,"preset");
    if(pp && (pp->type=="choice"||pp->type=="optionmenu")) {
        std::vector<PresetSpec> ordered;
        for(const auto& name:pp->options) {
            bool found=false;
            for(const auto& pr:*x->presets) if(toLower(pr.name)==toLower(name)) { ordered.push_back(pr); found=true; break; }
            if(!found) { PresetSpec pr; pr.name=name; pr.mappingSource="legacy"; ordered.push_back(pr); }
        }
        for(const auto& pr:*x->presets) {
            bool exists=false; for(const auto& q:ordered) if(toLower(q.name)==toLower(pr.name)) {exists=true;break;}
            if(!exists) ordered.push_back(pr);
        }
        *x->presets=ordered;
    }
    infer_legacy_preset_mappings(x,lines);
    x->descriptorLoaded=true; err.clear(); return true;
}

static SafetyReport scan_script(t_AudioToolsPraat* x,const std::string& script)
{
    using namespace formparse;
    SafetyReport r; std::string low=toLower(script);
    auto block=[&](const std::string& s){r.allowed=false;r.blockers.push_back(s);};
    auto pauseBlocks=analyze_pause_blocks(script);
    int virtualizedPauses=0;
    for(const auto& pb:pauseBlocks) {
        if(pb.virtualizable) {
            ++virtualizedPauses;
            if(pb.endAssigned)
                r.warnings.push_back("pause virtualization: '"+pb.title+"' assigns endPause; headless run will select declared default button "+std::to_string(pb.defaultButton));
        } else {
            block(pb.blocker.empty()?"interactive-runtime: Pause cannot be virtualized safely":pb.blocker);
        }
    }
    if(virtualizedPauses>0)
        r.warnings.push_back("pause virtualization: "+std::to_string(virtualizedPauses)+" beginPause/endPause dialog(s) moved to host state");
    if(low.find("pausescript")!=std::string::npos)
        block("interactive-runtime: pauseScript is unsupported in headless host mode");
    if(low.find("choosefolder$")!=std::string::npos && !pathParamNonEmpty(*x->params,"folder"))
        block("chooser: chooseFolder$ is unresolved; set a folder parameter before run");
    if(low.find("choosereadfile$")!=std::string::npos && !readPathNonEmpty(*x->params))
        block("chooser: chooseReadFile$ is unresolved; set an input/file/source parameter before run");
    if(low.find("choosewritefile$")!=std::string::npos && !writePathNonEmpty(*x->params))
        block("chooser: chooseWriteFile$ is unresolved; set an output parameter before run");
    if(low.find("choosefolder$")!=std::string::npos && pathParamNonEmpty(*x->params,"folder"))
        r.warnings.push_back("chooseFolder$ present but a host folder value is supplied; fallback is expected to be unreachable");
    if(!x->dependencies->empty())
        r.warnings.push_back("script declares external dependencies; use [describe] to inspect them before distribution");
    if(*x->outputStrategy=="auto")
        r.warnings.push_back("legacy output strategy is being inferred; add #@output strategy=... for a fully-hosted script");
    return r;
}

static bool resolve_requires_sound(const std::string& script,const std::string& effectiveMode)
{
    using namespace formparse;
    std::string compact;
    compact.reserve(script.size());
    for(char c:toLower(script)) if(!isspace((unsigned char)c)) compact+=c;

    // Strong legacy signal: the script explicitly validates/queries the current
    // Sound selection before doing its work. This is independent of whether the
    // tool is musically a processor, generator, analyzer, etc.
    if(compact.find("numberofselected(\"sound\")")!=std::string::npos ||
       compact.find("numberofselected('sound')")!=std::string::npos)
        return true;

    std::string m=toLower(effectiveMode);
    if(m=="processor" || m=="analyzer") return true;
    return false;
}

static std::string resolve_strategy(t_AudioToolsPraat* x,const std::string& script,const std::string& effectiveMode)
{
    using namespace formparse;
    std::string st=toLower(*x->outputStrategy);
    if(st!="auto" && !st.empty()) return st;
    std::string low=toLower(script);
    if(low.find("{{out}}")!=std::string::npos || low.find("{{manifest}}")!=std::string::npos)
        return "script_managed";
    for(const auto& p:*x->params) if(p.type=="outfile") return "script_managed";
    if(toLower(effectiveMode)=="analyzer") return "none";
    return "host_save_selected_sound";
}

static std::string resolve_mode(t_AudioToolsPraat* x,const std::string& script)
{
    using namespace formparse;
    std::string m=toLower(*x->toolMode); if(m.empty())m="auto";
    if(m!="auto") return m;
    std::string low=toLower(script), title=toLower(*x->scriptTitle);
    bool hasFolder=false,hasInput=false;
    for(const auto&p:*x->params){std::string id=toLower(p.id);if(p.type=="folder"||id=="folder"||id.find("folder")!=std::string::npos)hasFolder=true;if(p.type=="infile"||id.find("input")!=std::string::npos||id.find("source")!=std::string::npos)hasInput=true;}
    if(hasFolder && (title.find("browser")!=std::string::npos || low.find("choosefolder$")!=std::string::npos)) return "browser";
    if(!hasInput && low.find("create sound")!=std::string::npos && low.find("read from file")==std::string::npos) return "generator";
    return "processor";
}

static bool write_manifest_outputs(t_AudioToolsPraat* x,const char* manifestPath)
{
    std::ifstream f(manifestPath); if(!f.good()) return false;
    std::string line; bool any=false;
    while(std::getline(f,line)) {
        line=formparse::trim(line); if(line.empty()||line[0]=='#') continue;
        std::istringstream is(line); std::string type; is>>type; std::string path; std::getline(is,path);
        path=formparse::trim(path); if(type.empty()||path.empty()) continue;
        x->pendingOutputs->push_back({type,path}); any=true;
    }
    return any;
}

static bool check_declared_dependencies(t_AudioToolsPraat* x,const char* runDir,std::string& reason)
{
    using namespace formparse;
    bool needsPython=false; std::vector<std::string> modules;
    for(const auto& d:*x->dependencies) {
        std::string low=toLower(d);
        if(low.rfind("requires-python ",0)==0 || low.rfind("requires_python ",0)==0) {
            needsPython=true; auto tok=splitWS(d); for(size_t i=1;i<tok.size();++i) modules.push_back(tok[i]);
        } else if(low.find("python")!=std::string::npos) needsPython=true;
    }
    if(!needsPython) return true;
    std::string args="--version";
    if(!modules.empty()) {
        std::string imports;
        for(size_t i=0;i<modules.size();++i){if(i)imports+=",";imports+=modules[i];}
        args="-c \"import "+imports+"\"";
    }
    char logPath[2300]; snprintf(logPath,sizeof(logPath),"%s%cdependency-python.log",runDir,DIRSEP);
    ProcHandle p; int launchErr=0; bool attached=false;
    if(!proc_launch(x->pythonExe->c_str(),args.c_str(),logPath,p,launchErr,attached)) {
        reason="Python dependency unavailable: "+*x->pythonExe+" (OS error "+std::to_string(launchErr)+")"; return false;
    }
    int code=0; bool running=true;
    for(int i=0;i<100&&running;++i){sleep_ms(100);running=proc_is_running(p,code);}
    if(running){proc_terminate(p);proc_close(p);reason="Python dependency check timed out";return false;}
    proc_close(p);
    if(code!=0){std::string lt=tail_of_file(logPath,600);reason="Python dependency check failed"+(lt.empty()?std::string():std::string(": ")+lt);return false;}
    return true;
}

static std::vector<std::string> split_praat_info_lines(const std::string& text)
{
    std::vector<std::string> lines;
    std::string line;
    for (char c : text) {
        if (c == '\r') continue;
        if (c == '\n') { lines.push_back(line); line.clear(); }
        else line += c;
    }
    if (!line.empty() || (text.empty() ? false : text.back() != '\n'))
        lines.push_back(line);
    // Avoid a purely synthetic empty final line, but preserve intentional blanks inside.
    while (!lines.empty() && lines.back().empty()) lines.pop_back();
    return lines;
}

struct PictureBounds {
    bool found=false;
    double x1=0.0, x2=8.0, y1=0.0, y2=8.0;
};

static PictureBounds infer_picture_bounds(const std::string& script)
{
    using namespace formparse;
    PictureBounds b;
    auto lines=linesOf(script);
    for(const auto& line:lines) {
        std::string t=trim(line), low=toLower(t);
        const std::string key="select outer viewport:";
        if(low.rfind(key,0)!=0) continue;
        size_t colon=t.find(':');
        if(colon==std::string::npos) continue;
        std::string tail=t.substr(colon+1);
        for(char& c:tail) if(c==',') c=' ';
        std::istringstream iss(tail);
        double a=0.0,c=0.0,d=0.0,e=0.0;
        if(!(iss>>a>>c>>d>>e)) continue; // expressions are intentionally ignored
        const double lx=(std::min)(a,c), rx=(std::max)(a,c);
        const double by=(std::min)(d,e), ty=(std::max)(d,e);
        if(!b.found) {
            b.found=true; b.x1=lx; b.x2=rx; b.y1=by; b.y2=ty;
        } else {
            b.x1=(std::min)(b.x1,lx); b.x2=(std::max)(b.x2,rx);
            b.y1=(std::min)(b.y1,by); b.y2=(std::max)(b.y2,ty);
        }
    }
    return b;
}

static bool script_looks_visual(const std::string& script)
{
    const std::string low=formparse::toLower(script);
    const bool viewport = low.find("select outer viewport:")!=std::string::npos ||
                          low.find("select inner viewport:")!=std::string::npos;
    const bool drawing = low.find("draw inner box")!=std::string::npos ||
                         low.find("paint rectangle:")!=std::string::npos ||
                         low.find("draw line:")!=std::string::npos ||
                         low.find("text top:")!=std::string::npos ||
                         low.find("erase all")!=std::string::npos;
    return viewport && drawing;
}

static bool build_run_script(t_AudioToolsPraat* x,
                             const std::string& script,
                             const char* inPath,const char* outPath,
                             const char* imagePath,const char* manifestPath,const char* infoPath,
                             const std::string& mode,const std::string& strategy,bool requiresSound,
                             std::string& sc,std::string& err,int& fieldCount,bool& halfScaleLegacyVisual)
{
    using namespace formparse;
    fieldCount=(int)x->params->size();
    halfScaleLegacyVisual=false;
    auto fwd=[](const char* r)->std::string { std::string s; for(const char* c=r;*c;++c)s+=(*c=='\\')?'/':*c; return s; };
    auto repl=[](std::string& s,const std::string& f,const std::string& t){size_t p=0;while((p=s.find(f,p))!=std::string::npos){s.replace(p,f.size(),t);p+=t.size();}};
    auto lines=linesOf(script);
    auto pauseBlocks=analyze_pause_blocks(script);
    for(const auto& pb:pauseBlocks) {
        if(!pb.virtualizable) {
            err=pb.blocker.empty()?"Pause block is not safely virtualizable":pb.blocker;
            return false;
        }
    }
    int formStart=-1,formEnd=-1;
    for(int i=0;i<(int)lines.size();++i) {
        std::string t=trim(lines[i]),tl=toLower(t),head; size_t n=0;
        while(n<tl.size()&&isalpha((unsigned char)tl[n]))head+=tl[n++];
        if(formStart<0&&head=="form")formStart=i;
        else if(formStart>=0&&head=="endform"){formEnd=i;break;}
    }

    sc="# [AudioTools.praat~ v1.36.1 host-generated]\n";
    bool hasInfile=false; for(const auto& p:*x->params) if(p.type=="infile") hasInfile=true;
    std::string scriptLow=toLower(script);
    bool scriptReadsInput=(scriptLow.find("{{in}}")!=std::string::npos);
    bool hostRead=(requiresSound && !hasInfile && (formStart>=0 || !scriptReadsInput));
    if(hostRead) sc+="Read from file: \""+fwd(inPath)+"\"\n\n";

    if(formStart>0) {
        for(int i=0;i<formStart;++i) if(trim(lines[i]).rfind("#@",0)!=0) sc+=lines[i]+"\n";
        sc+="\n";
    }

    // Stateful form replacement. Playback is categorically host-disabled.
    std::vector<std::string> forcedPlayback,forcedVisual;

    auto serializedParamAssignment=[&](const ParamSpec& p)->std::string {
        std::string value=p.currentValue;
        if(p.role=="praat-playback") { value="0"; forcedPlayback.push_back(p.id); }
        if(p.role=="visual" && !x->visualEnabled) { value="0"; forcedVisual.push_back(p.id); }

        if(p.type=="sentence"||p.type=="text"||p.type=="word"||p.type=="infile"||p.type=="outfile"||p.type=="folder") {
            std::string v=value, idl=toLower(p.id);
            bool legacyIn=(p.type!="folder" && p.type!="outfile" && (idl.find("input")!=std::string::npos||idl.find("in_file")!=std::string::npos||idl.find("infile")!=std::string::npos||idl.find("source")!=std::string::npos));
            bool legacyOut=(p.type!="folder" && (idl.find("output")!=std::string::npos||idl.find("out_file")!=std::string::npos||idl.find("outfile")!=std::string::npos));
            if(p.type=="infile" || (legacyIn&&!legacyOut)) v=fwd(inPath);
            if(p.type=="outfile" || legacyOut) v=fwd(outPath);
            return p.id+"$ = \""+praatQuote(v)+"\"\n";
        }
        if(p.type=="choice"||p.type=="optionmenu") {
            int idx=atoi(value.c_str()); if(idx<1)idx=1;
            std::string a=p.id+" = "+std::to_string(idx)+"\n";
            if(idx<=(int)p.options.size()) a+=p.id+"$ = \""+praatQuote(p.options[idx-1])+"\"\n";
            return a;
        }
        if(value.empty()) value="0";
        return p.id+" = "+value+"\n";
    };

    // Ordinary form parameters must exist before the script body starts.
    // Pause parameters are different: their defaults may reference variables
    // initialized in the body immediately before beginPause.  Emit those at
    // the original Pause location below, never at the wrapper top.
    for(const auto& p:*x->params) {
        if(p.fromPause) continue;
        sc+=serializedParamAssignment(p);
    }

    // Remove every virtualized Pause block from the headless script. Dialog
    // variables were already emitted from persistent host state above. If the
    // original script assigned endPause's return value, resolve it to the
    // dialog's declared default button so downstream control flow is preserved.
    std::vector<bool> pauseSkip(lines.size(),false);
    std::map<int,std::string> pauseStartReplacement;
    std::map<int,std::string> pauseReplacement;
    for(const auto& pb:pauseBlocks) {
        if(pb.startLine<0 || pb.endLine<pb.startLine) continue;

        std::string assignments;
        for(const auto& p:*x->params)
            if(p.fromPause && p.group==pb.title) assignments+=serializedParamAssignment(p);
        pauseStartReplacement[pb.startLine]=assignments;

        for(int k=pb.startLine;k<=pb.endLine && k<(int)pauseSkip.size();++k) pauseSkip[k]=true;
        if(pb.endAssigned && !pb.endTarget.empty())
            pauseReplacement[pb.endLine]=pb.endTarget+" = "+std::to_string(pb.defaultButton);
        object_post((t_object*)x,"AudioTools.praat~: headless: virtualized Pause '%s'%s",
                    pb.title.c_str(), pb.whenParam.empty()?"":" (conditional UI)");
    }

    int bodyStart=(formEnd>=0)?formEnd+1:0;
    for(int i=bodyStart;i<(int)lines.size();++i) {
        auto psi=pauseStartReplacement.find(i);
        if(psi!=pauseStartReplacement.end()) { sc+=psi->second; continue; }
        auto pri=pauseReplacement.find(i);
        if(pri!=pauseReplacement.end()) { sc+=pri->second+"\n"; continue; }
        if(i<(int)pauseSkip.size() && pauseSkip[i]) continue;
        std::string t=trim(lines[i]);
        if(t.rfind("#@",0)==0) continue;
        if(isPlaybackCommand(lines[i])) {
            object_post((t_object*)x,"AudioTools.praat~: headless: removed direct Praat playback command: %s",t.c_str());
            continue;
        }
        sc+=lines[i]+"\n";
    }

    // Praat Info is intentionally NOT captured inside the generated script.
    // In headless --run mode Praat routes writeInfo*/appendInfo* to stdout; the
    // worker captures that stream after the process exits. Keeping capture out
    // of the script also guarantees that object selection is untouched before
    // host_save_selected_sound runs.

    if(strategy=="host_save_selected_sound") {
        sc+="\n# [AudioTools.praat~ host_save_selected_sound]\n";
        sc+="Save as WAV file: \""+fwd(outPath)+"\"\n";
    }

    // v1.35 legacy visual capture. Fully-hosted scripts that explicitly use
    // {{IMAGE}} keep ownership of their image export. Legacy AudioTools scripts
    // usually draw to the Picture window only, so the host reselects the union
    // of literal outer viewports and exports that complete canvas to visual.png.
    const bool scriptOwnsImage=(scriptLow.find("{{image}}")!=std::string::npos);
    if(x->visualEnabled && !scriptOwnsImage && script_looks_visual(script)) {
        PictureBounds pb=infer_picture_bounds(script);
        if(!pb.found) { pb.found=true; pb.x1=0.0; pb.x2=8.0; pb.y1=0.0; pb.y2=8.0; }
        char vp[512];
        snprintf(vp,sizeof(vp),"Select outer viewport: %.6g, %.6g, %.6g, %.6g\n",pb.x1,pb.x2,pb.y1,pb.y2);
        sc+="\n# [AudioTools.praat~ v1.36.1 legacy_visual_capture]\n";
        sc+=vp;
        const long praatExportDpi=(x->visualDpi==600)?600:300;
        if(praatExportDpi==600) sc+="Save as 600-dpi PNG file: \""+fwd(imagePath)+"\"\n";
        else sc+="Save as 300-dpi PNG file: \""+fwd(imagePath)+"\"\n";
        halfScaleLegacyVisual=(x->visualDpi==150);
        if(halfScaleLegacyVisual)
            object_post((t_object*)x,"AudioTools.praat~: visual capture -> %s [screen 150 dpi: Praat 300 dpi + host 0.5x; viewport %.3g..%.3g x %.3g..%.3g]",
                        imagePath,pb.x1,pb.x2,pb.y1,pb.y2);
        else
            object_post((t_object*)x,"AudioTools.praat~: visual capture -> %s [%ld dpi; viewport %.3g..%.3g x %.3g..%.3g]",
                        imagePath,praatExportDpi,pb.x1,pb.x2,pb.y1,pb.y2);
    }

    repl(sc,"{{IN}}",fwd(inPath)); repl(sc,"{{OUT}}",fwd(outPath));
    repl(sc,"{{IMAGE}}",fwd(imagePath)); repl(sc,"{{MANIFEST}}",fwd(manifestPath)); repl(sc,"{{INFO}}",fwd(infoPath));

    for(const auto& v:forcedPlayback) object_post((t_object*)x,"AudioTools.praat~: forcing %s = 0 (Praat playback disabled)",v.c_str());
    for(const auto& v:forcedVisual) object_post((t_object*)x,"AudioTools.praat~: forcing %s = 0 (visual output not requested)",v.c_str());
    err.clear(); return true;
}

// ═════════════════════════════════════════════════════════════════════════════
// SECTION 8 — Worker threads
// ═════════════════════════════════════════════════════════════════════════════

// ── send: export buffer + open Praat GUI with the input loaded ───────────────
static void send_worker(t_AudioToolsPraat* x)
{
    std::lock_guard<std::mutex> lock(x->ioMutex);
    x->pendingPraatInfo->clear(); x->praatInfoCaptured=false;
    if (!export_input_buffer(x, x->wavIn)) { finish_run(x, RESULT_ERROR); return; }

    char cmd[4096];
    snprintf(cmd,sizeof(cmd),"\"%s\" --open \"%s\"",x->praatExe,x->wavIn);
    object_post((t_object*)x,"AudioTools.praat~: opening Praat with the input audio...");

    if (!run_detached(cmd)) {
        object_error((t_object*)x,"AudioTools.praat~: failed to launch Praat.");
        finish_run(x, RESULT_ERROR); return;
    }
    object_post((t_object*)x,
        "AudioTools.praat~: Praat opened with audio loaded.\n"
        "  Process in Praat, then:\n"
        "  Select Sound -> File -> Save as WAV file -> %s\n"
        "  Then send [receive] to load it back into Max.",
        x->wavOut);
    // Not a run result — no outlet fires for [send].
    x->processing.store(false);
}

// ── receive: read the manual _out.wav → output buffer ────────────────────────
static void receive_worker(t_AudioToolsPraat* x)
{
    std::lock_guard<std::mutex> lock(x->ioMutex);
    x->pendingPraatInfo->clear(); x->praatInfoCaptured=false;
    // FIX 5: v1.24 returned here without firing either outlet.
    if (!import_output_buffer(x, x->wavOut)) { finish_run(x, RESULT_ERROR); return; }
    finish_run(x, RESULT_OK);
}

// ── bang: fully automated pipeline ───────────────────────────────────────────
static void bang_worker(t_AudioToolsPraat* x)
{
    std::lock_guard<std::mutex> lock(x->ioMutex);
    if(!x->debugKeep && x->lastRunDir[0]) { remove_tree(x->lastRunDir); x->lastRunDir[0]='\0'; }
    long runId=++x->runCounter;
    char runDir[2048];
    if(!make_run_workspace(x,runId,runDir,sizeof(runDir))){object_error((t_object*)x,"AudioTools.praat~: could not create run workspace.");*x->pendingState="error";finish_run(x,RESULT_ERROR);return;}
    snprintf(x->lastRunDir,sizeof(x->lastRunDir),"%s",runDir);
    char inPath[2100],outPath[2200],runPath[2100],logPath[2100],imagePath[2200],manifestPath[2200],infoPath[2200];
    snprintf(inPath,sizeof(inPath),"%s%cinput_0.wav",runDir,DIRSEP);
    snprintf(outPath,sizeof(outPath),"%s%coutputs%cout.wav",runDir,DIRSEP,DIRSEP);
    snprintf(runPath,sizeof(runPath),"%s%crun.praat",runDir,DIRSEP);
    snprintf(logPath,sizeof(logPath),"%s%clog.txt",runDir,DIRSEP);
    snprintf(imagePath,sizeof(imagePath),"%s%coutputs%cvisual.png",runDir,DIRSEP,DIRSEP);
    snprintf(manifestPath,sizeof(manifestPath),"%s%coutputs%cmanifest.txt",runDir,DIRSEP,DIRSEP);
    snprintf(infoPath,sizeof(infoPath),"%s%coutputs%cpraat_info.txt",runDir,DIRSEP,DIRSEP);
    x->pendingOutputs->clear(); x->pendingPraatInfo->clear(); x->praatInfoCaptured=false; *x->pendingState="running";
    object_post((t_object*)x,"AudioTools.praat~: run %ld — workspace %s",runId,runDir);
    auto fail=[&](int result,const char* state){*x->pendingState=state;if(!x->debugKeep)remove_tree(runDir);finish_run(x,result);};

    std::string script; int re=0;
    if(!read_whole_file(x->scriptPath->s_name,script,re)){object_error((t_object*)x,"AudioTools.praat~: cannot open script '%s' (errno %d)",x->scriptPath->s_name,re);fail(RESULT_ERROR,"error");return;}
    if(!x->descriptorLoaded){std::string derr;parse_script_descriptor(x,script,true,derr);}
    SafetyReport sr=scan_script(x,script);
    *x->safetyState=sr.allowed?"allow":"block";
    x->safetyReason->clear();
    for(const auto& b:sr.blockers){if(!x->safetyReason->empty())*x->safetyReason+=" | ";*x->safetyReason+=b;}
    if(!sr.allowed){object_error((t_object*)x,"AudioTools.praat~: Run Safety Gate BLOCKED: %s",x->safetyReason->c_str());fail(RESULT_ERROR,"blocked");return;}
    for(const auto& w:sr.warnings)object_warn((t_object*)x,"AudioTools.praat~: safety: %s",w.c_str());
    std::string depReason;
    if(!check_declared_dependencies(x,runDir,depReason)){object_error((t_object*)x,"AudioTools.praat~: dependency check failed: %s",depReason.c_str());fail(RESULT_ERROR,"error");return;}

    std::string mode=resolve_mode(x,script),strategy=resolve_strategy(x,script,mode);
    bool requiresSound=resolve_requires_sound(script,mode);
    object_post((t_object*)x,"AudioTools.praat~: mode=%s requires_sound=%d strategy=%s",mode.c_str(),(int)requiresSound,strategy.c_str());

    if(requiresSound) {
        if(!export_input_buffer(x,inPath)){fail(RESULT_ERROR,"error");return;}
    }

    std::string sc,berr; int fields=0; bool halfScaleLegacyVisual=false;
    if(!build_run_script(x,script,inPath,outPath,imagePath,manifestPath,infoPath,mode,strategy,requiresSound,sc,berr,fields,halfScaleLegacyVisual)){object_error((t_object*)x,"AudioTools.praat~: %s",berr.c_str());fail(RESULT_ERROR,"error");return;}
    FILE* rf=fopen(runPath,"wb"); if(!rf){object_error((t_object*)x,"AudioTools.praat~: cannot write '%s'",runPath);fail(RESULT_ERROR,"error");return;}
    fwrite(sc.c_str(),1,sc.size(),rf); fclose(rf);

    char args[4096]; snprintf(args,sizeof(args),x->fullTrust ? "--FULL-TRUST --utf8 --no-pref-files --run \"%s\"" : "--utf8 --no-pref-files --run \"%s\"",runPath);
    ProcHandle proc; int launchErr=0; bool logAttached=false;
    if(!proc_launch(x->praatExe,args,logPath,proc,launchErr,logAttached)){object_error((t_object*)x,"AudioTools.praat~: failed to launch Praat (OS error %d).",launchErr);fail(RESULT_ERROR,"error");return;}

    bool processEnded=false,aborted=false; int exitCode=0; unsigned long elapsed=0;
    while(elapsed<x->timeoutMs){sleep_ms(200);elapsed+=200;if(x->abort_flag.load()||x->quitting.load()){aborted=true;break;}if(!proc_is_running(proc,exitCode)){processEnded=true;break;}}
    if(aborted){proc_terminate(proc);proc_close(proc);object_error((t_object*)x,"AudioTools.praat~: run %ld stopped by user.",runId);fail(RESULT_CANCELLED,"cancelled");return;}
    if(!processEnded){proc_terminate(proc);proc_close(proc);object_error((t_object*)x,"AudioTools.praat~: run %ld timed out after %lu ms.",runId,x->timeoutMs);fail(RESULT_ERROR,"error");return;}
    proc_close(proc); sleep_ms(150);

    // In Praat --run mode, text that would normally go to the Info window is
    // written to stdout. proc_launch redirects stdout+stderr to log.txt; with
    // --utf8 above, successful-run Info can be read directly and exposed to Max.
    // We do this before any later error path can remove the workspace.
    if(logAttached && formparse::fileExists(logPath)) {
        std::string infoText; int ie=0;
        if(read_whole_file(logPath,infoText,ie)) {
            *x->pendingPraatInfo=split_praat_info_lines(infoText);
            x->praatInfoCaptured=true;
        }
    }

    // Never report a failed Praat script as a successful audio run. Earlier
    // builds could continue after a non-zero Praat exit code and import whatever
    // output happened to exist. Keep partial Praat Info available for diagnosis.
    if(exitCode!=0) {
        std::string lt=tail_of_file(logPath,1200);
        object_error((t_object*)x,"AudioTools.praat~: Praat exited with code %d%s%s",
                     exitCode,lt.empty()?"":" — ",lt.empty()?"":lt.c_str());
        fail(RESULT_ERROR,"error");
        return;
    }

    if(halfScaleLegacyVisual && formparse::fileExists(imagePath)) {
        unsigned int sw=0,sh=0; std::string resizeReason;
        if(downsample_png_half_wic(imagePath,sw,sh,resizeReason))
            object_post((t_object*)x,"AudioTools.praat~: visual screen downsample -> %u x %u",sw,sh);
        else
            object_warn((t_object*)x,"AudioTools.praat~: 150-dpi screen downsample failed (%s); keeping Praat 300-dpi PNG.",resizeReason.c_str());
    }

    bool manifest=write_manifest_outputs(x,manifestPath);
    bool outExists=formparse::fileExists(outPath);
    bool imageExists=formparse::fileExists(imagePath);
    bool imported=false;
    std::string manifestAudio;
    for(const auto&o:*x->pendingOutputs) if(o.type=="audio"&&manifestAudio.empty()) manifestAudio=o.path;
    if(strategy=="host_save_selected_sound"||strategy=="script_managed") {
        if(outExists) {
            if(!import_output_buffer(x,outPath)){fail(RESULT_ERROR,"error");return;}
            imported=true;
            bool listed=false;for(const auto&o:*x->pendingOutputs)if(o.type=="audio"&&o.path==outPath)listed=true;
            if(!listed)x->pendingOutputs->push_back({"audio",outPath});
        } else if(strategy=="script_managed" && !manifestAudio.empty() && formparse::fileExists(manifestAudio)) {
            if(!import_output_buffer(x,manifestAudio.c_str())){fail(RESULT_ERROR,"error");return;}
            imported=true;
        } else if(strategy=="host_save_selected_sound") {
            std::string lt=tail_of_file(logPath,900);
            object_error((t_object*)x,"AudioTools.praat~: Praat exited without host audio output.%s%s",lt.empty()?"":"\n",lt.c_str());
            fail(RESULT_ERROR,"error");return;
        }
    }
    if(imageExists) x->pendingOutputs->push_back({"image",imagePath});

    if(exitCode!=0 && !outExists && !manifest && x->pendingOutputs->empty()) {
        std::string lt=tail_of_file(logPath,900);
        object_error((t_object*)x,"AudioTools.praat~: Praat exited code %d.%s%s",exitCode,lt.empty()?"":"\n",lt.c_str());
        fail(RESULT_ERROR,"error");return;
    }

    int result=RESULT_OK;
    if(exitCode!=0) {
        std::string lt=tail_of_file(logPath,600);
        object_warn((t_object*)x,"AudioTools.praat~: Praat exited code %d after producing output; reporting PARTIAL.%s%s",exitCode,lt.empty()?"":"\n",lt.c_str());
        result=RESULT_PARTIAL;
    }
    if(strategy=="script_managed"&&!outExists&&!manifest&&x->pendingOutputs->empty()) {
        object_warn((t_object*)x,"AudioTools.praat~: script_managed completed but declared no host-readable outputs.");
        result=RESULT_PARTIAL;
    }
    *x->pendingState=(result==RESULT_PARTIAL)?"partial":"completed";
    if(x->debugKeep) object_post((t_object*)x,"AudioTools.praat~: debug=1 — workspace kept at %s",runDir);
    else object_post((t_object*)x,"AudioTools.praat~: outputs remain valid until the next run: %s",runDir);
    (void)imported;
    finish_run(x,result);
}

// ═════════════════════════════════════════════════════════════════════════════
// SECTION 9 — Max object methods
// ═════════════════════════════════════════════════════════════════════════════

void* AudioToolsPraat_new(t_symbol*, long argc, t_atom* argv)
{
    static std::atomic<long> s_instanceCounter(0);

    t_AudioToolsPraat* x=
        (t_AudioToolsPraat*)object_alloc(s_AudioToolsPraat_class);
    if (!x) return nullptr;

    new (&x->result)     std::atomic<int>(RESULT_OK);
    new (&x->processing) std::atomic<bool>(false);
    new (&x->abort_flag) std::atomic<bool>(false);
    new (&x->quitting)   std::atomic<bool>(false);
    new (&x->ioMutex)    std::mutex();
    new (&x->worker)     std::thread();

    x->params          = new std::vector<ParamSpec>();
    x->presets         = new std::vector<PresetSpec>();
    x->dependencies    = new std::vector<std::string>();
    x->pendingOutputs  = new std::vector<OutputItem>();
    x->pendingPraatInfo = new std::vector<std::string>();
    x->scriptTitle     = new std::string("Praat Tool");
    x->toolMode        = new std::string("auto");
    x->outputStrategy  = new std::string("auto");
    x->safetyState     = new std::string("unknown");
    x->safetyReason    = new std::string();
    x->libraryRoot     = new std::string();
#ifdef _WIN32
    x->pythonExe       = new std::string("python");
#else
    x->pythonExe       = new std::string("python3");
#endif
    x->pendingState    = new std::string("idle");

    x->inBufName  =(argc>0&&atom_gettype(argv)  ==A_SYM)?atom_getsym(argv)  :gensym("input");
    x->outBufName =(argc>1&&atom_gettype(argv+1)==A_SYM)?atom_getsym(argv+1):gensym("output");
    x->scriptPath = gensym("");

    x->instanceId = ++s_instanceCounter;
    x->runCounter = 0;
    x->timeoutMs  = 30000;
    x->debugKeep  = false;
    x->fullTrust  = true;
    x->visualEnabled = false;
    x->visualDpi = 150;
    x->praatInfoCaptured = false;
    x->lastRunDir[0]='\0';

    if (!get_external_directory(x->exeDir,sizeof(x->exeDir)))
        x->exeDir[0]='\0';

    {
        const std::string defaultPraat = default_praat_executable(x->exeDir);
        strncpy(x->praatExe, defaultPraat.c_str(), sizeof(x->praatExe)-1);
        x->praatExe[sizeof(x->praatExe)-1] = '\0';
    }

    if (!make_instance_workspace(x)) {
        object_error((t_object*)x,
            "AudioTools.praat~: could not create a temp workspace — "
            "falling back to the externals folder (instances WILL collide).");
        snprintf(x->instDir,  sizeof(x->instDir),  "%s", x->exeDir);
        snprintf(x->wavIn,    sizeof(x->wavIn),    "%s%c_in.wav",    x->exeDir, DIRSEP);
        snprintf(x->wavOut,   sizeof(x->wavOut),   "%s%c_out.wav",   x->exeDir, DIRSEP);
        snprintf(x->runScript,sizeof(x->runScript),"%s%c_run.praat", x->exeDir, DIRSEP);
    }

    x->inBufRef   = buffer_ref_new((t_object*)x, x->inBufName);
    x->outBufRef  = buffer_ref_new((t_object*)x, x->outBufName);
    // Outlets are created right-to-left: keep success=0 and error=1 compatible,
    // add structured info as outlet 2.
    x->infoOutlet  = outlet_new((t_object*)x, nullptr);
    x->errorOutlet = bangout((t_object*)x);
    x->outlet      = bangout((t_object*)x);
    x->qelem       = qelem_new((t_object*)x,(method)AudioToolsPraat_qfn);
    dsp_setup((t_pxobject*)x, 0);

    object_post((t_object*)x,
        "AudioTools.praat~ v1.36.1\n"
        "  Praat exe    : %s\n"
        "  inBuf        : %s\n"
        "  outBuf       : %s\n"
        "  workspace    : %s\n"
        "  timeout      : %lu ms\n"
        "  Praat trust  : %s\n"
        "─────────────────────────────────────────\n"
        "  outlet 0 (left)  : bang on success\n"
        "  outlet 1 (right) : bang on error / timeout / stop\n"
        "  MANUAL : [send] → process in Praat → save → [receive]\n"
        "  AUTO   : set script path then [bang]\n"
        "  [stop] [status] [debug 0|1] [timeout <ms>]",
        x->praatExe, x->inBufName->s_name, x->outBufName->s_name,
        x->instDir, x->timeoutMs, x->fullTrust ? "FULL (hosted file output enabled)" : "restricted");
    return x;
}

// FIX 6: own and join the worker; cancel any pending main-thread notify.
void AudioToolsPraat_free(t_AudioToolsPraat* x)
{
    x->quitting.store(true);
    x->abort_flag.store(true);
    if (x->worker.joinable()) x->worker.join();

    if (x->qelem) { qelem_unset(x->qelem); qelem_free(x->qelem); x->qelem=nullptr; }

    dsp_free((t_pxobject*)x);
    if (x->inBufRef)  { object_free(x->inBufRef);  x->inBufRef =nullptr; }
    if (x->outBufRef) { object_free(x->outBufRef); x->outBufRef=nullptr; }

    if (!x->debugKeep && x->instDir[0] &&
        strcmp(x->instDir, x->exeDir) != 0)
        remove_tree(x->instDir);

    delete x->params; delete x->presets; delete x->dependencies; delete x->pendingOutputs; delete x->pendingPraatInfo;
    delete x->scriptTitle; delete x->toolMode; delete x->outputStrategy;
    delete x->safetyState; delete x->safetyReason; delete x->libraryRoot;
    delete x->pythonExe; delete x->pendingState;

    x->worker.~thread();
    x->ioMutex.~mutex();
    x->quitting.~atomic<bool>();
    x->abort_flag.~atomic<bool>();
    x->processing.~atomic<bool>();
    x->result.~atomic<int>();
}

void AudioToolsPraat_bang(t_AudioToolsPraat* x)
{
    if (x->processing.exchange(true)) {
        object_post((t_object*)x,"AudioTools.praat~: still processing."); return;
    }
    if (x->scriptPath->s_name[0]=='\0') {
        object_error((t_object*)x,
            "AudioTools.praat~: no script set.\n"
            "Send:  script <absolute path to a .praat file>");
        x->processing.store(false); return;
    }
    start_worker(x, bang_worker);
}

void AudioToolsPraat_send(t_AudioToolsPraat* x)
{
    if (x->processing.exchange(true)) {
        object_post((t_object*)x,"AudioTools.praat~: still processing."); return;
    }
    start_worker(x, send_worker);
}

void AudioToolsPraat_receive(t_AudioToolsPraat* x)
{
    if (x->processing.exchange(true)) {
        object_post((t_object*)x,"AudioTools.praat~: still processing."); return;
    }
    start_worker(x, receive_worker);
}

void AudioToolsPraat_open(t_AudioToolsPraat* x)
{
    char cmd[4096];
    snprintf(cmd,sizeof(cmd),"\"%s\"",x->praatExe);
    if (run_detached(cmd))
        object_post((t_object*)x,"AudioTools.praat~: Praat opened.");
    else
        object_error((t_object*)x,"AudioTools.praat~: failed to open Praat.");
}

void AudioToolsPraat_script(t_AudioToolsPraat* x, t_symbol* /*s*/,
                             long argc, t_atom* argv)
{
    if(argc==0){object_error((t_object*)x,"AudioTools.praat~: script needs a path argument.");return;}
    if(x->processing.load()){object_error((t_object*)x,"AudioTools.praat~: cannot change script while running.");return;}
    std::string fullPath=formparse::atomsString(argc,argv);
    x->scriptPath=gensym(fullPath.c_str());
    std::string src;int er=0,derr=0;
    *x->toolMode="auto"; *x->outputStrategy="auto";
    if(!read_whole_file(fullPath.c_str(),src,er)){object_error((t_object*)x,"AudioTools.praat~: cannot read script '%s' (errno %d)",fullPath.c_str(),er);x->descriptorLoaded=false;return;}
    std::string pe; parse_script_descriptor(x,src,true,pe);
    SafetyReport sr=scan_script(x,src);*x->safetyState=sr.allowed?"allow":"block";x->safetyReason->clear();
    for(const auto& b:sr.blockers){if(!x->safetyReason->empty())*x->safetyReason+=" | ";*x->safetyReason+=b;}
    object_post((t_object*)x,"AudioTools.praat~: script -> '%s' | %zu params | %zu presets | safety=%s",fullPath.c_str(),x->params->size(),x->presets->size(),x->safetyState->c_str());
    // v1.34: descriptor streams are pushed automatically so a connected dynamic
    // Max UI can rebuild immediately after [script <path>] without a second click.
    AudioToolsPraat_describe(x);
    (void)derr;
}

void AudioToolsPraat_praatexe(t_AudioToolsPraat* x, t_symbol* /*s*/,
                               long argc, t_atom* argv)
{
    if (argc == 0) {
        object_post((t_object*)x,
            "AudioTools.praat~: praatExe = '%s'", x->praatExe);
        return;
    }
    std::string fullPath = atoms_to_path(argc, argv);
#ifdef _WIN32
    for (char& c : fullPath) if (c == '/') c = '\\';
#endif
    strncpy(x->praatExe, fullPath.c_str(), sizeof(x->praatExe)-1);
    x->praatExe[sizeof(x->praatExe)-1] = '\0';
    object_post((t_object*)x,
        "AudioTools.praat~: praatExe -> '%s' (len=%zu)",
        x->praatExe, fullPath.size());
}

void AudioToolsPraat_stop(t_AudioToolsPraat* x)
{
    if (x->processing.load()) {
        x->abort_flag.store(true);
        object_post((t_object*)x,
            "AudioTools.praat~: stop requested — terminating Praat.");
    } else {
        object_post((t_object*)x,"AudioTools.praat~: nothing running.");
    }
}

static void emit_param(t_AudioToolsPraat* x,const ParamSpec& p)
{
    std::vector<std::string> v={p.id,p.type,p.label,"default",p.defaultValue,"current",p.currentValue};
    if(!p.unit.empty()){v.push_back("unit");v.push_back(p.unit);}
    if(!p.role.empty()){v.push_back("role");v.push_back(p.role);}
    if(!p.group.empty()){v.push_back("group");v.push_back(p.group);}
    if(!p.whenParam.empty()){v.push_back("when");v.push_back(p.whenParam);v.push_back("whenvalue");v.push_back(p.whenValue);}
    char b[64];
    if(p.hasMin){snprintf(b,sizeof(b),"%.12g",p.minValue);v.push_back("min");v.push_back(b);}
    if(p.hasMax){snprintf(b,sizeof(b),"%.12g",p.maxValue);v.push_back("max");v.push_back(b);}
    if(p.hasStep){snprintf(b,sizeof(b),"%.12g",p.stepValue);v.push_back("step");v.push_back(b);}
    if(!p.options.empty()){v.push_back("options");for(const auto&o:p.options)v.push_back(o);}
    info_message(x,"param",v);
}

void AudioToolsPraat_describe(t_AudioToolsPraat* x)
{
    if(!x->descriptorLoaded){object_error((t_object*)x,"AudioTools.praat~: no script descriptor loaded. Send [script <path>] first.");return;}
    info_kv(x,"describe_begin",{*x->scriptTitle,*x->toolMode,*x->outputStrategy,std::to_string(x->params->size()),std::to_string(x->presets->size())});
    for(const auto&p:*x->params)emit_param(x,p);
    int i=1;for(const auto&pr:*x->presets){
        std::string src=pr.mappingSource.empty()?(pr.values.empty()?"legacy":"mapped"):pr.mappingSource;
        info_kv(x,"preset",{std::to_string(i++),pr.name,src,std::to_string(pr.values.size())});
    }
    for(const auto&d:*x->dependencies)info_kv(x,"requires",{d});
    info_kv(x,"safety",{*x->safetyState,x->safetyReason->empty()?"ok":*x->safetyReason});
    info_kv(x,"describe_end",{*x->scriptTitle});
}

void AudioToolsPraat_dump(t_AudioToolsPraat* x)
{
    for(const auto&p:*x->params)info_kv(x,"value",{p.id,p.currentValue});
}

void AudioToolsPraat_reset(t_AudioToolsPraat* x)
{
    if(x->processing.load()){object_error((t_object*)x,"AudioTools.praat~: reset unavailable while running.");return;}
    for(auto&p:*x->params)p.currentValue=p.defaultValue;
    info_kv(x,"reset",{"ok"}); AudioToolsPraat_dump(x);
}

void AudioToolsPraat_scan(t_AudioToolsPraat* x)
{
    if(x->scriptPath->s_name[0]=='\0'){object_error((t_object*)x,"AudioTools.praat~: no script set.");return;}
    std::string src;int er=0;if(!read_whole_file(x->scriptPath->s_name,src,er)){object_error((t_object*)x,"AudioTools.praat~: cannot read script.");return;}
    SafetyReport sr=scan_script(x,src);*x->safetyState=sr.allowed?"allow":"block";x->safetyReason->clear();
    for(const auto&b:sr.blockers){if(!x->safetyReason->empty())*x->safetyReason+=" | ";*x->safetyReason+=b;info_kv(x,"safety_block",{b});}
    for(const auto&w:sr.warnings)info_kv(x,"safety_warning",{w});
    info_kv(x,"safety",{*x->safetyState,x->safetyReason->empty()?"ok":*x->safetyReason});
}

void AudioToolsPraat_param(t_AudioToolsPraat* x,t_symbol*,long argc,t_atom* argv)
{
    if(argc<2){object_error((t_object*)x,"usage: param <name> <value>");return;}
    if(x->processing.load()){object_error((t_object*)x,"AudioTools.praat~: parameters are locked while running.");return;}
    std::string id=formparse::atomString(argv),value=formparse::atomsString(argc,argv,1);
    ParamSpec* p=find_param(x,id);if(!p){object_error((t_object*)x,"AudioTools.praat~: unknown parameter '%s'",id.c_str());return;}
    if(p->type=="choice"||p->type=="optionmenu") {
        int idx=atoi(value.c_str());
        if(idx<1) { for(size_t i=0;i<p->options.size();++i)if(formparse::toLower(p->options[i])==formparse::toLower(value)){idx=(int)i+1;break;} }
        if(idx<1||idx>(int)p->options.size()){object_error((t_object*)x,"AudioTools.praat~: invalid option '%s' for %s",value.c_str(),p->id.c_str());return;}
        value=std::to_string(idx);
    } else if(p->type=="boolean") value=(atoi(value.c_str())!=0)?"1":"0";
    else if((p->type=="real"||p->type=="positive"||p->type=="integer"||p->type=="natural")&&!value.empty()) {
        double d=0;if(!formparse::parseDouble(value,d)){object_error((t_object*)x,"AudioTools.praat~: %s expects a number",p->id.c_str());return;}
        if(p->hasMin&&d<p->minValue) d=p->minValue;
        if(p->hasMax&&d>p->maxValue) d=p->maxValue;
        char b[64];snprintf(b,sizeof(b),"%.12g",d);value=b;
    }
    p->currentValue=value;
    if(formparse::toLower(p->id)!="preset" && p->role!="visual" && p->role!="praat-playback") {
        int mi=manual_or_custom_preset_index(x);
        ParamSpec* pp=find_param(x,"preset");
        if(mi>0 && pp && atoi(pp->currentValue.c_str())!=mi) {
            pp->currentValue=std::to_string(mi);
            info_kv(x,"preset_selected",{std::to_string(mi),(*x->presets)[mi-1].name,"manual-after-param-edit"});
            info_kv(x,"value",{pp->id,pp->currentValue});
        }
    }
    info_kv(x,"value",{p->id,p->currentValue});
}

void AudioToolsPraat_preset(t_AudioToolsPraat* x,t_symbol*,long argc,t_atom* argv)
{
    if(argc<1){for(size_t i=0;i<x->presets->size();++i)info_kv(x,"preset",{std::to_string(i+1),(*x->presets)[i].name});return;}
    if(x->processing.load()){object_error((t_object*)x,"AudioTools.praat~: preset unavailable while running.");return;}
    std::string q=formparse::atomsString(argc,argv);int idx=atoi(q.c_str());
    if(idx<1){for(size_t i=0;i<x->presets->size();++i)if(formparse::toLower((*x->presets)[i].name)==formparse::toLower(q)){idx=(int)i+1;break;}}
    if(idx<1||idx>(int)x->presets->size()){object_error((t_object*)x,"AudioTools.praat~: preset '%s' not found.",q.c_str());return;}
    PresetSpec& pr=(*x->presets)[idx-1];
    for(auto& p:*x->params) p.currentValue=p.defaultValue;
    ParamSpec* pp=find_param(x,"preset");if(pp&&!pp->options.empty())pp->currentValue=std::to_string(idx);
    for(const auto&kv:pr.values){ParamSpec*p=find_param(x,kv.first);if(p)p->currentValue=kv.second;}
    std::string src=pr.mappingSource.empty()?(pr.values.empty()?"legacy":"mapped"):pr.mappingSource;
    info_kv(x,"preset_selected",{std::to_string(idx),pr.name,src,std::to_string(pr.values.size())});
    AudioToolsPraat_dump(x);
}

void AudioToolsPraat_mode(t_AudioToolsPraat* x,t_symbol*,long argc,t_atom* argv)
{
    if(argc<1){info_kv(x,"mode",{*x->toolMode});return;}std::string m=formparse::toLower(formparse::atomString(argv));
    if(m!="auto"&&m!="processor"&&m!="generator"&&m!="analyzer"&&m!="browser"){object_error((t_object*)x,"mode: auto|processor|generator|analyzer|browser");return;}*x->toolMode=m;info_kv(x,"mode",{m});
}
void AudioToolsPraat_strategy(t_AudioToolsPraat* x,t_symbol*,long argc,t_atom* argv)
{
    if(argc<1){info_kv(x,"strategy",{*x->outputStrategy});return;}std::string m=formparse::toLower(formparse::atomString(argv));
    if(m!="auto"&&m!="host_save_selected_sound"&&m!="script_managed"&&m!="none"){object_error((t_object*)x,"strategy: auto|host_save_selected_sound|script_managed|none");return;}*x->outputStrategy=m;info_kv(x,"strategy",{m});
}
void AudioToolsPraat_visual(t_AudioToolsPraat* x,t_symbol*,long argc,t_atom* argv)
{
    if(argc<1){info_kv(x,"visual",{x->visualEnabled?"1":"0"});return;}
    x->visualEnabled=atom_getlong(argv)!=0;
    const std::string v=x->visualEnabled?"1":"0";
    // Keep any role=visual form parameter synchronized with the host toggle.
    // This is a host/output control, not a musical edit, so it must not force
    // a named preset back to Manual/Custom.
    for(auto& p:*x->params) {
        if(p.role=="visual") { p.currentValue=v; info_kv(x,"value",{p.id,p.currentValue}); }
    }
    info_kv(x,"visual",{v});
}
void AudioToolsPraat_visualdpi(t_AudioToolsPraat* x,t_symbol*,long argc,t_atom* argv)
{
    if(argc<1) { info_kv(x,"visualdpi",{std::to_string(x->visualDpi)}); return; }
    const long dpi=atom_getlong(argv);
    if(dpi!=150 && dpi!=300 && dpi!=600) {
        object_warn((t_object*)x,"AudioTools.praat~: visualdpi must be 150, 300, or 600 (current %ld).",x->visualDpi);
        return;
    }
    x->visualDpi=dpi;
    info_kv(x,"visualdpi",{std::to_string(x->visualDpi)});
}
void AudioToolsPraat_trust(t_AudioToolsPraat* x,t_symbol*,long argc,t_atom* argv)
{
    if(argc<1){info_kv(x,"trust",{x->fullTrust?"1":"0"});return;}
    x->fullTrust=atom_getlong(argv)!=0;
    info_kv(x,"trust",{x->fullTrust?"1":"0"});
    object_post((t_object*)x,"AudioTools.praat~: trust -> %d (%s)",(int)x->fullTrust,
        x->fullTrust?"Praat --FULL-TRUST enabled for hosted runs; run only scripts you trust":"restricted Praat run; file output may be blocked by Praat 7+");
}
void AudioToolsPraat_library(t_AudioToolsPraat* x,t_symbol*,long argc,t_atom* argv){if(argc<1){info_kv(x,"library",{x->libraryRoot->empty()?"(unset)":*x->libraryRoot});return;}*x->libraryRoot=formparse::atomsString(argc,argv);info_kv(x,"library",{*x->libraryRoot});}
void AudioToolsPraat_python(t_AudioToolsPraat* x,t_symbol*,long argc,t_atom* argv){if(argc<1){info_kv(x,"python",{*x->pythonExe});return;}*x->pythonExe=formparse::atomsString(argc,argv);info_kv(x,"python",{*x->pythonExe});}

void AudioToolsPraat_status(t_AudioToolsPraat* x)
{
    object_post((t_object*)x,
        "AudioTools.praat~ status\n"
        "  external     : v1.36.1\n"
        "  state        : %s\n"
        "  script       : %s\n"
        "  title        : %s\n"
        "  mode         : %s\n"
        "  strategy     : %s\n"
        "  safety       : %s\n"
        "  params       : %zu\n"
        "  presets      : %zu\n"
        "  praatExe     : %s\n"
        "  inBuf/outBuf : %s / %s\n"
        "  workspace    : %s\n"
        "  timeout      : %lu ms\n"
        "  visual       : %d\n"
        "  visual dpi   : %ld\n"
        "  fullTrust    : %d",
        x->processing.load()?"running":"idle",x->scriptPath->s_name,
        x->scriptTitle->c_str(),x->toolMode->c_str(),x->outputStrategy->c_str(),
        x->safetyState->c_str(),x->params->size(),x->presets->size(),x->praatExe,
        x->inBufName->s_name,x->outBufName->s_name,x->instDir,x->timeoutMs,(int)x->visualEnabled,x->visualDpi,(int)x->fullTrust);
    info_kv(x,"status",{x->processing.load()?"running":"idle",*x->toolMode,*x->outputStrategy,*x->safetyState,std::to_string(x->params->size()),std::to_string(x->presets->size())});
}

void AudioToolsPraat_debug(t_AudioToolsPraat* x, t_symbol*, long argc, t_atom* argv)
{
    if (argc < 1) {
        object_post((t_object*)x,"AudioTools.praat~: debug = %d",(int)x->debugKeep);
        return;
    }
    x->debugKeep = (atom_getlong(argv) != 0);
    object_post((t_object*)x,
        "AudioTools.praat~: debug -> %d (%s)",(int)x->debugKeep,
        x->debugKeep ? "run workspaces are kept" : "run workspaces are cleaned up");
}

void AudioToolsPraat_timeout(t_AudioToolsPraat* x, t_symbol* /*s*/,
                              long argc, t_atom* argv)
{
    if (argc < 1) {
        object_post((t_object*)x,
            "AudioTools.praat~: timeout = %lu ms", x->timeoutMs);
        return;
    }
    long ms = atom_getlong(argv);
    if (ms < 1000) ms = 1000;
    x->timeoutMs = (unsigned long)ms;
    object_post((t_object*)x,"AudioTools.praat~: timeout -> %lu ms", x->timeoutMs);
}

void AudioToolsPraat_set(t_AudioToolsPraat* x, t_symbol*, long argc, t_atom* argv)
{
    if (argc<2||atom_gettype(argv)!=A_SYM||atom_gettype(argv+1)!=A_SYM) {
        object_error((t_object*)x,"usage: set in|out <buffer_name>"); return;
    }
    t_symbol* which=atom_getsym(argv);
    t_symbol* name =atom_getsym(argv+1);
    if (which==gensym("in")) {
        x->inBufName=name;
        if (x->inBufRef) object_free(x->inBufRef);
        x->inBufRef=buffer_ref_new((t_object*)x,name);
        object_post((t_object*)x,"AudioTools.praat~: in -> '%s'",name->s_name);
    } else if (which==gensym("out")) {
        x->outBufName=name;
        if (x->outBufRef) object_free(x->outBufRef);
        x->outBufRef=buffer_ref_new((t_object*)x,name);
        object_post((t_object*)x,"AudioTools.praat~: out -> '%s'",name->s_name);
    } else {
        object_error((t_object*)x,"set: use 'in' or 'out'");
    }
}

void AudioToolsPraat_dsp64(t_AudioToolsPraat* x, t_object* dsp64,
                            short*, double, long, long)
{
    object_method(dsp64,gensym("dsp_add64"),x,
                  AudioToolsPraat_perform64,0,nullptr);
}

void AudioToolsPraat_perform64(t_AudioToolsPraat*, t_object*, double**, long,
                                double**, long, long, long, void*) {}

t_max_err AudioToolsPraat_notify(t_AudioToolsPraat* x, t_symbol* s,
                                  t_symbol* msg, void* sender, void* data)
{
    t_max_err e1=buffer_ref_notify(x->inBufRef, s,msg,sender,data);
    t_max_err e2=buffer_ref_notify(x->outBufRef,s,msg,sender,data);
    return (e1==MAX_ERR_NONE&&e2==MAX_ERR_NONE)?MAX_ERR_NONE:MAX_ERR_GENERIC;
}

void AudioToolsPraat_assist(t_AudioToolsPraat*, void*, long io, long index, char* s)
{
    if(io==ASSIST_INLET&&index==0) strcpy(s,"bang | script | describe | param | preset | reset | dump | scan | mode | strategy | visual | visualdpi | trust | stop/cancel | status");
    if(io==ASSIST_OUTLET&&index==0) strcpy(s,"bang: run completed / partial success");
    if(io==ASSIST_OUTLET&&index==1) strcpy(s,"bang: error / blocked / timeout / cancelled");
    if(io==ASSIST_OUTLET&&index==2) strcpy(s,"structured messages: describe, param, preset, value, safety, state, output, status");
}

// ═════════════════════════════════════════════════════════════════════════════
// SECTION 10 — ext_main
// ═════════════════════════════════════════════════════════════════════════════

extern "C" void ext_main(void*)
{
    t_class* c=class_new(
        "AudioTools.praat~",
        (method)AudioToolsPraat_new,
        (method)AudioToolsPraat_free,
        sizeof(t_AudioToolsPraat),
        (method)nullptr,A_GIMME,0);

    class_addmethod(c,(method)AudioToolsPraat_bang,    "bang",    0);
    class_addmethod(c,(method)AudioToolsPraat_send,    "send",    0);
    class_addmethod(c,(method)AudioToolsPraat_receive, "receive", 0);
    class_addmethod(c,(method)AudioToolsPraat_open,    "open",    0);
    class_addmethod(c,(method)AudioToolsPraat_stop,    "stop",    0);
    class_addmethod(c,(method)AudioToolsPraat_stop,    "cancel",  0);
    class_addmethod(c,(method)AudioToolsPraat_status,  "status",  0);
    class_addmethod(c,(method)AudioToolsPraat_describe,"describe",0);
    class_addmethod(c,(method)AudioToolsPraat_dump,    "dump",    0);
    class_addmethod(c,(method)AudioToolsPraat_reset,   "reset",   0);
    class_addmethod(c,(method)AudioToolsPraat_scan,    "scan",    0);
    class_addmethod(c,(method)AudioToolsPraat_param,   "param",   A_GIMME,0);
    class_addmethod(c,(method)AudioToolsPraat_preset,  "preset",  A_GIMME,0);
    class_addmethod(c,(method)AudioToolsPraat_mode,    "mode",    A_GIMME,0);
    class_addmethod(c,(method)AudioToolsPraat_strategy,"strategy",A_GIMME,0);
    class_addmethod(c,(method)AudioToolsPraat_visual,  "visual",  A_GIMME,0);
    class_addmethod(c,(method)AudioToolsPraat_visualdpi,"visualdpi",A_GIMME,0);
    class_addmethod(c,(method)AudioToolsPraat_trust,   "trust",   A_GIMME,0);
    class_addmethod(c,(method)AudioToolsPraat_library, "library", A_GIMME,0);
    class_addmethod(c,(method)AudioToolsPraat_python,  "python",  A_GIMME,0);
    class_addmethod(c,(method)AudioToolsPraat_debug,   "debug",   A_GIMME, 0);
    class_addmethod(c,(method)AudioToolsPraat_timeout, "timeout", A_GIMME, 0);
    class_addmethod(c,(method)AudioToolsPraat_set,     "set",     A_GIMME, 0);
    class_addmethod(c,(method)AudioToolsPraat_script,  "script",  A_GIMME, 0);
    class_addmethod(c,(method)AudioToolsPraat_praatexe,"praat",   A_GIMME, 0);
    class_addmethod(c,(method)AudioToolsPraat_dsp64,   "dsp64",   A_CANT,  0);
    class_addmethod(c,(method)AudioToolsPraat_notify,  "notify",  A_CANT,  0);
    class_addmethod(c,(method)AudioToolsPraat_assist,  "assist",  A_CANT,  0);

    class_dspinit(c);
    class_register(CLASS_BOX,c);
    s_AudioToolsPraat_class=c;

    post("AudioTools.praat~ v1.36.1 | v7 host preview: headless Pause virtualization, Praat Info capture, screen visualization, descriptor UI, live presets");
}
