autowatch = 1;

inlets = 1;
outlets = 0;

mgraphics.init();
mgraphics.relative_coords = 0;
mgraphics.autofill = 0;


// ============================================================
// AudioTools.praat.info.js - v1.36 hotfix
// Legacy Max jsui viewer for Praat Info output
//
// Connect AudioTools.praat~ outlet 3 directly to this jsui.
// It listens only to:
//   praat_info_begin
//   praat_info_line ...
//   praat_info_end
//
// All other messages are ignored.
// ============================================================


// ------------------------------------------------------------
// MODEL
// ------------------------------------------------------------

var lines = [];
var receiving = false;
var completed = false;

var scrollY = 0;
var autoFollow = true;

var maxLines = 2000;


// ------------------------------------------------------------
// LAYOUT
// ------------------------------------------------------------

var margin = 12;
var headerH = 38;
var footerH = 24;

var fontSize = 11;
var lineH = 17;

var wheelStep = 55;


// ------------------------------------------------------------
// COLOURS
// ------------------------------------------------------------

var COL_BG      = [0.105, 0.105, 0.115, 1];
var COL_PANEL   = [0.135, 0.135, 0.15, 1];
var COL_TEXT    = [0.92, 0.92, 0.94, 1];
var COL_MUTED   = [0.60, 0.60, 0.64, 1];
var COL_LINE    = [0.24, 0.24, 0.27, 1];
var COL_ACCENT  = [0.32, 0.62, 0.95, 1];
var COL_RUNNING = [0.86, 0.58, 0.22, 1];


// ============================================================
// INPUT
// ============================================================

function anything()
{
    var selector = messagename;
    var a = arrayfromargs(arguments);

    if (selector === "praat_info_begin") {
        beginInfo();
    }
    else if (selector === "praat_info_line") {
        appendInfoLine(a);
    }
    else if (selector === "praat_info_end") {
        endInfo();
    }

    // Ignore state/output/value/param/etc.
}


// ------------------------------------------------------------

function beginInfo()
{
    lines = [];
    scrollY = 0;

    receiving = true;
    completed = false;
    autoFollow = true;

    mgraphics.redraw();
}


// ------------------------------------------------------------

function appendInfoLine(a)
{
    var text = "";

    if (a.length > 0)
        text = atomsToText(a);

    lines.push(text);

    if (lines.length > maxLines)
        lines.splice(0, lines.length - maxLines);

    if (autoFollow)
        scrollToBottom();

    mgraphics.redraw();
}


// ------------------------------------------------------------

function endInfo()
{
    receiving = false;
    completed = true;

    if (autoFollow)
        scrollToBottom();

    mgraphics.redraw();
}


// ============================================================
// DRAW
// ============================================================

function paint()
{
    var w = getWidth();
    var h = getHeight();

    drawBackground(w, h);
    drawHeader(w);

    var contentTop = headerH;
    var contentBottom = h - footerH;
    var contentH = Math.max(1, contentBottom - contentTop);

    drawContent(w, contentTop, contentH);
    drawFooter(w, h);
    drawScrollbar(w, contentTop, contentH);
}


// ------------------------------------------------------------

function drawBackground(w, h)
{
    setColour(COL_BG);
    mgraphics.rectangle(0, 0, w, h);
    mgraphics.fill();
}


// ------------------------------------------------------------

function drawHeader(w)
{
    setColour(COL_PANEL);
    mgraphics.rectangle(0, 0, w, headerH);
    mgraphics.fill();

    drawText(
        "Praat Info",
        margin,
        23,
        14,
        COL_TEXT
    );

    var status = "idle";
    var statusColour = COL_MUTED;

    if (receiving) {
        status = "receiving";
        statusColour = COL_RUNNING;
    }
    else if (completed) {
        status = "completed";
        statusColour = COL_ACCENT;
    }

    var statusX = Math.max(margin + 100, w - 88);

    drawText(
        status,
        statusX,
        23,
        9,
        statusColour
    );

    setColour(COL_LINE);
    mgraphics.rectangle(0, headerH - 1, w, 1);
    mgraphics.fill();
}


// ------------------------------------------------------------

function drawContent(w, top, contentH)
{
    var textX = margin;
    var maxTextW = Math.max(40, w - margin * 2 - 10);

    var wrapped = buildWrappedLines(maxTextW);
    var totalH = wrapped.length * lineH;

    clampScroll(totalH, contentH);

    var y = top + margin - scrollY + fontSize;
    var firstY = top + fontSize;
    var lastY = top + contentH - 3;

    // Legacy Max jsui mgraphics has no clip() method.
    // Draw only rows whose baseline is inside the content area.
    for (var i = 0; i < wrapped.length; i++) {

        var row = wrapped[i];

        if (y >= firstY && y <= lastY) {
            var colour = row.blank ? COL_MUTED : COL_TEXT;
            drawText(row.text, textX, y, fontSize, colour);
        }

        y += lineH;
    }

    if (lines.length === 0) {
        drawText(
            "Praat Info will appear here after RUN.",
            margin,
            top + 30,
            10,
            COL_MUTED
        );
    }
}


// ------------------------------------------------------------

function drawFooter(w, h)
{
    var y = h - footerH;

    setColour(COL_PANEL);
    mgraphics.rectangle(0, y, w, footerH);
    mgraphics.fill();

    setColour(COL_LINE);
    mgraphics.rectangle(0, y, w, 1);
    mgraphics.fill();

    var info = lines.length + " lines";

    if (!autoFollow)
        info += "  |  manual scroll";

    drawText(
        info,
        margin,
        y + 16,
        9,
        COL_MUTED
    );
}


// ------------------------------------------------------------

function drawScrollbar(w, top, contentH)
{
    var wrapped = buildWrappedLines(
        Math.max(40, w - margin * 2 - 10)
    );

    var totalH = wrapped.length * lineH;

    if (totalH <= contentH)
        return;

    var trackX = w - 5;
    var trackW = 3;

    setColour([0.23, 0.23, 0.26, 1]);
    mgraphics.rectangle(trackX, top + 3, trackW, contentH - 6);
    mgraphics.fill();

    var visibleRatio = contentH / totalH;
    var thumbH = Math.max(18, (contentH - 6) * visibleRatio);

    var maxScroll = Math.max(1, totalH - contentH + margin * 2);
    var norm = clamp(scrollY / maxScroll, 0, 1);

    var travel = Math.max(1, contentH - 6 - thumbH);
    var thumbY = top + 3 + travel * norm;

    setColour(COL_MUTED);
    mgraphics.rectangle(trackX, thumbY, trackW, thumbH);
    mgraphics.fill();
}


// ============================================================
// WRAPPING
// ============================================================

function buildWrappedLines(maxWidth)
{
    var result = [];

    for (var i = 0; i < lines.length; i++) {

        var s = "" + lines[i];

        if (s.length === 0) {
            result.push({
                text: "",
                blank: true
            });
            continue;
        }

        var chunks = wrapLine(s, maxWidth);

        for (var j = 0; j < chunks.length; j++) {
            result.push({
                text: chunks[j],
                blank: false
            });
        }
    }

    return result;
}


// ------------------------------------------------------------

function wrapLine(text, maxWidth)
{
    // Conservative approximation that avoids relying on
    // text_measure differences between Max versions.
    var approxCharW = fontSize * 0.58;
    var maxChars = Math.max(
        8,
        Math.floor(maxWidth / approxCharW)
    );

    if (text.length <= maxChars)
        return [text];

    var words = text.split(" ");
    var out = [];
    var current = "";

    for (var i = 0; i < words.length; i++) {

        var word = words[i];

        // Very long token/path: split it safely.
        if (word.length > maxChars) {

            if (current.length > 0) {
                out.push(current);
                current = "";
            }

            var start = 0;

            while (start < word.length) {
                out.push(
                    word.substring(start, start + maxChars)
                );
                start += maxChars;
            }

            continue;
        }

        var candidate =
            current.length === 0
            ? word
            : current + " " + word;

        if (candidate.length <= maxChars) {
            current = candidate;
        }
        else {
            if (current.length > 0)
                out.push(current);

            current = word;
        }
    }

    if (current.length > 0)
        out.push(current);

    return out;
}


// ============================================================
// SCROLLING
// ============================================================

function onmousewheel(x, y, scrollx, scrolly, cmd, shift, capslock, option, ctrl)
{
    var amount = scrolly * wheelStep;

    scrollY += amount;

    autoFollow = false;

    clampScrollToCurrentContent();

    // If the user reaches the bottom again, resume following.
    if (isAtBottom())
        autoFollow = true;

    mgraphics.redraw();
}


// ------------------------------------------------------------

function onclick(x, y, but, cmd, shift, capslock, option, ctrl)
{
    // Double-click behaviour is handled by ondblclick below.
}


// ------------------------------------------------------------

function ondblclick(x, y, but, cmd, shift, capslock, option, ctrl)
{
    // Double-click returns to live-follow mode.
    autoFollow = true;
    scrollToBottom();
    mgraphics.redraw();
}


// ------------------------------------------------------------

function scrollToBottom()
{
    var w = getWidth();
    var h = getHeight();

    var contentH = Math.max(
        1,
        h - headerH - footerH
    );

    var wrapped = buildWrappedLines(
        Math.max(40, w - margin * 2 - 10)
    );

    var totalH = wrapped.length * lineH;

    scrollY = Math.max(
        0,
        totalH - contentH + margin * 2
    );
}


// ------------------------------------------------------------

function clampScrollToCurrentContent()
{
    var w = getWidth();
    var h = getHeight();

    var contentH = Math.max(
        1,
        h - headerH - footerH
    );

    var wrapped = buildWrappedLines(
        Math.max(40, w - margin * 2 - 10)
    );

    var totalH = wrapped.length * lineH;

    clampScroll(totalH, contentH);
}


// ------------------------------------------------------------

function clampScroll(totalH, contentH)
{
    var maxScroll = Math.max(
        0,
        totalH - contentH + margin * 2
    );

    scrollY = clamp(
        scrollY,
        0,
        maxScroll
    );
}


// ------------------------------------------------------------

function isAtBottom()
{
    var w = getWidth();
    var h = getHeight();

    var contentH = Math.max(
        1,
        h - headerH - footerH
    );

    var wrapped = buildWrappedLines(
        Math.max(40, w - margin * 2 - 10)
    );

    var totalH = wrapped.length * lineH;

    var maxScroll = Math.max(
        0,
        totalH - contentH + margin * 2
    );

    return Math.abs(scrollY - maxScroll) < 8;
}


// ============================================================
// PUBLIC MESSAGES
// ============================================================

function clear()
{
    lines = [];
    receiving = false;
    completed = false;

    scrollY = 0;
    autoFollow = true;

    mgraphics.redraw();
}


// ------------------------------------------------------------

function top()
{
    scrollY = 0;
    autoFollow = false;
    mgraphics.redraw();
}


// ------------------------------------------------------------

function bottom()
{
    autoFollow = true;
    scrollToBottom();
    mgraphics.redraw();
}


// ============================================================
// HELPERS
// ============================================================

function atomsToText(a)
{
    var parts = [];

    for (var i = 0; i < a.length; i++)
        parts.push("" + a[i]);

    return parts.join(" ");
}


// ------------------------------------------------------------

function drawText(text, x, y, size, colour)
{
    setColour(colour);

    mgraphics.select_font_face("Arial");
    mgraphics.set_font_size(size);

    mgraphics.move_to(x, y);
    mgraphics.show_text("" + text);
}


// ------------------------------------------------------------

function setColour(c)
{
    mgraphics.set_source_rgba(
        c[0],
        c[1],
        c[2],
        c[3]
    );
}


// ------------------------------------------------------------

function getWidth()
{
    return box.rect[2] - box.rect[0];
}


function getHeight()
{
    return box.rect[3] - box.rect[1];
}


// ------------------------------------------------------------

function clamp(v, minv, maxv)
{
    if (v < minv)
        return minv;

    if (v > maxv)
        return maxv;

    return v;
}


// ------------------------------------------------------------

function onresize(w, h)
{
    if (autoFollow)
        scrollToBottom();
    else
        clampScrollToCurrentContent();

    mgraphics.redraw();
}
