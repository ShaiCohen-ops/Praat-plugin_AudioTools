autowatch = 1;

inlets = 1;
outlets = 1;

mgraphics.init();
mgraphics.relative_coords = 0;
mgraphics.autofill = 0;


// ============================================================
// AudioTools.praat.ui.js
// Max jsui interface for AudioTools.praat~
// v0.4.2 - native numeric fields + conditional Pause groups
// ============================================================


// ------------------------------------------------------------
// MODEL
// ------------------------------------------------------------

var toolTitle = "AudioTools.praat~";
var toolState = "idle";
var safetyState = "";

var params = {};
var paramOrder = [];

var presets = [];
var currentPreset = 1;

var describing = false;

// The host owns visualization in hosted mode.
// Do NOT mirror the script's Draw_visualization default into this.
var hostVisual = 0;


// ------------------------------------------------------------
// LAYOUT
// ------------------------------------------------------------

var margin = 14;
var headerH = 46;
var presetH = 40;
var rowH = 30;
var groupH = 24;
var footerH = 48;

var hitAreas = [];

var activeDrag = null;
var dragStartX = 0;
var dragStartValue = 0;

// Native Max numeric entry boxes are created beside numeric sliders.
// They are real [flonum]/[number] UI objects, so values can be typed.
var numericEntries = {};
var numericListeners = {};
var numericEntryCallbacks = {};
var selfRectListener = null;

var openMenu = null;


// ------------------------------------------------------------
// COLOURS
// ------------------------------------------------------------

var COL_BG       = [0.105, 0.105, 0.115, 1];
var COL_PANEL    = [0.145, 0.145, 0.16, 1];
var COL_PANEL2   = [0.18, 0.18, 0.20, 1];
var COL_LINE     = [0.25, 0.25, 0.27, 1];
var COL_TEXT     = [0.93, 0.93, 0.95, 1];
var COL_MUTED    = [0.62, 0.62, 0.66, 1];
var COL_ACCENT   = [0.32, 0.62, 0.95, 1];
var COL_CONTROL  = [0.205, 0.205, 0.225, 1];
var COL_RUN      = [0.25, 0.56, 0.34, 1];
var COL_WARN     = [0.86, 0.55, 0.22, 1];
var COL_DISABLED = [0.28, 0.28, 0.30, 1];


// ============================================================
// MESSAGE INPUT
// ============================================================

function anything()
{
    var selector = messagename;
    var a = arrayfromargs(arguments);

    if (selector === "describe_begin") {
        handleDescribeBegin(a);
    }
    else if (selector === "param") {
        handleParam(a);
    }
    else if (selector === "preset") {
        handlePresetDescription(a);
    }
    else if (selector === "describe_end") {
        describing = false;
        mgraphics.redraw();
    }
    else if (selector === "value") {
        handleValue(a);
    }
    else if (selector === "preset_selected") {
        handlePresetSelected(a);
    }
    else if (selector === "state") {
        toolState = atomString(a[0]);
        mgraphics.redraw();
    }
    else if (selector === "safety") {
        safetyState = atomString(a[0]);
        mgraphics.redraw();
    }
    else if (selector === "output") {
        mgraphics.redraw();
    }
}


// ------------------------------------------------------------
// DESCRIBE BEGIN
// ------------------------------------------------------------

function handleDescribeBegin(a)
{
    describing = true;

    removeAllNumericEntries();

    params = {};
    paramOrder = [];
    presets = [];
    openMenu = null;
    activeDrag = null;

    if (a.length > 0)
        toolTitle = atomString(a[0]);

    mgraphics.redraw();
}


// ------------------------------------------------------------
// PARAM DESCRIPTION
// ------------------------------------------------------------

function handleParam(a)
{
    if (a.length < 3)
        return;

    var name = atomString(a[0]);
    var type = atomString(a[1]);
    var label = atomString(a[2]);

    var p = {
        name: name,
        type: type,
        label: cleanLabel(label),

        defaultValue: 0,
        value: 0,
        scriptValue: 0,

        options: [],
        role: "",
        group: "",
        whenParam: "",
        whenValue: "",

        hidden: false
    };

    var i = 3;

    while (i < a.length) {

        var key = atomString(a[i]);

        if (key === "default" && i + 1 < a.length) {
            p.defaultValue = a[i + 1];
            i += 2;
        }
        else if (key === "current" && i + 1 < a.length) {
            p.value = a[i + 1];
            p.scriptValue = a[i + 1];
            i += 2;
        }
        else if (key === "role" && i + 1 < a.length) {
            p.role = atomString(a[i + 1]);
            i += 2;
        }
        else if (key === "group" && i + 1 < a.length) {
            p.group = atomString(a[i + 1]);
            i += 2;
        }
        else if (key === "when" && i + 1 < a.length) {
            p.whenParam = atomString(a[i + 1]);
            i += 2;
        }
        else if (key === "whenvalue" && i + 1 < a.length) {
            p.whenValue = atomString(a[i + 1]);
            i += 2;
        }
        else if (key === "options") {
            i++;
            while (i < a.length) {
                p.options.push(atomString(a[i]));
                i++;
            }
        }
        else {
            i++;
        }
    }

    // Hosted playback belongs to Max, not Praat.
    if (p.role === "praat-playback")
        p.hidden = true;

    // Hosted visualization belongs to the host flag, not the script default.
    if (p.role === "visual")
        p.value = hostVisual;

    params[name] = p;
    paramOrder.push(name);

    if (isNumericParameter(p)) {
        ensureNumericEntry(p);
        syncNumericEntry(name);
    }

    if (name === "preset")
        currentPreset = parseInt(p.value);

    mgraphics.redraw();
}


// ------------------------------------------------------------
// PRESET DESCRIPTION
// preset 3 "Rhythmic Pulse" legacy-inferred 11
// ------------------------------------------------------------

function handlePresetDescription(a)
{
    if (a.length < 2)
        return;

    var n = parseInt(a[0]);
    var name = atomString(a[1]);

    presets[n] = name;
    mgraphics.redraw();
}


// ------------------------------------------------------------
// VALUE UPDATE
// ------------------------------------------------------------

function handleValue(a)
{
    if (a.length < 2)
        return;

    var name = atomString(a[0]);
    var value = a[1];

    if (params[name]) {
        params[name].scriptValue = value;

        if (params[name].role !== "visual")
            params[name].value = value;
    }

    if (name === "preset")
        currentPreset = parseInt(value);

    if (params[name] && isNumericParameter(params[name]))
        syncNumericEntry(name);

    mgraphics.redraw();
}


// ------------------------------------------------------------
// PRESET SELECTED
// ------------------------------------------------------------

function handlePresetSelected(a)
{
    if (a.length < 1)
        return;

    currentPreset = parseInt(a[0]);

    if (params.preset)
        params.preset.value = currentPreset;

    mgraphics.redraw();
}


// ============================================================
// DRAWING
// ============================================================

function paint()
{
    var w = getWidth();
    var h = getHeight();

    hitAreas = [];
    parkAllNumericEntries();

    background(w, h);
    drawHeader(w);

    var y = margin + headerH;
    y = drawPresetSection(y, w);

    var footerTop = h - footerH;

    var lastGroup = "";

    for (var i = 0; i < paramOrder.length; i++) {

        var name = paramOrder[i];
        var p = params[name];

        if (!p)
            continue;

        if (name === "preset")
            continue;

        if (p.hidden || !isParamVisible(p))
            continue;

        if (p.group !== "" && p.group !== lastGroup) {
            if (y + groupH + rowH > footerTop - 4)
                break;

            drawGroupHeader(p.group, y, w);
            y += groupH;
            lastGroup = p.group;
        }
        else if (p.group === "") {
            lastGroup = "";
        }

        // Keep footer clear if the jsui is made too short.
        if (y + rowH > footerTop - 4)
            break;

        drawParameterRow(p, y, w);
        y += rowH;
    }

    drawFooter(w, h);

    // Draw dropdown last, so it appears above all controls.
    if (openMenu)
        drawDropdown(openMenu, w, h);
}


// ------------------------------------------------------------

function background(w, h)
{
    setColour(COL_BG);
    mgraphics.rectangle(0, 0, w, h);
    mgraphics.fill();
}


// ------------------------------------------------------------
// HEADER
// ------------------------------------------------------------

function drawHeader(w)
{
    drawText(
        toolTitle,
        margin,
        margin + 17,
        15,
        COL_TEXT
    );

    drawText(
        "UI v4.2",
        Math.max(margin + 100, w - 62),
        margin + 17,
        9,
        COL_ACCENT
    );

    var status = toolState;

    if (safetyState !== "")
        status += "  |  safety: " + safetyState;

    drawText(
        status,
        margin,
        margin + 36,
        9,
        COL_MUTED
    );
}


// ------------------------------------------------------------
// PRESET
// ------------------------------------------------------------

function drawPresetSection(y, w)
{
    var x = margin;
    var width = w - margin * 2;
    var h = presetH - 6;

    drawRoundedRect(x, y, width, h, 5, COL_PANEL);

    drawText(
        "Preset",
        x + 10,
        y + 22,
        10,
        COL_MUTED
    );

    var presetName = getPresetName(currentPreset);

    drawText(
        presetName,
        x + 90,
        y + 22,
        11,
        COL_TEXT
    );

    drawText(
        "\u25BE",
        x + width - 20,
        y + 21,
        10,
        COL_MUTED
    );

    hitAreas.push({
        type: "presetMenu",
        x1: x,
        y1: y,
        x2: x + width,
        y2: y + h
    });

    return y + presetH;
}


// ------------------------------------------------------------
// CONDITIONAL PAUSE GROUPS
// ------------------------------------------------------------

function isParamVisible(p)
{
    if (!p || p.whenParam === "")
        return true;

    var controller = params[p.whenParam];

    if (!controller)
        return true;

    var expected = ("" + p.whenValue).toLowerCase();
    var current = "" + controller.value;

    // Direct scalar comparison first.
    if (current.toLowerCase() === expected)
        return true;

    // For choice/optionmenu controllers, a Praat condition usually compares
    // the string companion variable (e.g. algorithm$ = "Accelerando") while
    // Max stores the numeric option index. Resolve that index back to its label.
    if ((controller.type === "choice" || controller.type === "optionmenu") &&
        controller.options && controller.options.length > 0) {

        var idx = parseInt(controller.value);

        if (!isNaN(idx) && idx >= 1 && idx <= controller.options.length) {
            var label = ("" + controller.options[idx - 1]).toLowerCase();

            if (label === expected)
                return true;
        }
    }

    return false;
}


function drawGroupHeader(title, y, w)
{
    setColour(COL_PANEL);
    mgraphics.rectangle(margin, y + 3, w - margin * 2, groupH - 6);
    mgraphics.fill();

    drawText(
        title,
        margin + 9,
        y + 17,
        9,
        COL_ACCENT
    );
}


// ------------------------------------------------------------
// PARAM ROW
// ------------------------------------------------------------

function drawParameterRow(p, y, w)
{
    var labelX = margin;
    var controlX = Math.floor(w * 0.55);
    var controlW = w - controlX - margin;

    var di = displayInfo(p.name);

    drawText(
        di.label,
        labelX,
        y + 19,
        10,
        COL_TEXT
    );

    if (p.type === "boolean") {
        drawBoolean(p, controlX, y + 4, controlW, 22);
    }
    else if (p.type === "optionmenu" ||
             p.type === "choice") {
        drawOption(p, controlX, y + 4, controlW, 22);
    }
    else {
        drawNumeric(p, controlX, y + 4, controlW, 22);
    }

    setColour(COL_LINE);
    mgraphics.set_line_width(1);
    mgraphics.move_to(margin, y + rowH - 1);
    mgraphics.line_to(w - margin, y + rowH - 1);
    mgraphics.stroke();
}


// ------------------------------------------------------------
// BOOLEAN
// ------------------------------------------------------------

function drawBoolean(p, x, y, w, h)
{
    var enabled = parseFloat(p.value) !== 0;
    var bw = Math.min(52, w);

    drawRoundedRect(
        x,
        y,
        bw,
        h,
        4,
        enabled ? COL_ACCENT : COL_CONTROL
    );

    drawText(
        enabled ? "ON" : "OFF",
        x + 10,
        y + 15,
        9,
        COL_TEXT
    );

    hitAreas.push({
        type: "boolean",
        param: p.name,
        x1: x,
        y1: y,
        x2: x + bw,
        y2: y + h
    });
}


// ------------------------------------------------------------
// OPTION MENU
// ------------------------------------------------------------

function drawOption(p, x, y, w, h)
{
    drawRoundedRect(x, y, w, h, 4, COL_CONTROL);

    var n = parseInt(p.value);
    var text = "" + p.value;

    if (p.options.length > 0 &&
        n >= 1 &&
        n <= p.options.length) {
        text = p.options[n - 1];
    }

    drawText(
        text,
        x + 8,
        y + 15,
        9,
        COL_TEXT
    );

    drawText(
        "\u25BE",
        x + w - 17,
        y + 15,
        9,
        COL_MUTED
    );

    hitAreas.push({
        type: "option",
        param: p.name,
        x1: x,
        y1: y,
        x2: x + w,
        y2: y + h
    });
}


// ------------------------------------------------------------
// NUMERIC + SLIDER BAR
// ------------------------------------------------------------

function drawNumeric(p, x, y, w, h)
{
    var gap = 7;
    var entryW = Math.min(78, Math.max(62, Math.floor(w * 0.30)));
    var sliderW = Math.max(40, w - entryW - gap);
    var entryX = x + sliderW + gap;

    // Slider portion.
    drawRoundedRect(x, y, sliderW, h, 4, COL_CONTROL);

    var r = numericRange(p);
    var v = parseFloat(p.value);

    if (isNaN(v))
        v = 0;

    var norm = clamp(normalize(v, r.min, r.max), 0, 1);

    if (norm > 0) {
        setColour([COL_ACCENT[0], COL_ACCENT[1], COL_ACCENT[2], 0.22]);
        mgraphics.rectangle(x, y, sliderW * norm, h);
        mgraphics.fill();
    }

    // Keep a small value readout in the slider itself.
    // The native box on the right is the precise editable value.
    var di = displayInfo(p.name);
    var shownValue = v * di.scale;
    var sliderText = formatDisplayNumber(shownValue, p);

    if (di.unit !== "")
        sliderText += " " + di.unit;

    drawText(
        sliderText,
        x + 8,
        y + 15,
        9,
        COL_TEXT
    );

    // Reserve/softly mark the native number-box area in the jsui.
    drawRoundedRect(entryX, y, entryW, h, 4, COL_PANEL2);

    // Real Max [flonum]/[number] is positioned on top of this area.
    positionNumericEntry(p, entryX, y, entryW, h);

    // Only the slider portion responds to horizontal dragging.
    hitAreas.push({
        type: "numeric",
        param: p.name,
        x1: x,
        y1: y,
        x2: x + sliderW,
        y2: y + h
    });
}


// ------------------------------------------------------------
// FOOTER
// ------------------------------------------------------------

function drawFooter(w, h)
{
    var y = h - footerH + 9;

    // Cover anything underneath.
    setColour(COL_BG);
    mgraphics.rectangle(0, h - footerH, w, footerH);
    mgraphics.fill();

    var resetW = 78;
    var runW = 100;

    var resetX = w - margin - runW - resetW - 10;
    var runX = w - margin - runW;

    drawRoundedRect(
        resetX,
        y,
        resetW,
        28,
        5,
        COL_CONTROL
    );

    drawText(
        "RESET",
        resetX + 18,
        y + 19,
        10,
        COL_TEXT
    );

    var running = (toolState === "running");

    drawRoundedRect(
        runX,
        y,
        runW,
        28,
        5,
        running ? COL_DISABLED : COL_RUN
    );

    drawText(
        running ? "RUNNING..." : "RUN",
        runX + (running ? 20 : 35),
        y + 19,
        10,
        COL_TEXT
    );

    hitAreas.push({
        type: "reset",
        x1: resetX,
        y1: y,
        x2: resetX + resetW,
        y2: y + 28
    });

    hitAreas.push({
        type: "run",
        x1: runX,
        y1: y,
        x2: runX + runW,
        y2: y + 28
    });
}


// ------------------------------------------------------------
// DROPDOWN
// ------------------------------------------------------------

function drawDropdown(menu, w, h)
{
    var itemH = 25;
    var count = menu.options.length;

    if (count <= 0)
        return;

    var totalH = itemH * count;
    var menuY = menu.y;

    // If there is not enough room below, open upward.
    if (menuY + totalH > h - 4)
        menuY = Math.max(4, menu.anchorY - totalH);

    // Shadow.
    setColour([0, 0, 0, 0.28]);
    mgraphics.rectangle(menu.x + 3, menuY + 3, menu.w, totalH);
    mgraphics.fill();

    drawRoundedRect(
        menu.x,
        menuY,
        menu.w,
        totalH,
        4,
        COL_PANEL2
    );

    for (var i = 0; i < count; i++) {

        var yy = menuY + i * itemH;

        if (i + 1 === menu.current) {
            setColour([COL_ACCENT[0], COL_ACCENT[1], COL_ACCENT[2], 0.25]);
            mgraphics.rectangle(menu.x, yy, menu.w, itemH);
            mgraphics.fill();
        }

        drawText(
            menu.options[i],
            menu.x + 9,
            yy + 17,
            9,
            COL_TEXT
        );

        hitAreas.push({
            type: "dropdownItem",
            menuKind: menu.kind,
            param: menu.param,
            index: i + 1,
            x1: menu.x,
            y1: yy,
            x2: menu.x + menu.w,
            y2: yy + itemH
        });
    }

    openMenu.drawY = menuY;
}


// ============================================================
// MOUSE
// ============================================================

function onclick(x, y, but, cmd, shift, capslock, option, ctrl)
{
    var hit = findHit(x, y);

    // Dropdown selection has priority.
    if (hit && hit.type === "dropdownItem") {

        if (hit.menuKind === "preset") {
            currentPreset = hit.index;
            outlet(0, "preset", hit.index);
        }
        else {
            if (params[hit.param])
                params[hit.param].value = hit.index;

            outlet(0, "param", hit.param, hit.index);
        }

        closeDropdown();
        return;
    }

    // Clicking outside an open dropdown closes it first.
    if (openMenu) {
        closeDropdown();
        return;
    }

    if (!hit)
        return;

    if (hit.type === "run") {

        if (toolState !== "running")
            outlet(0, "bang");
    }

    else if (hit.type === "reset") {

        outlet(0, "reset");
    }

    else if (hit.type === "presetMenu") {

        var opts = [];

        if (params.preset && params.preset.options)
            opts = params.preset.options;

        if (opts.length === 0) {
            for (var i = 1; i < presets.length; i++) {
                if (presets[i])
                    opts.push(presets[i]);
            }
        }

        openDropdown(
            "preset",
            "preset",
            hit.x1 + 80,
            hit.y2,
            Math.max(150, hit.x2 - hit.x1 - 80),
            opts,
            currentPreset,
            hit.y1
        );
    }

    else if (hit.type === "boolean") {

        var p = params[hit.param];

        if (!p)
            return;

        var v = parseFloat(p.value) ? 0 : 1;
        p.value = v;

        if (p.role === "visual") {
            hostVisual = v;
            outlet(0, "visual", v);
        }
        else {
            outlet(0, "param", p.name, v);
        }

        mgraphics.redraw();
    }

    else if (hit.type === "option") {

        var op = params[hit.param];

        if (!op || op.options.length === 0)
            return;

        openDropdown(
            "param",
            hit.param,
            hit.x1,
            hit.y2,
            hit.x2 - hit.x1,
            op.options,
            parseInt(op.value),
            hit.y1
        );
    }

    else if (hit.type === "numeric") {

        var np = params[hit.param];

        if (!np)
            return;

        activeDrag = hit.param;
        dragStartX = x;
        dragStartValue = parseFloat(np.value);

        if (isNaN(dragStartValue))
            dragStartValue = 0;
    }
}


// ------------------------------------------------------------

function ondrag(x, y, but, cmd, shift, capslock, option, ctrl)
{
    if (!activeDrag)
        return;

    var p = params[activeDrag];

    if (!p)
        return;

    var r = numericRange(p);
    var dx = x - dragStartX;

    // Full control width is roughly one range.
    var pixelsForRange = 220;
    var step = (r.max - r.min) / pixelsForRange;

    if (shift)
        step *= 0.1;

    if (option || ctrl)
        step *= 0.1;

    var value = dragStartValue + dx * step;

    if (p.type === "integer" ||
        p.type === "natural") {
        value = Math.round(value);
    }

    if (p.type === "natural" && value < 0)
        value = 0;

    if (p.type === "positive" && value <= 0)
        value = Math.max(0.001, r.min);

    value = clamp(value, r.min, r.max);

    p.value = value;
    syncNumericEntry(p.name);

    outlet(
        0,
        "param",
        p.name,
        value
    );

    mgraphics.redraw();
}


// ------------------------------------------------------------

function onidleout()
{
    activeDrag = null;
}


// ------------------------------------------------------------

function onresize(w, h)
{
    mgraphics.redraw();
}


// ============================================================
// DROPDOWN HELPERS
// ============================================================

function openDropdown(kind, paramName, x, y, w, options, current, anchorY)
{
    openMenu = {
        kind: kind,
        param: paramName,
        x: x,
        y: y,
        w: w,
        options: options,
        current: current,
        anchorY: anchorY,
        drawY: y
    };

    mgraphics.redraw();
}


function closeDropdown()
{
    openMenu = null;
    mgraphics.redraw();
}


// ============================================================
// HIT TESTING
// ============================================================

function findHit(x, y)
{
    for (var i = hitAreas.length - 1; i >= 0; i--) {

        var h = hitAreas[i];

        if (x >= h.x1 &&
            x <= h.x2 &&
            y >= h.y1 &&
            y <= h.y2) {

            return h;
        }
    }

    return null;
}


// ============================================================
// NATIVE NUMERIC ENTRY BOXES
// ============================================================

function isNumericParameter(p)
{
    if (!p)
        return false;

    return !(
        p.type === "boolean" ||
        p.type === "optionmenu" ||
        p.type === "choice"
    );
}


// ------------------------------------------------------------

function ensureNumericEntry(p)
{
    if (!p || !isNumericParameter(p))
        return;

    var name = p.name;

    if (numericEntries[name] &&
        numericEntries[name].valid)
        return;

    var klass =
        (p.type === "integer" || p.type === "natural")
        ? "number"
        : "flonum";

    var obj = null;

    try {
        obj = this.patcher.newdefault(-1000, -1000, klass);
    }
    catch (e) {
        post("AudioTools.praat.ui.js: could not create numeric entry for ",
             name, ": ", e, "\n");
        return;
    }

    obj.varname = "__AudioTools_num_" + safeVarname(name);

    // Make the generated object visible and interactive in BOTH
    // ordinary patching view and Presentation Mode.
    try { obj.hidden = false; } catch (e0) {}
    try { obj.setboxattr("presentation", 1); } catch (e1) {}
    try { obj.setboxattr("ignoreclick", 0); } catch (e2) {}
    try { obj.setattr("fontsize", 10); } catch (e3) {}

    numericEntries[name] = obj;

    numericEntryCallbacks[name] = makeNumericEntryCallback(name);

    try {
        numericListeners[name] =
            new MaxobjListener(obj, numericEntryCallbacks[name]);
    }
    catch (e4) {
        post("AudioTools.praat.ui.js: could not listen to numeric entry ",
             name, ": ", e4, "\n");
    }

    // Native number boxes must sit ABOVE the jsui sibling.
    try { this.patcher.bringtofront(obj); } catch (e5) {}
}


// ------------------------------------------------------------

function makeNumericEntryCallback(name)
{
    return function(data)
    {
        handleNumericEntryValue(name, data);
    };
}


// ------------------------------------------------------------

function handleNumericEntryValue(name, data)
{
    var p = params[name];

    if (!p)
        return;

    var displayed = data.value;

    if (displayed instanceof Array)
        displayed = displayed[0];

    displayed = parseFloat(displayed);

    if (isNaN(displayed))
        return;

    var di = displayInfo(name);
    var scale = di.scale;

    if (!scale || scale === 0)
        scale = 1;

    // Entry uses the musician-facing display value.
    // Example: typing 15 in a "%" field sends 0.15 to Praat.
    var value = displayed / scale;

    if (p.type === "integer" || p.type === "natural")
        value = Math.round(value);

    if (p.type === "natural" && value < 0)
        value = 0;

    if (p.type === "positive" && value <= 0) {
        // Invalid for Praat "positive": restore the previous value.
        syncNumericEntry(name);
        return;
    }

    // Deliberately do NOT clamp typed values to numericRange().
    // numericRange() is a slider/UI heuristic, not authoritative metadata.
    p.value = value;

    // Natural/integer normalization may differ from what was typed.
    syncNumericEntry(name);

    outlet(0, "param", name, value);
    mgraphics.redraw();
}


// ------------------------------------------------------------

function syncNumericEntry(name)
{
    var p = params[name];
    var listener = numericListeners[name];

    if (!p || !listener)
        return;

    var value = parseFloat(p.value);

    if (isNaN(value))
        value = 0;

    var di = displayInfo(name);
    var displayed = value * di.scale;

    try {
        listener.setvalue_silent(displayed);
    }
    catch (e) {
        // Fallback for unusual UI objects / older Max builds.
        var obj = numericEntries[name];
        if (obj && obj.valid) {
            try { obj.message("set", displayed); } catch (e2) {}
        }
    }
}


// ------------------------------------------------------------

function positionNumericEntry(p, x, y, w, h)
{
    ensureNumericEntry(p);

    var obj = numericEntries[p.name];

    if (!obj || !obj.valid)
        return;

    // -------------------------
    // PATCHING MODE coordinates
    // box.rect = left, top, right, bottom
    // -------------------------
    var pr = box.rect;

    var patchLeft = Math.round(pr[0] + x);
    var patchTop = Math.round(pr[1] + y);

    try {
        obj.setboxattr(
            "patching_rect",
            [patchLeft, patchTop, Math.round(w), Math.round(h)]
        );
    }
    catch (e0) {
        // Fallback: Maxobj.rect uses L,T,R,B.
        try {
            obj.rect = [
                patchLeft,
                patchTop,
                patchLeft + Math.round(w),
                patchTop + Math.round(h)
            ];
        }
        catch (e1) {}
    }

    // -------------------------
    // PRESENTATION MODE coordinates
    // presentation_rect = x, y, width, height
    // -------------------------
    try {
        var pres = box.getboxattr("presentation_rect");

        if (pres && pres.length >= 4) {
            var presLeft = Math.round(parseFloat(pres[0]) + x);
            var presTop = Math.round(parseFloat(pres[1]) + y);

            obj.setboxattr("presentation", 1);
            obj.setboxattr(
                "presentation_rect",
                [presLeft, presTop, Math.round(w), Math.round(h)]
            );
        }
    }
    catch (e2) {}

    // Keep the native field above the jsui so it is not painted over.
    try { this.patcher.bringtofront(obj); } catch (e3) {}

    syncNumericEntry(p.name);
}


// ------------------------------------------------------------

function parkAllNumericEntries()
{
    for (var name in numericEntries) {
        var obj = numericEntries[name];

        if (obj && obj.valid) {
            try {
                obj.setboxattr(
                    "patching_rect",
                    [-1000, -1000, 70, 22]
                );
            }
            catch (e0) {}

            try {
                obj.setboxattr(
                    "presentation_rect",
                    [-1000, -1000, 70, 22]
                );
            }
            catch (e1) {}
        }
    }
}


// ------------------------------------------------------------

function removeAllNumericEntries()
{
    for (var name in numericEntries) {
        var obj = numericEntries[name];

        if (obj && obj.valid) {
            try {
                this.patcher.remove(obj);
            }
            catch (e) {}
        }
    }

    numericEntries = {};
    numericListeners = {};
    numericEntryCallbacks = {};
}


// ------------------------------------------------------------

function safeVarname(s)
{
    return ("" + s).replace(/[^A-Za-z0-9_]/g, "_");
}


// ------------------------------------------------------------
// Keep external number boxes attached when the jsui itself moves.
// ------------------------------------------------------------

function ensureSelfRectListener()
{
    if (selfRectListener)
        return;

    try {
        selfRectListener =
            new MaxobjListener(box, "patching_rect", selfRectChanged);
    }
    catch (e) {}
}


function selfRectChanged(data)
{
    mgraphics.redraw();
}


function loadbang()
{
    ensureSelfRectListener();
    mgraphics.redraw();

    // Do not request describe here: at Max startup the external may not
    // have a script loaded yet. Metadata is requested after script load,
    // and the manual refresh() command remains available.
}


function refresh()
{
    outlet(0, "describe");
}


function notifydeleted()
{
    removeAllNumericEntries();
}


// ============================================================
// PARAMETER DISPLAY
// ============================================================

function displayInfo(name)
{
    var info = {
        label: prettyLabel(name),
        unit: "",
        scale: 1
    };

    if (name === "grain_size_ms") {
        info.label = "Grain Size";
        info.unit = "ms";
    }
    else if (name === "analysis_overlap") {
        info.label = "Analysis Overlap";
        info.unit = "%";
        info.scale = 100;
    }
    else if (name === "number_of_states") {
        info.label = "States";
    }
    else if (name === "markov_order") {
        info.label = "Markov Order";
    }
    else if (name === "randomness") {
        info.label = "Randomness";
        info.unit = "%";
        info.scale = 100;
    }
    else if (name === "output_duration_sec") {
        info.label = "Duration";
        info.unit = "s";
    }
    else if (name === "synthesis_overlap") {
        info.label = "Synthesis Overlap";
        info.unit = "%";
        info.scale = 100;
    }
    else if (name === "varispeed_scatter_semitones") {
        info.label = "Varispeed Scatter";
        info.unit = "st";
    }
    else if (name === "position_jitter") {
        info.label = "Position Jitter";
        info.unit = "%";
        info.scale = 100;
    }
    else if (name === "density_variation") {
        info.label = "Density Variation";
        info.unit = "%";
        info.scale = 100;
    }
    else if (name === "stereo_decorrelation") {
        info.label = "Stereo Decorrelation";
        info.unit = "%";
        info.scale = 100;
    }
    else if (name === "random_seed") {
        info.label = "Random Seed";
    }
    else if (name === "draw_visualization") {
        info.label = "Visualization";
    }

    return info;
}


// ------------------------------------------------------------
// NUMERIC RANGES
//
// These are UI ranges only. They do not alter Praat semantics.
// ------------------------------------------------------------

function numericRange(p)
{
    var name = p.name;
    var d = absNumber(p.defaultValue);
    var v = absNumber(p.value);
    var base = Math.max(d, v);

    if (name === "grain_size_ms")
        return { min: 5, max: 500 };

    if (name === "analysis_overlap")
        return { min: 0, max: 0.95 };

    if (name === "number_of_states")
        return { min: 1, max: 32 };

    if (name === "randomness")
        return { min: 0, max: 1 };

    if (name === "output_duration_sec")
        return { min: 1, max: 120 };

    if (name === "synthesis_overlap")
        return { min: 0, max: 0.95 };

    if (name === "varispeed_scatter_semitones")
        return { min: -24, max: 24 };

    if (name === "position_jitter")
        return { min: 0, max: 1 };

    if (name === "density_variation")
        return { min: 0, max: 1 };

    if (name === "stereo_decorrelation")
        return { min: 0, max: 1 };

    if (name === "random_seed")
        return { min: 0, max: 99999 };


    // Generic fallback for other AudioTools scripts.
    if (p.type === "natural")
        return { min: 0, max: Math.max(10, base * 4) };

    if (p.type === "integer") {
        var im = Math.max(10, base * 4);
        return { min: -im, max: im };
    }

    if (p.type === "positive")
        return { min: 0.001, max: Math.max(1, base * 4) };

    // Real values around zero are commonly normalized controls.
    if (base <= 1)
        return { min: -1, max: 1 };

    var rm = Math.max(1, base * 4);
    return { min: -rm, max: rm };
}


// ============================================================
// DRAW HELPERS
// ============================================================

function drawText(text, x, y, size, colour)
{
    setColour(colour);

    mgraphics.select_font_face("Arial");
    mgraphics.set_font_size(size);

    mgraphics.move_to(x, y);
    mgraphics.show_text("" + text);
}


// ------------------------------------------------------------

function drawRoundedRect(x, y, w, h, radius, colour)
{
    setColour(colour);

    mgraphics.rectangle_rounded(
        x,
        y,
        w,
        h,
        radius,
        radius
    );

    mgraphics.fill();
}


// ------------------------------------------------------------

function setColour(c)
{
    mgraphics.set_source_rgba(
        c[0],
        c[1],
        c[2],
        c[3]
    );
}


// ============================================================
// UTILS
// ============================================================

function getWidth()
{
    return box.rect[2] - box.rect[0];
}


function getHeight()
{
    return box.rect[3] - box.rect[1];
}


function getPresetName(n)
{
    if (presets[n])
        return presets[n];

    if (params.preset &&
        params.preset.options &&
        n >= 1 &&
        n <= params.preset.options.length) {

        return params.preset.options[n - 1];
    }

    return "Preset " + n;
}


function cleanLabel(s)
{
    return ("" + s).replace(/_/g, " ");
}


function prettyLabel(s)
{
    var text = cleanLabel(s);

    if (text.length === 0)
        return text;

    return text.charAt(0).toUpperCase() + text.slice(1);
}


function atomString(a)
{
    if (a === undefined || a === null)
        return "";

    return "" + a;
}


function absNumber(v)
{
    var n = parseFloat(v);

    if (isNaN(n))
        return 0;

    return Math.abs(n);
}


function normalize(v, minv, maxv)
{
    if (maxv <= minv)
        return 0;

    return (v - minv) / (maxv - minv);
}


function clamp(v, minv, maxv)
{
    if (v < minv)
        return minv;

    if (v > maxv)
        return maxv;

    return v;
}


function formatDisplayNumber(v, p)
{
    if (p.type === "integer" ||
        p.type === "natural") {
        return "" + Math.round(v);
    }

    if (Math.abs(v - Math.round(v)) < 0.000001)
        return "" + Math.round(v);

    if (Math.abs(v) >= 100)
        return v.toFixed(1).replace(/0+$/, "").replace(/\.$/, "");

    if (Math.abs(v) >= 10)
        return v.toFixed(2).replace(/0+$/, "").replace(/\.$/, "");

    return v.toFixed(3).replace(/0+$/, "").replace(/\.$/, "");
}


// ============================================================
// MANUAL DEBUG COMMANDS
// ============================================================

function clear()
{
    removeAllNumericEntries();

    params = {};
    paramOrder = [];
    presets = [];

    currentPreset = 1;
    toolTitle = "AudioTools.praat~";
    toolState = "idle";
    safetyState = "";
    hostVisual = 0;

    openMenu = null;
    activeDrag = null;

    mgraphics.redraw();
}


function dumpmodel()
{
    post("\n--- AudioTools jsui model ---\n");
    post("title:", toolTitle, "\n");
    post("state:", toolState, "\n");
    post("preset:", currentPreset, getPresetName(currentPreset), "\n");
    post("hostVisual:", hostVisual, "\n");

    for (var i = 0; i < paramOrder.length; i++) {

        var p = params[paramOrder[i]];

        post(
            p.name,
            "type=",
            p.type,
            "value=",
            p.value,
            "role=",
            p.role,
            "\n"
        );
    }

    post("---------------------------\n");
}
