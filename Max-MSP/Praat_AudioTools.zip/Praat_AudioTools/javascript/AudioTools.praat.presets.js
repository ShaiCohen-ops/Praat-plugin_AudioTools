/* AudioTools.praat.presets.js
   inlet 0: structured messages from AudioTools.praat~ outlet 2
   inlet 1: 0-based umenu selection index
   outlet 0: commands for umenu
   outlet 1: messages back to AudioTools.praat~
*/
inlets = 2;
outlets = 2;

var presetNames = [];

function clearPresets() {
    presetNames = [];
    outlet(0, "clear");
}

function describe_begin() {
    if (inlet !== 0) return;
    clearPresets();
}

function preset() {
    if (inlet !== 0) return;
    var a = arrayfromargs(arguments);
    if (a.length < 2) return;
    var index1 = parseInt(a[0], 10);
    var name = String(a[1]);
    presetNames[index1 - 1] = name;
    outlet(0, ["append", name]);
}

function preset_selected() {
    if (inlet !== 0) return;
    var a = arrayfromargs(arguments);
    if (!a.length) return;
    var index1 = parseInt(a[0], 10);
    if (index1 > 0) outlet(0, ["set", index1 - 1]);
}

function msg_int(v) {
    if (inlet !== 1) return;
    var index1 = v + 1;
    if (index1 > 0) outlet(1, ["preset", index1]);
}

function bang() {
    if (inlet === 1) outlet(1, "describe");
}

function anything() {
    // Ignore other structured messages; this helper is intentionally preset-only.
}
