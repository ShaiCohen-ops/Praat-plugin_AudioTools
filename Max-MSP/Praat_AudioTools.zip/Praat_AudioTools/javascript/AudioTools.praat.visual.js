autowatch = 1;

inlets = 1;
outlets = 1;

mgraphics.init();
mgraphics.relative_coords = 0;
mgraphics.autofill = 0;

// ============================================================
// AudioTools.praat.visual.js
// jsui image viewer for AudioTools.praat~ v1.34+
// Receives structured outlet-3 messages from AudioTools.praat~.
// ============================================================

var imagePath = "";
var visualImage = null;
var imageW = 0;
var imageH = 0;
var state = "idle";
var lastError = "";

var COL_BG     = [0.105, 0.105, 0.115, 1];
var COL_PANEL  = [0.145, 0.145, 0.16, 1];
var COL_TEXT   = [0.93, 0.93, 0.95, 1];
var COL_MUTED  = [0.62, 0.62, 0.66, 1];
var COL_ACCENT = [0.32, 0.62, 0.95, 1];
var COL_ERROR  = [0.90, 0.36, 0.32, 1];

function anything()
{
    var selector = messagename;
    var a = arrayfromargs(arguments);

    if (selector === "output") {
        handleOutput(a);
    }
    else if (selector === "state") {
        if (a.length > 0)
            state = atomString(a[0]);
        mgraphics.redraw();
    }
    else if (selector === "visual") {
        // Host state only. The control jsui normally owns this toggle.
        mgraphics.redraw();
    }
}

function handleOutput(a)
{
    if (a.length < 2)
        return;

    var type = atomString(a[0]);
    if (type !== "image")
        return;

    // Normally the path is one Max symbol even if it contains spaces.
    // Joining the remainder makes this tolerant of alternate routing.
    var p = "";
    for (var i = 1; i < a.length; i++) {
        if (i > 1) p += " ";
        p += atomString(a[i]);
    }

    loadimage(p);
}

function loadimage(path)
{
    imagePath = path;
    lastError = "";

    if (visualImage) {
        try { visualImage.freepeer(); } catch (e0) {}
        visualImage = null;
    }

    // Verify the file first so a bad path produces useful feedback.
    var f = null;
    try {
        f = new File(path, "read");
    }
    catch (e1) {
        f = null;
    }

    if (!f || !f.isopen) {
        lastError = "Cannot open image file";
        if (f) try { f.close(); } catch (e2) {}
        mgraphics.redraw();
        return;
    }

    try { f.close(); } catch (e3) {}

    try {
        visualImage = new Image(1, 1);
        visualImage.read(path);

        var sz = visualImage.size;
        imageW = parseFloat(sz[0]);
        imageH = parseFloat(sz[1]);

        if (!(imageW > 1 && imageH > 1)) {
            lastError = "Image loaded with invalid size";
            try { visualImage.freepeer(); } catch (e4) {}
            visualImage = null;
        }
    }
    catch (e5) {
        lastError = "Image load failed: " + e5;
        visualImage = null;
        imageW = 0;
        imageH = 0;
    }

    mgraphics.redraw();
}

function paint()
{
    var w = box.rect[2] - box.rect[0];
    var h = box.rect[3] - box.rect[1];

    setColour(COL_BG);
    mgraphics.rectangle(0, 0, w, h);
    mgraphics.fill();

    var pad = 10;
    var headerH = 30;
    var x = pad;
    var y = headerH + 4;
    var vw = Math.max(1, w - pad * 2);
    var vh = Math.max(1, h - y - pad);

    drawText("Visualization", pad, 19, 11, COL_TEXT);

    if (state === "running")
        drawText("rendering...", w - 88, 19, 9, COL_ACCENT);

    drawRoundedRect(x, y, vw, vh, 4, COL_PANEL);

    if (visualImage && imageW > 0 && imageH > 0) {
        var scale = Math.min(vw / imageW, vh / imageH);
        var dw = imageW * scale;
        var dh = imageH * scale;
        var dx = x + (vw - dw) * 0.5;
        var dy = y + (vh - dh) * 0.5;

        mgraphics.save();
        mgraphics.translate(dx, dy);
        mgraphics.scale(scale, scale);
        mgraphics.image_surface_draw(visualImage);
        mgraphics.restore();
    }
    else if (lastError !== "") {
        drawText(lastError, x + 12, y + 24, 10, COL_ERROR);
        drawText(shortPath(imagePath, 62), x + 12, y + 43, 8, COL_MUTED);
    }
    else {
        drawText("Turn Visualization ON, then RUN", x + 12, y + 25, 10, COL_MUTED);
        drawText("The latest Praat Picture will appear here.", x + 12, y + 44, 9, COL_MUTED);
    }
}

function onclick(x, y, but, cmd, shift, capslock, option, ctrl)
{
    // Clicking the viewer asks the host to enable visualization.
    // This is convenient when the viewer is used without the control jsui.
    if (!visualImage)
        outlet(0, "visual", 1);
}

function onresize(w, h)
{
    mgraphics.redraw();
}

function clear()
{
    if (visualImage) {
        try { visualImage.freepeer(); } catch (e) {}
    }
    visualImage = null;
    imagePath = "";
    imageW = 0;
    imageH = 0;
    lastError = "";
    state = "idle";
    mgraphics.redraw();
}

function drawText(text, x, y, size, colour)
{
    setColour(colour);
    mgraphics.select_font_face("Arial");
    mgraphics.set_font_size(size);
    mgraphics.move_to(x, y);
    mgraphics.show_text("" + text);
}

function drawRoundedRect(x, y, w, h, r, colour)
{
    setColour(colour);
    mgraphics.rectangle_rounded(x, y, w, h, r, r);
    mgraphics.fill();
}

function setColour(c)
{
    mgraphics.set_source_rgba(c[0], c[1], c[2], c[3]);
}

function atomString(a)
{
    if (a === undefined || a === null)
        return "";
    return "" + a;
}

function shortPath(s, maxLen)
{
    if (!s) return "";
    if (s.length <= maxLen) return s;
    return "..." + s.substring(s.length - (maxLen - 3));
}
