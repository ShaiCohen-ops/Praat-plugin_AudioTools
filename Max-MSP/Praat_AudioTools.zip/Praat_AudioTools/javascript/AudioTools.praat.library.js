/*
    AudioTools.praat.library.js
    Dynamic Praat AudioTools library scanner for Max 9.

    Search priority on Windows:
      1. <Max package>/misc/plugin_AudioTools
      2. ~/AppData/Roaming/Praat/plugin_AudioTools
      3. ~/Praat/plugin_AudioTools

    Duplicate scripts are removed by relative path; the first root wins.

    Inlet 0:
      scan

    Inlet 1:
      selected umenu index

    Outlet 0:
      commands for umenu (clear, append, set)

    Outlet 1:
      resolved absolute script path
*/

autowatch = 0;
inlets = 2;
outlets = 2;

var scripts = [];

function normalizePath(p)
{
    if (!p) return "";
    p = String(p).replace(/\\/g, "/");
    while (p.length > 1 && p.charAt(p.length - 1) === "/")
        p = p.substring(0, p.length - 1);
    return p;
}

function ensureSlash(p)
{
    p = normalizePath(p);
    return p === "" ? "" : p + "/";
}

function dirname(p)
{
    p = normalizePath(p);
    var i = p.lastIndexOf("/");
    return i >= 0 ? p.substring(0, i) : "";
}

function packageLibraryRoot()
{
    try {
        var patchFile = normalizePath(this.patcher.filepath);
        if (patchFile === "")
            return "";

        // .../praat/patchers/praat.maxpat
        var patchersDir = dirname(patchFile);
        var packageDir = dirname(patchersDir);

        if (packageDir === "")
            return "";

        return ensureSlash(packageDir + "/misc/plugin_AudioTools");
    }
    catch (e) {
        return "";
    }
}

function isPraatFile(name)
{
    name = String(name).toLowerCase();
    return name.length >= 6 &&
           name.substring(name.length - 6) === ".praat";
}

function scanFolder(root, relativePrefix, results)
{
    root = ensureSlash(root);

    var folder;
    try {
        folder = new Folder(root);
    }
    catch (e) {
        return;
    }

    try {
        while (!folder.end) {
            var name = folder.filename;

            if (name &&
                name !== "." &&
                name !== "..") {

                var full = root + name;
                var rel = relativePrefix + name;
                var type = String(folder.filetype).toLowerCase();

                if (type === "fold") {
                    scanFolder(full, rel + "/", results);
                }
                else if (isPraatFile(name)) {
                    results.push({
                        rel: rel,
                        abs: normalizePath(full)
                    });
                }
            }

            folder.next();
        }
    }
    catch (e2) {
        // A single unreadable directory must not abort the whole scan.
    }

    try {
        folder.close();
    }
    catch (e3) {
    }
}

function scanRoot(root)
{
    var found = [];
    scanFolder(root, "", found);

    found.sort(function(a, b) {
        var aa = a.rel.toLowerCase();
        var bb = b.rel.toLowerCase();
        if (aa < bb) return -1;
        if (aa > bb) return 1;
        return 0;
    });

    return found;
}

function scan()
{
    if (inlet !== 0)
        return;

    scripts = [];

    var roots = [
        packageLibraryRoot(),
        "~/AppData/Roaming/Praat/plugin_AudioTools/",
        "~/Praat/plugin_AudioTools/"
    ];

    var seen = {};
    var totalPerRoot = [];

    outlet(0, "clear");

    for (var r = 0; r < roots.length; r++) {
        var root = roots[r];

        if (!root || root === "") {
            totalPerRoot.push(0);
            continue;
        }

        var found = scanRoot(root);
        totalPerRoot.push(found.length);

        for (var i = 0; i < found.length; i++) {
            var key = found[i].rel.toLowerCase();

            if (seen[key])
                continue;

            seen[key] = 1;
            scripts.push(found[i]);
        }
    }

    scripts.sort(function(a, b) {
        var aa = a.rel.toLowerCase();
        var bb = b.rel.toLowerCase();
        if (aa < bb) return -1;
        if (aa > bb) return 1;
        return 0;
    });

    for (var j = 0; j < scripts.length; j++)
        outlet(0, "append", scripts[j].rel);

    if (scripts.length > 0)
        outlet(0, "set", 0);

    post("\nAudioTools.praat library scan\n");
    post("  package : " + roots[0] + " -> " + totalPerRoot[0] + " .praat files\n");
    post("  roaming : " + roots[1] + " -> " + totalPerRoot[1] + " .praat files\n");
    post("  profile : " + roots[2] + " -> " + totalPerRoot[2] + " .praat files\n");
    post("  unique  : " + scripts.length + " .praat files\n");
    post("  priority: package > roaming > profile\n");
}

function msg_int(v)
{
    if (inlet !== 1)
        return;

    var index = parseInt(v, 10);

    if (isNaN(index) ||
        index < 0 ||
        index >= scripts.length)
        return;

    outlet(1, scripts[index].abs);
}

function anything()
{
    if (inlet === 0 && String(messagename) === "scan")
        scan();
}
