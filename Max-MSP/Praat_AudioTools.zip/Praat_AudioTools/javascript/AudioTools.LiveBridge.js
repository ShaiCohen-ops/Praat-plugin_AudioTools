autowatch = 0;

inlets = 1;
outlets = 2;

// AudioTools.LiveBridge.js
// v1.6 - Ableton Live 12.3
//
// live.path resolves Song + Track in the Max patcher.
// Send the resulting IDs here:
//   songid <n>
//   trackid <n>
//
// IMPORTANT FIX from v1.5:
// LiveAPI object IDs are bound using the canonical "id N" form,
// e.g. new LiveAPI(noop, "id 4").
//
// Audio:
//   import <absolute-path>
//   output audio <absolute-path>
//
// Status:
//   status

var songId = 0;
var trackId = 0;

var songApi = null;
var trackApi = null;
var ready = 0;

var lastPath = "";

var beforeCount = 0;
var pendingPath = "";
var pendingPosition = 0;
var verifyTask = null;

function noop(args)
{
}

function songid(v)
{
    songId = parseInt(v, 10);

    post("AudioTools.LiveBridge v1.6: songid " +
         songId + "\n");

    bindIfPossible();
}

function trackid(v)
{
    trackId = parseInt(v, 10);

    post("AudioTools.LiveBridge v1.6: trackid " +
         trackId + "\n");

    bindIfPossible();
}

function bindIfPossible()
{
    ready = 0;

    if (songId <= 0 || trackId <= 0)
        return;

    try {
        var songRef = "id " + songId;
        var trackRef = "id " + trackId;

        songApi = new LiveAPI(noop, songRef);
        trackApi = new LiveAPI(noop, trackRef);

        var sid = Number(songApi.id);
        var tid = Number(trackApi.id);

        post("AudioTools.LiveBridge v1.6: bound song id=" +
             sid + " type=" + songApi.type + "\n");

        post("AudioTools.LiveBridge v1.6: bound track id=" +
             tid + " type=" + trackApi.type + "\n");

        if (!(sid > 0))
            throw new Error("Song ID did not bind");

        if (!(tid > 0))
            throw new Error("Track ID did not bind");

        ready = 1;

        outlet(0, "ready");
        post("AudioTools.LiveBridge v1.6: READY\n");
    }
    catch (e) {
        ready = 0;

        outlet(0, "bind_error");
        post("AudioTools.LiveBridge v1.6: BIND ERROR: " +
             e + "\n");
    }
}

function status()
{
    post("\nAudioTools.LiveBridge v1.6 STATUS\n");
    post("  ready = " + ready + "\n");
    post("  songId = " + songId + "\n");
    post("  trackId = " + trackId + "\n");

    if (songApi)
        post("  songApi.id = " + songApi.id +
             " type=" + songApi.type + "\n");

    if (trackApi)
        post("  trackApi.id = " + trackApi.id +
             " type=" + trackApi.type + "\n");

    if (lastPath !== "")
        post("  lastPath = " + lastPath + "\n");
}

function bang()
{
    if (lastPath === "") {
        outlet(0, "no_audio_path");
        post("AudioTools.LiveBridge v1.6: no stored path\n");
        return;
    }

    insertAtPlayhead(lastPath);
}

function path()
{
    var a = arrayfromargs(arguments);

    lastPath =
        normalizePath(joinAtoms(a));

    post("AudioTools.LiveBridge v1.6: stored path = " +
         lastPath + "\n");
}

function output()
{
    var a = arrayfromargs(arguments);

    if (a.length < 2)
        return;

    if (String(a[0]) !== "audio")
        return;

    insertAtPlayhead(
        normalizePath(joinAtoms(a.slice(1)))
    );
}

function insert()
{
    insertAtPlayhead(
        normalizePath(
            joinAtoms(arrayfromargs(arguments))
        )
    );
}

function importfile()
{
    insertAtPlayhead(
        normalizePath(
            joinAtoms(arrayfromargs(arguments))
        )
    );
}

function anything()
{
    var name = String(messagename);
    var a = arrayfromargs(arguments);

    if (name === "import" ||
        name === "sendtolive") {

        insertAtPlayhead(
            normalizePath(joinAtoms(a))
        );

        return;
    }

    if (a.length === 0 &&
        looksLikeAudioPath(name)) {

        insertAtPlayhead(
            normalizePath(name)
        );

        return;
    }

    post("AudioTools.LiveBridge v1.6: ignored " +
         name + "\n");
}

function insertAtPlayhead(p)
{
    if (!ready) {
        outlet(0, "not_ready");
        post("AudioTools.LiveBridge v1.6: NOT READY\n");
        return;
    }

    p = normalizePath(p);

    if (p === "") {
        outlet(0, "empty_path");
        return;
    }

    try {
        var raw =
            songApi.get("current_song_time");

        var position =
            firstNumber(raw);

        if (!isFinite(position))
            throw new Error(
                "Could not read current_song_time"
            );

        beforeCount =
            arrangementClipCount();

        pendingPath = p;
        pendingPosition = position;

        post("\nAudioTools.LiveBridge v1.6: INSERT REQUEST\n");
        post("  song id = " + songApi.id + "\n");
        post("  track id = " + trackApi.id + "\n");
        post("  position = " + position + "\n");
        post("  clips before = " + beforeCount + "\n");
        post("  file = " + p + "\n");

        var result =
            trackApi.call(
                "create_audio_clip",
                p,
                position
            );

        post("  create_audio_clip returned = " +
             valueToString(result) + "\n");

        verifyTask =
            new Task(verifyInsert, this);

        verifyTask.schedule(300);
    }
    catch (e) {
        outlet(0, "insert_error");

        post("AudioTools.LiveBridge v1.6: INSERT ERROR: " +
             e + "\n");
    }
}

function verifyInsert()
{
    try {
        var afterCount =
            arrangementClipCount();

        post("  clips after = " +
             afterCount + "\n");

        if (afterCount > beforeCount) {
            lastPath = pendingPath;

            outlet(
                0,
                "inserted",
                pendingPath,
                pendingPosition
            );

            outlet(1, "bang");

            post(
                "AudioTools.LiveBridge v1.6: VERIFIED INSERT at " +
                pendingPosition + " beats\n"
            );
        }
        else {
            outlet(0, "insert_failed");

            post(
                "AudioTools.LiveBridge v1.6: INSERT FAILED - " +
                "Arrangement clip count did not increase\n"
            );
        }
    }
    catch (e) {
        outlet(0, "verify_error");

        post(
            "AudioTools.LiveBridge v1.6: VERIFY ERROR: " +
            e + "\n"
        );
    }
}

function arrangementClipCount()
{
    try {
        return trackApi.getcount(
            "arrangement_clips"
        );
    }
    catch (e) {
        var v =
            trackApi.get(
                "arrangement_clips"
            );

        if (!(v instanceof Array))
            return 0;

        var n = 0;

        for (var i = 0;
             i < v.length;
             i++) {

            if (String(v[i]) === "id" &&
                i + 1 < v.length) {

                var id =
                    parseInt(v[i + 1], 10);

                if (!isNaN(id) &&
                    id > 0)
                    n++;
            }
        }

        return n;
    }
}

function firstNumber(v)
{
    if (typeof v === "number")
        return v;

    if (v instanceof Array) {
        for (var i = 0;
             i < v.length;
             i++) {

            var n =
                parseFloat(v[i]);

            if (!isNaN(n))
                return n;
        }
    }

    var n2 =
        parseFloat(v);

    return isNaN(n2)
        ? NaN
        : n2;
}

function valueToString(v)
{
    if (v === null)
        return "null";

    if (typeof v === "undefined")
        return "undefined";

    if (v instanceof Array)
        return "[" +
               v.join(", ") +
               "]";

    return String(v);
}

function joinAtoms(a)
{
    if (!a ||
        a.length === 0)
        return "";

    var s = "";

    for (var i = 0;
         i < a.length;
         i++) {

        if (i > 0)
            s += " ";

        s += String(a[i]);
    }

    return stripOuterQuotes(s);
}

function normalizePath(p)
{
    p =
        stripOuterQuotes(
            String(p)
        );

    return p.replace(
        /\\/g,
        "/"
    );
}

function stripOuterQuotes(s)
{
    if (s.length >= 2) {
        var a = s.charAt(0);
        var b =
            s.charAt(
                s.length - 1
            );

        if ((a === '"' &&
             b === '"') ||
            (a === "'" &&
             b === "'")) {

            return s.substring(
                1,
                s.length - 1
            );
        }
    }

    return s;
}

function looksLikeAudioPath(s)
{
    s =
        String(s).toLowerCase();

    return endsWith(s, ".wav") ||
           endsWith(s, ".aif") ||
           endsWith(s, ".aiff") ||
           endsWith(s, ".flac") ||
           endsWith(s, ".mp3");
}

function endsWith(s, suffix)
{
    return s.indexOf(
        suffix,
        s.length - suffix.length
    ) !== -1;
}
