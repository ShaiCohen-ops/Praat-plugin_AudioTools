# ============================================================
# Praat AudioTools - Wave_Shaper_Distortion.praat
# Author: Shai Cohen
# Affiliation: Department of Music, Bar-Ilan University, Israel
# Email: shai.cohen@biu.ac.il
# Version: 0.5 (2025)
# License: MIT License
# Repository: https://github.com/ShaiCohen-ops/Praat-plugin_AudioTools
#
# Description:
#   Wave Shaper Distortion - comprehensive waveshaping toolkit
#   with 12 different transfer function algorithms and 5
#   processing modes. From subtle saturation to extreme folding.
#   Includes frequency-split, asymmetric, multi-stage, and
#   stereo M/S processing options.
#
# Algorithms:
#   1. Hyperbolic Tangent (soft clip)
#   2. Sine Fold (warm harmonics)
#   3. Arc Tangent (smooth saturation)
#   4. Polynomial (gentle curve)
#   5. Absolute Value (rectifier)
#   6. Square Law (fuzzy)
#   7. Chebyshev (harmonic control)
#   8. Sigmoid (tube-like)
#   9. Exponential Saturation (smooth, hyperbolic)
#   10. Bitcrush (lo-fi)
#   11. Wave Wrap (true periodic fold)
#   12. Diode Ladder (analog asymmetric)
#
# Changelog v0.5 (second review round):
#   - The transfer-function graph now subtracts the SAME DC offset
#     that "Subtract mean" actually removed from the real Sound
#     (captured per pass into dc_offset_standard/low/high/asym/
#     stage[]/mid/side), instead of the raw un-corrected curve. The
#     graph and the audio no longer disagree at e.g. Chebyshev+silence.
#   - Frequency Split and Stereo Wide graph curves now include the
#     global dry/wet mix, like every other mode; captions spell out
#     what's still not representable pointwise (band recombination /
#     L=Mid+Side & R=Mid-Side reconstruction, and the output-level
#     stage).
#   - Stereo Wide now falls back to Standard mode (with a warning) up
#     front for non-stereo input, the same way Frequency Split falls
#     back for too-low a sample rate - so mode/info/graph always agree
#     on what actually ran, instead of a hidden fallback one level down.
#   - writeInfoLine now runs before the Mix_percent/Frequency-Split/
#     Stereo-Wide validation checks, so their WARNING lines are no
#     longer silently erased when the Info window is (re)initialized.
#   - Output level: the peak is now also measured and reported AFTER
#     the output stage, not just before it.
#
# Changelog v0.4 (review fixes):
#   - Chebyshev (and every algorithm): DC blocking ("Subtract mean")
#     applied after each waveshaping pass, so silence can no longer
#     turn into a DC offset that normalization then blows up to 0.95.
#   - Transfer-function graph is now mode-aware: Standard/Asymmetric/
#     Multi-Stage show the true cascaded, mix-included curve; Frequency
#     Split and Stereo Wide show their two underlying per-band/per-
#     channel curves instead of a single misleading broadband curve.
#     Normalization (peak-dependent) is explicitly noted as not shown.
#   - Removed the +/-1.4 graphic clamp; the Y axis is now computed
#     from the actual function range so large excursions are visible.
#   - Renamed "Exponential Fold" to "Exponential Saturation" - the
#     function is a bounded, monotonic tanh-like curve, not a fold.
#   - "Wave Wrap" now implements a genuine periodic triangle-wave
#     fold (repeated reflection via modulo) instead of a single
#     one-time reflection that diverges again above |x|=3.
#   - Mix_percent is now a real-valued field, clamped to 0-100 with
#     a warning if the user enters something outside that range
#     (previously 150% silently produced a negative dry component).
#   - Normalize (boolean) replaced with an Output_level choice:
#     Preserve / Limiter (cap at 0.95) / Normalize (scale to 0.95).
#     Peak is measured first; silent output skips scaling instead of
#     amplifying noise or dividing by (near) zero.
#   - Frequency Split checks that the Nyquist frequency actually
#     clears the 800 Hz split (with headroom for the 100 Hz Hann
#     smoothing) and falls back to Standard mode with a warning if not.
#   - Zoom panel now reads the Sound's actual start/end time instead
#     of assuming xmin = 0, so it zooms into the real beginning of
#     the extracted Sound.
#   - Channel handling distinguishes mono / stereo / >2-channel input
#     for Stereo Wide, instead of reporting any non-stereo input as
#     "Mono input".
#
# Changelog v0.3:
#   - Removed a duplicated input-check block and a duplicated
#     section comment (copy-paste artifacts).
#   - Stereo Wide (M/S): free the extracted left/right channels
#     after Combine to stereo (they were leaking into the object list).
#
# Changelog v0.2:
#   - Fixed input check
#   - Fixed selection syntax (use object IDs)
#   - Fixed formula syntax (string building)
#   - Fixed procedure call syntax (@)
#   - Fixed frequency split high band filter
#   - Fixed M/S stereo mode
#   - Added visualization
#   - Added info output
# ============================================================

form Wave Shaper Distortion
    comment Select a Sound object first
    comment Note: every algorithm is automatically mean-centred (DC removed) after each pass.
    
    comment === Waveshaping Algorithm ===
    choice Shape 1
        option 1. Hyperbolic Tangent (soft)
        option 2. Sine Fold (warm)
        option 3. Arc Tangent (smooth)
        option 4. Polynomial (aggressive)
        option 5. Absolute Value (digital)
        option 6. Square Law (fuzzy)
        option 7. Chebyshev (harmonic)
        option 8. Sigmoid (tube-like)
        option 9. Exponential Saturation (smooth)
        option 10. Bitcrush (lo-fi)
        option 11. Wave Wrap (periodic fold)
        option 12. Diode Ladder (analog)
    
    comment === Parameters ===
    positive Drive 2.0
    real Mix_percent 80
    
    comment === Processing Mode ===
    optionmenu Mode 1
        option Standard
        option Frequency Split (800 Hz)
        option Asymmetric (+/- different)
        option Multi-Stage (3x cascade)
        option Stereo Wide (M/S)
    
    comment === Output ===
    optionmenu Output_level 3
        option Preserve (no gain change)
        option Limiter (cap peak at 0.95)
        option Normalize (scale peak to 0.95)
    boolean Draw_visualization 1
    boolean Play_result 1
endform

# === Check Input ===
if numberOfSelected("Sound") <> 1
    exitScript: "Please select exactly one Sound object."
endif

original = selected("Sound")
original_name$ = selected$("Sound")

# Start the Info window now, before any validation warnings are
# printed. writeInfoLine: clears the window - if it ran after the
# Mix_percent/Frequency-Split checks below, it would silently wipe
# out any WARNING lines they had already written.
writeInfoLine: "=== Wave Shaper Distortion ==="

selectObject: original
duration = Get total duration
sr = Get sampling frequency
numChannels = Get number of channels

# Classify channel layout: mono / stereo / multichannel (>2)
# (Stereo Wide / M/S is only meaningful for exactly 2 channels.)
if numChannels = 1
    channel_mode$ = "mono"
    is_stereo = 0
elsif numChannels = 2
    channel_mode$ = "stereo"
    is_stereo = 1
else
    channel_mode$ = "multichannel"
    is_stereo = 0
endif

# === Clamp Mix_percent to 0-100 ===
# (Values outside this range would make the dry component negative
# or add more than 100% wet, which is not what "% Mix" promises.)
if mix_percent < 0
    appendInfoLine: "WARNING: Mix_percent (", mix_percent, ") below 0; clamped to 0."
    mix_percent = 0
elsif mix_percent > 100
    appendInfoLine: "WARNING: Mix_percent (", mix_percent, ") above 100; clamped to 100."
    mix_percent = 100
endif
mix_frac_g = mix_percent / 100
dry_frac_g = 1 - mix_frac_g

# === Frequency Split validity check ===
# The high band needs the Nyquist frequency to clear the split point
# with room for the 100 Hz Hann smoothing skirt.
freq_split_target = 800
if mode = 2 and (sr / 2) <= (freq_split_target + 100)
    appendInfoLine: "WARNING: Sampling rate too low for an 800 Hz split (Nyquist = ", fixed$(sr/2, 1), " Hz). Falling back to Standard mode."
    mode = 1
endif

# === Stereo Wide validity check ===
# M/S only makes sense for exactly 2 channels; fall back the same
# way Frequency Split does, so mode/graph/info all agree on what
# actually ran (instead of a mode=5 label with Standard processing
# hidden a level down).
if mode = 5 and is_stereo = 0
    appendInfoLine: "WARNING: Stereo Wide needs a 2-channel Sound (input is ", channel_mode$, "). Falling back to Standard mode."
    mode = 1
endif

# === Get Shape and Mode Names ===
@getShapeName: shape
@getModeName: mode
@getOutputLevelName: output_level

# === Info ===
appendInfoLine: "Source: ", original_name$, " (", fixed$(duration, 2), " s)"
appendInfoLine: "Shape: ", shape_name$
appendInfoLine: "Mode: ", mode_name$
appendInfoLine: "Drive: ", drive
appendInfoLine: "Mix: ", mix_percent, "%"
appendInfoLine: "Output level: ", output_level_name$
appendInfoLine: ""

# ============================================================
# PROCESSING
# ============================================================

appendInfoLine: "Processing..."

selectObject: original
Copy: "processing_temp"
proc_sound = selected("Sound")

# Convert drive to string for formulas
drive_str$ = string$(drive)

# ====== MODE-SPECIFIC PROCESSING ======

if mode = 1
    # === STANDARD MODE ===
    appendInfoLine: "  Mode: Standard"
    selectObject: proc_sound
    Formula: "self * " + drive_str$
    @applyWaveShaping: proc_sound, shape
    dc_offset_standard = last_dc_removed

elsif mode = 2
    # === FREQUENCY SPLIT MODE ===
    appendInfoLine: "  Mode: Frequency Split (800 Hz)"
    freq_split = 800
    
    # Extract low band
    selectObject: proc_sound
    Filter (pass Hann band): 20, freq_split, 100
    low_band = selected("Sound")
    
    # Extract high band
    selectObject: proc_sound
    Filter (pass Hann band): freq_split, sr/2, 100
    high_band = selected("Sound")
    
    # Process low band (normal drive)
    selectObject: low_band
    Formula: "self * " + drive_str$
    @applyWaveShaping: low_band, shape
    dc_offset_low = last_dc_removed
    
    # Process high band (1.5x drive for brightness)
    drive_high_str$ = string$(drive * 1.5)
    selectObject: high_band
    Formula: "self * " + drive_high_str$
    @applyWaveShaping: high_band, shape
    dc_offset_high = last_dc_removed
    
    # Recombine
    low_str$ = string$(low_band)
    high_str$ = string$(high_band)
    
    selectObject: proc_sound
    Formula: "object[" + low_str$ + "] + object[" + high_str$ + "]"
    
    removeObject: low_band, high_band

elsif mode = 3
    # === ASYMMETRIC MODE ===
    appendInfoLine: "  Mode: Asymmetric"
    selectObject: proc_sound
    Formula: "self * " + drive_str$
    @applyWaveShaping: proc_sound, shape
    dc_offset_asym = last_dc_removed
    # Different gain for positive/negative
    Formula: ~ if self > 0 then self * 1.3 else self * 0.8 fi

elsif mode = 4
    # === MULTI-STAGE MODE ===
    appendInfoLine: "  Mode: Multi-Stage (3 cascaded)"
    # Divide drive across 3 stages: total_drive = stage^3
    stage_drive = drive ^ (1/3)
    stage_drive_str$ = string$(stage_drive)
    
    selectObject: proc_sound
    for stage from 1 to 3
        appendInfoLine: "    Stage ", stage, "/3..."
        Formula: "self * " + stage_drive_str$
        @applyWaveShaping: proc_sound, shape
        dc_offset_stage[stage] = last_dc_removed
    endfor

elsif mode = 5
    # === STEREO WIDE MODE (M/S Processing) ===
    # The upfront guard already falls back to mode=1 for non-stereo
    # input, so is_stereo is guaranteed true here.
    appendInfoLine: "  Mode: Stereo Wide (M/S)"
    
    # Extract channels
    selectObject: proc_sound
    Extract one channel: 1
    left_ch = selected("Sound")
    
    selectObject: proc_sound
    Extract one channel: 2
    right_ch = selected("Sound")
    
    left_str$ = string$(left_ch)
    right_str$ = string$(right_ch)
    
    # Create Mid signal: (L + R) / 2
    selectObject: left_ch
    Copy: "mid_temp"
    mid_signal = selected("Sound")
    Formula: "(object[" + left_str$ + "] + object[" + right_str$ + "]) / 2"
    
    # Process Mid with normal drive
    Formula: "self * " + drive_str$
    @applyWaveShaping: mid_signal, shape
    dc_offset_mid = last_dc_removed
    
    # Create Side signal: (L - R) / 2
    selectObject: left_ch
    Copy: "side_temp"
    side_signal = selected("Sound")
    Formula: "(object[" + left_str$ + "] - object[" + right_str$ + "]) / 2"
    
    # Process Side with 1.5x drive (enhances width)
    drive_side_str$ = string$(drive * 1.5)
    Formula: "self * " + drive_side_str$
    @applyWaveShaping: side_signal, shape
    dc_offset_side = last_dc_removed
    
    mid_str$ = string$(mid_signal)
    side_str$ = string$(side_signal)
    
    # Reconstruct L = Mid + Side
    selectObject: left_ch
    Formula: "object[" + mid_str$ + "] + object[" + side_str$ + "]"
    
    # Reconstruct R = Mid - Side
    selectObject: right_ch
    Formula: "object[" + mid_str$ + "] - object[" + side_str$ + "]"
    
    # Combine back to stereo
    selectObject: left_ch, right_ch
    Combine to stereo
    new_stereo = selected("Sound")
    
    # Replace proc_sound
    removeObject: proc_sound, mid_signal, side_signal, left_ch, right_ch
    proc_sound = new_stereo
endif

# ====== MIX DRY/WET ======

if mix_percent < 100
    appendInfoLine: "Mixing dry/wet (", mix_percent, "% wet)..."
    
    wet_str$ = string$(mix_frac_g)
    dry_str$ = string$(dry_frac_g)
    orig_str$ = string$(original)
    
    selectObject: proc_sound
    Formula: "(self * " + wet_str$ + ") + (object[" + orig_str$ + "] * " + dry_str$ + ")"
endif

# ====== OUTPUT LEVEL (Preserve / Limiter / Normalize) ======

selectObject: proc_sound
final_peak = Get absolute extremum: 0, 0, "None"
appendInfoLine: "Output peak (pre output-stage): ", fixed$(final_peak, 4)

silent_threshold = 0.00001

if output_level = 1
    # Preserve: no gain change, just warn if it would clip on export
    if final_peak > 1
        appendInfoLine: "WARNING: output peak = ", fixed$(final_peak, 3), " exceeds 1.0 - may clip on playback/export."
    endif
elsif output_level = 2
    # Limiter: only pull the peak down, never boost a quiet signal
    if final_peak > 0.95
        selectObject: proc_sound
        Scale peak: 0.95
    endif
elsif output_level = 3
    # Normalize: scale to 0.95, but never do so on (near) silence,
    # since that would either fail or blow noise/DC up to full scale.
    if final_peak > silent_threshold
        selectObject: proc_sound
        Scale peak: 0.95
    else
        appendInfoLine: "NOTE: output is silent (peak ~0); skipping normalization."
    endif
endif

selectObject: proc_sound
final_peak_after = Get absolute extremum: 0, 0, "None"
appendInfoLine: "Output peak (after output-stage): ", fixed$(final_peak_after, 4)

# ====== FINAL NAMING ======

selectObject: proc_sound
Rename: original_name$ + "_" + shape_name$ + "_" + mode_name$
result = selected("Sound")

# ============================================================
# VISUALIZATION
# ============================================================

if draw_visualization
    Erase all
    
    # Title
    Select outer viewport: 0, 8, 0.1, 0.5
    Font size: 12
    Colour: "Black"
    Text: 0.5, "centre", 0.5, "half", "Wave Shaper: " + shape_name$ + " / " + mode_name$
    
    # Original waveform
    Select outer viewport: 0, 8, 0.6, 1.5
    Select inner viewport: 0.6, 7.6, 0.7, 1.4
    selectObject: original
    Colour: "{0.6, 0.6, 0.6}"
    Draw: 0, 0, 0, 0, "no", "Curve"
    Colour: "Black"
    Draw inner box
    Font size: 8
    Text left: "yes", "Original"
    
    # Result waveform
    Select outer viewport: 0, 8, 1.6, 2.5
    Select inner viewport: 0.6, 7.6, 1.7, 2.4
    selectObject: result
    Colour: "{0.6, 0.5, 0.7}"
    Draw: 0, 0, 0, 0, "no", "Curve"
    Colour: "Black"
    Draw inner box
    Text left: "yes", "Shaped"
    Text bottom: "yes", "Time (s)"
    
    # Zoomed comparison
    # Use the Sound's actual start/end time rather than assuming it
    # starts at 0 (an extracted Sound can retain an offset start time).
    selectObject: original
    zoomStart = Get start time
    zoomEndOrig = Get end time
    zoomEnd = zoomStart + min(0.02, zoomEndOrig - zoomStart)
    
    Select outer viewport: 0, 4, 2.7, 3.8
    Select inner viewport: 0.6, 3.8, 2.8, 3.7
    selectObject: original
    Colour: "{0.6, 0.6, 0.6}"
    Draw: zoomStart, zoomEnd, 0, 0, "no", "Curve"
    Colour: "Black"
    Draw inner box
    Font size: 6
    Text left: "yes", "Orig (zoom)"
    
    Select outer viewport: 4, 8, 2.7, 3.8
    Select inner viewport: 4.4, 7.6, 2.8, 3.7
    selectObject: result
    Colour: "{0.6, 0.5, 0.7}"
    Draw: zoomStart, zoomEnd, 0, 0, "no", "Curve"
    Colour: "Black"
    Draw inner box
    Font size: 6
    Text left: "yes", "Shaped (zoom)"
    Text bottom: "yes", "Time (s)"
    
    # Transfer function (mode-aware; see computeTransferPoint)
    Select outer viewport: 0, 4, 4.0, 5.5
    Select inner viewport: 0.6, 3.8, 4.1, 5.4
    
    nPoints = 300
    
    # --- Pre-pass: find the real Y range of what will be drawn, so
    # the axis fits the actual function instead of silently clamping
    # values that go far beyond +/-1 (e.g. Polynomial, Square Law,
    # Chebyshev at high drive). ---
    firstPoint = 1
    for p from 1 to nPoints
        xp = -1.2 + (p - 1) / (nPoints - 1) * 2.4
        @computeTransferPoint: xp
        if firstPoint = 1
            yMin = tv1
            yMax = tv1
            firstPoint = 0
        endif
        if tv1 < yMin
            yMin = tv1
        endif
        if tv1 > yMax
            yMax = tv1
        endif
        if dual_curve = 1
            if tv2 < yMin
                yMin = tv2
            endif
            if tv2 > yMax
                yMax = tv2
            endif
        endif
    endfor
    
    yRange = yMax - yMin
    if yRange < 0.2
        yRange = 0.2
    endif
    yPad = yRange * 0.15
    axisYmin = yMin - yPad
    axisYmax = yMax + yPad
    if axisYmin > -0.1
        axisYmin = -0.1
    endif
    if axisYmax < 0.1
        axisYmax = 0.1
    endif
    
    Axes: -1.5, 1.5, axisYmin, axisYmax
    Paint rectangle: "{0.95, 0.95, 0.95}", -1.5, 1.5, axisYmin, axisYmax
    
    # Grid
    Colour: "{0.85, 0.85, 0.85}"
    Draw line: -1.5, 0, 1.5, 0
    Draw line: 0, axisYmin, 0, axisYmax
    Dotted line
    Draw line: -1.2, -1.2, 1.2, 1.2
    Solid line
    
    # Draw transfer function(s) at full resolution, no clamping
    Line width: 2
    
    for p from 2 to nPoints
        x1 = -1.2 + (p - 2) / (nPoints - 1) * 2.4
        x2 = -1.2 + (p - 1) / (nPoints - 1) * 2.4
        
        @computeTransferPoint: x1
        y1a = tv1
        y1b = tv2
        @computeTransferPoint: x2
        y2a = tv1
        y2b = tv2
        
        Colour: "{0.6, 0.5, 0.7}"
        Draw line: x1, y1a, x2, y2a
        if dual_curve = 1
            Colour: "{0.4, 0.65, 0.55}"
            Draw line: x1, y1b, x2, y2b
        endif
    endfor
    Line width: 1
    
    Colour: "Black"
    Draw inner box
    Font size: 5
    Text left: "yes", "Output"
    Text bottom: "yes", "Input"
    
    if mode = 2
        Font size: 4
        Colour: "{0.6, 0.5, 0.7}"
        Text: -1.4, "left", axisYmax - (axisYmax - axisYmin) * 0.08, "half", "- Low band (drive)"
        Colour: "{0.4, 0.65, 0.55}"
        Text: -1.4, "left", axisYmax - (axisYmax - axisYmin) * 0.16, "half", "- High band (1.5x drive)"
        Colour: "Black"
        Font size: 5
        Text: 0, "centre", axisYmax + (axisYmax - axisYmin) * 0.05, "half", "Per-band curves, DC-corrected, mix incl.; band recombination & output-level stage not shown"
    elsif mode = 5
        Font size: 4
        Colour: "{0.6, 0.5, 0.7}"
        Text: -1.4, "left", axisYmax - (axisYmax - axisYmin) * 0.08, "half", "- Mid (drive)"
        Colour: "{0.4, 0.65, 0.55}"
        Text: -1.4, "left", axisYmax - (axisYmax - axisYmin) * 0.16, "half", "- Side (1.5x drive)"
        Colour: "Black"
        Font size: 5
        Text: 0, "centre", axisYmax + (axisYmax - axisYmin) * 0.05, "half", "Mid/Side curves, DC-corrected, mix incl.; L/R reconstruction & output-level stage not shown"
    else
        Text: 0, "centre", axisYmax + (axisYmax - axisYmin) * 0.05, "half", shape_name$ + " (drive=" + fixed$(drive, 1) + "), DC-corrected, mix incl.; output-level stage not shown"
    endif
    
    # Algorithm list
    Select outer viewport: 4, 8, 4.0, 5.5
    Select inner viewport: 4.4, 7.6, 4.1, 5.4
    
    Axes: 0, 4, 0, 12
    Paint rectangle: "{0.95, 0.95, 0.95}", 0, 4, 0, 12
    
    Font size: 5
    
    # List all algorithms, highlight current
    algorithms$[1] = "1. Tanh (soft)"
    algorithms$[2] = "2. Sine Fold"
    algorithms$[3] = "3. Arctan"
    algorithms$[4] = "4. Polynomial"
    algorithms$[5] = "5. Abs (rectify)"
    algorithms$[6] = "6. Square Law"
    algorithms$[7] = "7. Chebyshev"
    algorithms$[8] = "8. Sigmoid"
    algorithms$[9] = "9. Exp Saturation"
    algorithms$[10] = "10. Bitcrush"
    algorithms$[11] = "11. Wave Wrap (fold)"
    algorithms$[12] = "12. Diode"
    
    for i from 1 to 12
        yPos = 12 - i + 0.5
        if i = shape
            Colour: "{0.6, 0.5, 0.7}"
            Paint rectangle: "{0.85, 0.8, 0.9}", 0.1, 3.9, yPos - 0.4, yPos + 0.4
            Colour: "Black"
            Text: 0.2, "left", yPos, "half", "► " + algorithms$[i]
        else
            Colour: "{0.5, 0.5, 0.5}"
            Text: 0.2, "left", yPos, "half", algorithms$[i]
        endif
    endfor
    
    Colour: "Black"
    Draw inner box
    
    # Parameters
    Select outer viewport: 0, 8, 5.6, 6.0
    Font size: 7
    Colour: "{0.4, 0.4, 0.4}"
    Text: 0.5, "centre", 0.5, "half", "Drive: " + fixed$(drive, 1) + " | Mix: " + fixed$(mix_percent, 0) + "% | Mode: " + mode_name$ + " | Output: " + output_level_name$
    
    Font size: 10
    Colour: "Black"
endif

# === Final Info ===
selectObject: result

appendInfoLine: ""
appendInfoLine: "=== Done ==="
appendInfoLine: "Created: ", selected$("Sound")

# === Play ===
if play_result
    selectObject: result
    Play
endif

selectObject: result

# ============================================================
# PROCEDURES
# ============================================================

procedure applyWaveShaping: .sound, .shape
    selectObject: .sound
    
    if .shape = 1
        # Hyperbolic Tangent (soft clip)
        Formula: ~ tanh(self * 1.5) / 1.5
    elsif .shape = 2
        # Sine Fold (warm)
        Formula: ~ sin(self * 2.5) * 0.85
    elsif .shape = 3
        # Arc Tangent (smooth)
        Formula: ~ 2 * arctan(self * 1.8) / pi
    elsif .shape = 4
        # Polynomial (aggressive)
        Formula: ~ self - (self * self * self) * 0.33
    elsif .shape = 5
        # Absolute Value (rectifier)
        Formula: ~ abs(self)
    elsif .shape = 6
        # Square Law (fuzzy)
        Formula: ~ self * abs(self) * 0.8
    elsif .shape = 7
        # Chebyshev polynomials (harmonic control)
        # T1 + 0.2*T2 + 0.1*T3
        Formula: ~ self * 0.7 + (2 * self * self - 1) * 0.2 + (4 * self^3 - 3 * self) * 0.1
    elsif .shape = 8
        # Sigmoid (tube-like)
        Formula: ~ (2 / (1 + exp(-self * 2))) - 1
    elsif .shape = 9
        # Exponential Saturation (smooth, hyperbolic - monotonic, not
        # a fold: it approaches +/-1 asymptotically like tanh)
        Formula: ~ (exp(self) - exp(-self)) / (exp(self) + exp(-self) + 0.1)
    elsif .shape = 10
        # Bitcrush (lo-fi)
        Formula: ~ floor(self * 16 + 0.5) / 16
    elsif .shape = 11
        # Wave Wrap: true periodic triangle-wave fold. Matches self
        # for |self|<=1, then keeps reflecting back into [-1,1] with
        # period 4 instead of diverging again past |self|=3.
        Formula: ~ 1 - abs((self + 1) - 4 * floor((self + 1) / 4) - 2)
    elsif .shape = 12
        # Diode Ladder (analog asymmetric)
        Formula: ~ if self > 0 then (1 - exp(-self * 2)) * 0.5 else (exp(self * 2) - 1) * 0.3 fi
    endif
    
    # DC blocking: several curves (notably Chebyshev, whose T2 term
    # has a nonzero value at self=0) can turn silence, or any signal
    # with residual asymmetry, into a DC offset. Subtracting the mean
    # here means normalization downstream can never blow a DC offset
    # up to +/-0.95, and it is a no-op for already-zero-mean signals.
    # The removed amount is signal-dependent (it's the mean of the
    # WHOLE processed Sound, not a pointwise thing), so it's captured
    # here and reused by computeTransferPoint to keep the graph
    # consistent with what actually happened to the audio.
    last_dc_removed = Get mean: 0, 0, 0
    Subtract mean
endproc

procedure computeShape: .input, .shape
    # Compute waveshaping for visualization (returns result_value)
    
    if .shape = 1
        result_value = tanh(.input * 1.5) / 1.5
    elsif .shape = 2
        result_value = sin(.input * 2.5) * 0.85
    elsif .shape = 3
        result_value = 2 * arctan(.input * 1.8) / pi
    elsif .shape = 4
        result_value = .input - (.input * .input * .input) * 0.33
    elsif .shape = 5
        result_value = abs(.input)
    elsif .shape = 6
        result_value = .input * abs(.input) * 0.8
    elsif .shape = 7
        result_value = .input * 0.7 + (2 * .input * .input - 1) * 0.2 + (4 * .input^3 - 3 * .input) * 0.1
    elsif .shape = 8
        result_value = (2 / (1 + exp(-.input * 2))) - 1
    elsif .shape = 9
        result_value = (exp(.input) - exp(-.input)) / (exp(.input) + exp(-.input) + 0.1)
    elsif .shape = 10
        result_value = floor(.input * 16 + 0.5) / 16
    elsif .shape = 11
        result_value = 1 - abs((.input + 1) - 4 * floor((.input + 1) / 4) - 2)
    elsif .shape = 12
        if .input > 0
            result_value = (1 - exp(-.input * 2)) * 0.5
        else
            result_value = (exp(.input * 2) - 1) * 0.3
        endif
    endif
endproc

procedure computeTransferPoint: .x
    # Produces the point(s) actually shown in the transfer-function
    # graph. This now matches the real signal path as closely as a
    # pointwise function can:
    #   - the actual DC offset removed by "Subtract mean" during
    #     processing (dc_offset_*, measured from the real Sound, not
    #     recomputed from this x) is subtracted from each shaped value;
    #   - the global dry/wet mix is applied to every mode, including
    #     Frequency Split and Stereo Wide.
    # What still can't be shown pointwise: Frequency Split's band
    # recombination (low+high depend on neighbouring samples via the
    # filters, not just the local x) and Stereo Wide's L=Mid+Side,
    # R=Mid-Side reconstruction (needs both curves at once). Those two
    # modes therefore show each underlying curve individually, with
    # mix applied, rather than one broadband curve.
    # Sets tv1 (and tv2 for the dual-curve modes) plus dual_curve.
    if mode = 1
        # Standard: single wet-shaping curve, real DC offset, mix included
        @computeShape: .x * drive, shape
        f1 = result_value - dc_offset_standard
        tv1 = mix_frac_g * f1 + dry_frac_g * .x
        tv2 = tv1
        dual_curve = 0
    elsif mode = 2
        # Frequency Split: low and high bands, each with their own
        # measured DC offset and the global mix applied. Still not a
        # single broadband curve, since the actual signal sums two
        # filtered bands rather than transforming one sample at a time.
        @computeShape: .x * drive, shape
        f1 = result_value - dc_offset_low
        tv1 = mix_frac_g * f1 + dry_frac_g * .x
        @computeShape: .x * drive * 1.5, shape
        f2 = result_value - dc_offset_high
        tv2 = mix_frac_g * f2 + dry_frac_g * .x
        dual_curve = 1
    elsif mode = 3
        # Asymmetric: shaping curve (DC-corrected), then the +/-
        # post-gain (applied AFTER the mean removal, same as the
        # audio engine), then mix
        @computeShape: .x * drive, shape
        f1 = result_value - dc_offset_asym
        if f1 > 0
            f1 = f1 * 1.3
        else
            f1 = f1 * 0.8
        endif
        tv1 = mix_frac_g * f1 + dry_frac_g * .x
        tv2 = tv1
        dual_curve = 0
    elsif mode = 4
        # Multi-Stage: three cascaded passes at stage_drive, each
        # using its own measured per-stage DC offset, then mix
        v = .x
        for stg from 1 to 3
            @computeShape: v * stage_drive, shape
            v = result_value - dc_offset_stage[stg]
        endfor
        tv1 = mix_frac_g * v + dry_frac_g * .x
        tv2 = tv1
        dual_curve = 0
    elsif mode = 5
        # Stereo Wide: Mid and Side, each with their own measured DC
        # offset and the global mix applied. Still not a single-input
        # function: the actual L/R reconstruction (L=Mid+Side,
        # R=Mid-Side) depends on both curves together.
        @computeShape: .x * drive, shape
        f1 = result_value - dc_offset_mid
        tv1 = mix_frac_g * f1 + dry_frac_g * .x
        @computeShape: .x * drive * 1.5, shape
        f2 = result_value - dc_offset_side
        tv2 = mix_frac_g * f2 + dry_frac_g * .x
        dual_curve = 1
    endif
endproc

procedure getShapeName: .shape
    if .shape = 1
        shape_name$ = "Tanh"
    elsif .shape = 2
        shape_name$ = "SineFold"
    elsif .shape = 3
        shape_name$ = "Arctan"
    elsif .shape = 4
        shape_name$ = "Polynomial"
    elsif .shape = 5
        shape_name$ = "Abs"
    elsif .shape = 6
        shape_name$ = "SquareLaw"
    elsif .shape = 7
        shape_name$ = "Chebyshev"
    elsif .shape = 8
        shape_name$ = "Sigmoid"
    elsif .shape = 9
        shape_name$ = "ExpSaturation"
    elsif .shape = 10
        shape_name$ = "Bitcrush"
    elsif .shape = 11
        shape_name$ = "WaveWrap"
    elsif .shape = 12
        shape_name$ = "DiodeLadder"
    endif
endproc

procedure getModeName: .mode
    if .mode = 1
        mode_name$ = "Standard"
    elsif .mode = 2
        mode_name$ = "FreqSplit"
    elsif .mode = 3
        mode_name$ = "Asymmetric"
    elsif .mode = 4
        mode_name$ = "MultiStage"
    elsif .mode = 5
        mode_name$ = "StereoWide"
    endif
endproc

procedure getOutputLevelName: .level
    if .level = 1
        output_level_name$ = "Preserve"
    elsif .level = 2
        output_level_name$ = "Limiter"
    elsif .level = 3
        output_level_name$ = "Normalize"
    endif
endproc