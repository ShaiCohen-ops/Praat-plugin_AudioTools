# ============================================================
# Praat AudioTools - LatentRelocation.praat
# Author: Shai Cohen
# Affiliation: Department of Music, Bar-Ilan University, Israel
# Email: shai.cohen@biu.ac.il
# Version: 1.5 (2026) - Conservative robustness + truthful visualization
# License: MIT License
# Repository: https://github.com/ShaiCohen-ops/Praat-plugin_AudioTools
#
# Description:
#   Online Latent-Event Relocation
#   (Deep Thermodynamic Recomposition)
#
#   Trains a lightweight autoencoder on-the-fly from the input audio,
#   learns a latent space, then relocates events based on latent
#   thermodynamic fields (temperature, affinity, regimes).
#   No external models, no internet, pure numpy ML.
#
#   Parameters:
#   - Learning steps:  autoencoder training iterations (20–500)
#   - Latent size:     bottleneck dimensionality (2–32)
#   - Relocation intensity: how much reordering (0=original .. 1=max)
#   - Stability bias:  anchoring strength - higher = less movement
#   - Novelty bias:    how tightly novel events snap to structural slots
#   - Preserve duration: maintain original length
#   - Seed:            deterministic reproducibility
#
# Changelog v1.4:
#   - Rewrote the event-relocation engine so the three knobs behave the
#     way their names imply (the previous mapping was counter-intuitive):
#       * relocation_intensity is now a smooth master dial - it morphs
#         each event's rank from its original position toward its
#         relocated position, so 0 = original order and movement grows
#         gradually (no more "nothing happens then everything jumps"
#         cliff around 0.4-0.5).
#       * stability_bias now MONOTONICALLY reduces movement (anchors all
#         events toward their original position; stable events resist
#         more). It no longer secretly re-weighted the temperature field,
#         which had made "more stable" produce MORE scatter.
#       * novelty_bias now has a real, monotonic effect: it locks the
#         most novel events onto evenly-spaced structural positions,
#         gated by intensity. It was previously near-inert.
#     Output ordering is still always a valid permutation (no events
#     dropped or duplicated). Verified by parameter sweeps on the engine.
#
# Changelog v1.3:
#   - Replaced the runSystem_nocheck Python calls (probe + main engine)
#     with "nocheck runSubprocess", which passes each argument directly
#     without a shell. This avoids Windows mangling the long multi-quoted
#     command string, and surfaces Python's stderr into the Info window.
#   - Synced the version string across header, form title, and banner
#     (form/banner had lagged at v1.1).
#   - Python: guarded the single-event (n=1) case in the latent fields
#     (k-NN temperature no longer produces a NaN); corrected a stale
#     docstring (decoder output is linear, not sigmoid).
#
# Citation:
#   Cohen, S. (2026). Praat AudioTools: An Offline Analysis-Resynthesis
#   Toolkit for Experimental Composition.
#   https://github.com/ShaiCohen-ops/Praat-plugin_AudioTools
#
# ============================================================

# ---- INPUT CHECK ----
if numberOfSelected("Sound") <> 1
    exitScript: "Please select exactly one Sound object."
endif

sound = selected("Sound")
soundName$ = selected$("Sound")

# Praat 7+: file writes/deletes and subprocess execution require full trust.
if praatVersion >= 7000
    askForTrust()
endif

# ---- OS-Specific Python Discovery ----
if macintosh
    if fileReadable("/opt/homebrew/bin/python3")
        pythonCmd$ = "/opt/homebrew/bin/python3"
    elsif fileReadable("/Library/Frameworks/Python.framework/Versions/3.14/bin/python3")
        pythonCmd$ = "/Library/Frameworks/Python.framework/Versions/3.14/bin/python3"
    elsif fileReadable("/usr/local/bin/python3")
        pythonCmd$ = "/usr/local/bin/python3"
    else
        pythonCmd$ = "python3"
    endif
elsif windows
    pythonCmd$ = "python"
else
    pythonCmd$ = "python3"
endif

# ---- PATHS ----
pluginDir$    = preferencesDirectory$ + "/plugin_AudioTools/"
pythonScript$ = pluginDir$ + "py/latent_relocation.py"

if not fileReadable(pythonScript$)
    pythonScript$ = defaultDirectory$ + "/latent_relocation.py"
endif
if not fileReadable(pythonScript$)
    exitScript: "Cannot find Python script: latent_relocation.py" + newline$ + "Expected at: " + pluginDir$ + "py/ or next to this script."
endif

tempInput$   = temporaryDirectory$ + "/temp_latrel_input.wav"
tempCSV$     = temporaryDirectory$ + "/temp_latrel_events.csv"
tempOutput$  = temporaryDirectory$ + "/temp_latrel_output.wav"
tempStats$   = temporaryDirectory$ + "/temp_latrel_stats.txt"
probeMarker$ = temporaryDirectory$ + "/temp_latrel_probe.ok"

# Replace backslashes for the Python inline probe
probeMarkerJ$ = replace_regex$(probeMarker$, "\\", "/", 0)

# ---- CLEANUP PROCEDURE ----
procedure cleanUpTempFiles
    if fileReadable(tempInput$)
        deleteFile: tempInput$
    endif
    if fileReadable(tempCSV$)
        deleteFile: tempCSV$
    endif
    if fileReadable(tempOutput$)
        deleteFile: tempOutput$
    endif
    if fileReadable(tempStats$)
        deleteFile: tempStats$
    endif
    if fileReadable(probeMarker$)
        deleteFile: probeMarker$
    endif
endproc

@cleanUpTempFiles

# ---- FORM ----
form Online Latent-Event Relocation v1.5
    comment === Preset ===
    optionmenu Preset: 1
        option Custom
        option Gentle lattice
        option Balanced flow
        option Volatile scatter
        option Deep recomposition
        option Novelty pivots
    comment === Autoencoder ===
    integer Learning_steps 100
    integer Latent_size 8
    comment === Relocation Controls ===
    real Relocation_intensity 0.5
    real Stability_bias 0.3
    real Novelty_bias 0.3
    comment === Output ===
    boolean Preserve_duration 1
    integer Seed 42
    boolean Draw_visualization 1
    boolean Play_result 1
endform

# ---- PRESETS ----
if preset = 2
    # Gentle lattice - mild but AUDIBLE reordering. relocation_intensity
    # must clear the engine's reorder-by-sort threshold, and stability_bias
    # must stay low enough not to anchor events back to their original
    # order (high stability + low intensity = no audible change).
    learning_steps = 90
    latent_size = 6
    relocation_intensity = 0.45
    stability_bias = 0.25
    novelty_bias = 0.2
    presetName$ = "GentleLattice"
elsif preset = 3
    # Balanced flow - clearly audible mid-strength reshuffling
    learning_steps = 110
    latent_size = 8
    relocation_intensity = 0.6
    stability_bias = 0.2
    novelty_bias = 0.35
    presetName$ = "BalancedFlow"
elsif preset = 4
    learning_steps = 150
    latent_size = 12
    relocation_intensity = 0.8
    stability_bias = 0.1
    novelty_bias = 0.5
    presetName$ = "VolatileScatter"
elsif preset = 5
    learning_steps = 200
    latent_size = 16
    relocation_intensity = 0.7
    stability_bias = 0.2
    novelty_bias = 0.4
    presetName$ = "DeepRecomp"
elsif preset = 6
    learning_steps = 150
    latent_size = 10
    relocation_intensity = 0.6
    stability_bias = 0.1
    novelty_bias = 0.8
    presetName$ = "NoveltyPivots"
else
    presetName$ = "Custom"
endif

# Clamp
if learning_steps < 10
    learning_steps = 10
endif
if learning_steps > 500
    learning_steps = 500
endif
if latent_size < 2
    latent_size = 2
endif
if latent_size > 32
    latent_size = 32
endif

# ---- INFO ----
clearinfo
writeInfoLine:  "=== Online Latent-Event Relocation v1.5 ==="
appendInfoLine: "Input: ", soundName$
appendInfoLine: "Preset: ", presetName$
appendInfoLine: ""
appendInfoLine: "Learning steps: ", learning_steps
appendInfoLine: "Latent size:    ", latent_size
appendInfoLine: "Reloc intensity:", fixed$(relocation_intensity, 2)
appendInfoLine: "Stability bias: ", fixed$(stability_bias, 2)
appendInfoLine: "Novelty bias:   ", fixed$(novelty_bias, 2)
appendInfoLine: "Preserve dur:   ", preserve_duration
appendInfoLine: "Seed:           ", seed
appendInfoLine: ""

# ---- CAPTURE ORIGINAL STATS ----
selectObject: sound
dur = Get total duration
soundXmin = Get start time
sr  = Get sampling frequency
nChannels = Get number of channels
rms_orig = Get root-mean-square: 0, 0

appendInfoLine: "Duration: ", fixed$(dur, 2), " s | SR: ", sr, " Hz | Channels: ", nChannels
appendInfoLine: ""

# ===========================================================================
# Stage 1 — Detect Python Dependencies
# ===========================================================================
appendInfoLine: "[1/5] Detecting Python dependencies..."

probeSrc$ = "import numpy, scipy, soundfile; open('" + probeMarkerJ$ + "', 'w').write('ok')"
nocheck runSubprocess: pythonCmd$, "-c", probeSrc$

if not fileReadable(probeMarker$)
    @cleanUpTempFiles
    exitScript: "Python not found or dependencies missing." + newline$ + "Please install: pip install numpy scipy soundfile"
endif

deleteFile: probeMarker$
appendInfoLine: "  Python found: ", pythonCmd$

# ===========================================================================
# Stage 2 — Event Segmentation (Praat-side)
# ===========================================================================
appendInfoLine: "[2/5] Segmenting events..."

minEventDur = 0.200
maxEventDur = 3.000

selectObject: sound
if nChannels > 1
    Extract one channel: 1
    analysisMono = selected("Sound")
else
    Copy: "analysisMono"
    analysisMono = selected("Sound")
endif

# Saved WAV files start at sample time 0. Keep analysis/event times in the
# same coordinate system even when the selected Sound has a non-zero xmin.
selectObject: analysisMono
Shift times to: "start time", 0

selectObject: analysisMono
pitchObj = To Pitch: 0.01, 75, 600

selectObject: analysisMono
harmObj = To Harmonicity (cc): 0.01, 75, 0.1, 1.0

selectObject: analysisMono
intObj = To Intensity: 100, 0.01, "yes"

selectObject: intObj
intMatrix = Down to Matrix
intSound = To Sound (slice): 1
selectObject: intSound
ppObj = To PointProcess (extrema): 1, "yes", "no", "Sinc70"

selectObject: ppObj
nPeaks = Get number of points

nBounds = nPeaks + 2
bound_1 = 0
bound_2 = dur
iBound = 3
for iPeak from 1 to nPeaks
    selectObject: ppObj
    peakT = Get time from index: iPeak
    bound_'iBound' = peakT
    iBound = iBound + 1
endfor
nBounds = iBound - 1

for i from 1 to nBounds
    for j from i + 1 to nBounds
        if bound_'j' < bound_'i'
            tmpVal = bound_'i'
            bound_'i' = bound_'j'
            bound_'j' = tmpVal
        endif
    endfor
endfor

nFinal = 0
prevT = -1
for i from 1 to nBounds
    thisT = bound_'i'
    if thisT - prevT >= minEventDur
        nFinal = nFinal + 1
        final_'nFinal' = thisT
        prevT = thisT
    endif
endfor

if nFinal > 0
    lastFinal = final_'nFinal'
    if dur - lastFinal > 0.050
        nFinal = nFinal + 1
        final_'nFinal' = dur
    else
        final_'nFinal' = dur
    endif
else
    nFinal = 2
    final_1 = 0
    final_2 = dur
endif

nEvents = 0
for i from 1 to nFinal - 1
    evStart = final_'i'
    iNext = i + 1
    evEnd = final_'iNext'
    evDur = evEnd - evStart

    if evDur > maxEventDur
        nChunks = ceiling(evDur / maxEventDur)
        chunkDur = evDur / nChunks
        for iChunk from 0 to nChunks - 1
            nEvents = nEvents + 1
            evS_'nEvents' = evStart + iChunk * chunkDur
            if iChunk = nChunks - 1
                evE_'nEvents' = evEnd
            else
                evE_'nEvents' = evStart + (iChunk + 1) * chunkDur
            endif
        endfor
    elsif evDur >= minEventDur
        nEvents = nEvents + 1
        evS_'nEvents' = evStart
        evE_'nEvents' = evEnd
    endif
endfor

if nEvents < 2
    nEvents = 1
    evS_1 = 0
    evE_1 = dur
endif

appendInfoLine: "  Found ", nEvents, " events"

# ===========================================================================
# Stage 3 — Extract Per-Event Features
# ===========================================================================
appendInfoLine: "[3/5] Extracting per-event features..."

Create Table with column names: "eventFeatures", nEvents, "start_time end_time pitch_median pitch_stability intensity_mean attack_slope hnr_mean"
eventTable = selected("Table")

for iEv from 1 to nEvents
    t1 = evS_'iEv'
    t2 = evE_'iEv'
    tMid = (t1 + t2) / 2

    selectObject: eventTable
    Set numeric value: iEv, "start_time", t1
    Set numeric value: iEv, "end_time", t2

    selectObject: pitchObj
    pMed = Get quantile: t1, t2, 0.5, "Hertz"
    pMean = Get mean: t1, t2, "Hertz"
    pStd = Get standard deviation: t1, t2, "Hertz"

    if pMed = undefined
        pMed = 0
    endif
    if pMean = undefined or pMean = 0
        pitchStab = 0
    else
        if pStd = undefined
            pStd = 0
        endif
        pitchCV = pStd / (pMean + 0.001)
        pitchStab = 1 - min(1, pitchCV)
        if pitchStab < 0
            pitchStab = 0
        endif
    endif

    selectObject: eventTable
    Set numeric value: iEv, "pitch_median", pMed
    Set numeric value: iEv, "pitch_stability", pitchStab

    selectObject: intObj
    iMean = Get mean: t1, t2, "energy"
    if iMean = undefined
        iMean = 0
    endif
    iStart = Get value at time: t1, "Cubic"
    if iStart = undefined
        iStart = 0
    endif
    iPeak = Get maximum: t1, t2, "Parabolic"
    if iPeak = undefined
        iPeak = iStart
    endif
    tPeak = Get time of maximum: t1, t2, "Parabolic"
    if tPeak = undefined
        tPeak = tMid
    endif

    attackTime = tPeak - t1
    if attackTime > 0.001
        attackSlope = (iPeak - iStart) / attackTime
    else
        attackSlope = 0
    endif

    selectObject: eventTable
    Set numeric value: iEv, "intensity_mean", iMean
    Set numeric value: iEv, "attack_slope", attackSlope

    selectObject: harmObj
    hMean = Get mean: t1, t2
    if hMean = undefined
        hMean = 0
    endif

    selectObject: eventTable
    Set numeric value: iEv, "hnr_mean", hMean
endfor

appendInfoLine: "  Exporting temp files..."
selectObject: sound
Save as WAV file: tempInput$
selectObject: eventTable
Save as comma-separated file: tempCSV$

removeObject: analysisMono, pitchObj, harmObj, intObj
removeObject: intMatrix, intSound, ppObj, eventTable

# ===========================================================================
# Stage 4 — Call Python Engine
# ===========================================================================
appendInfoLine: "[4/5] Running Python engine..."
appendInfoLine: "  (Training autoencoder + relocating events)"

# Remove any stale output/stats from a PREVIOUS run before calling Python.
# The temp filenames are fixed, so without this a crashed run would leave
# the old files in place and the fileReadable() check below would pass on
# stale data - silently importing a previous result as if it were new.
if fileReadable(tempOutput$)
    deleteFile: tempOutput$
endif
if fileReadable(tempStats$)
    deleteFile: tempStats$
endif

# runSubprocess runs Python DIRECTLY (no shell), so it cannot mangle the
# quoted temp paths the way a single long runSystem command can on Windows,
# and it surfaces Python's own stderr into the Info window. The nocheck
# prefix lets the fileReadable() check below handle a failure gracefully
# instead of halting the script.
nocheck runSubprocess: pythonCmd$, pythonScript$,
    ... tempInput$, tempCSV$, tempOutput$, tempStats$,
    ... string$(learning_steps), string$(latent_size),
    ... fixed$(relocation_intensity, 4), fixed$(stability_bias, 4),
    ... fixed$(novelty_bias, 4), string$(preserve_duration), string$(seed)

if not fileReadable(tempOutput$)
    @cleanUpTempFiles
    exitScript: "Python latent relocation engine failed." + newline$ + "Check the Info window above for the Python error."
endif

# ===========================================================================
# Stage 5 — Import Result
# ===========================================================================
appendInfoLine: "[5/5] Importing result..."

Read from file: tempOutput$
Rename: soundName$ + "_latent"
resultSound = selected("Sound")

selectObject: resultSound
rms_out = Get root-mean-square: 0, 0
durOut = Get total duration

# ===========================================================================
# Read Stats
# ===========================================================================
nEvStat$ = "?"
nMovedStat$ = "?"
avgDispStat$ = "?"
maxDispStat$ = "?"
crystalPct$ = "?"
fluidPct$ = "?"
gasPct$ = "?"
plasmaPct$ = "?"
finalLoss$ = "?"
initialLoss$ = "?"
meanTempStat$ = "?"
meanEvDur$ = "?"
warningStat$ = ""

nDispPts = 0

if fileReadable(tempStats$)
    statsText$ = readFile$(tempStats$)

    @parseStatLine: statsText$, "n_events="
    nEvStat$ = parseStatLine.result$
    @parseStatLine: statsText$, "n_moved="
    nMovedStat$ = parseStatLine.result$
    @parseStatLine: statsText$, "avg_displacement_ms="
    avgDispStat$ = parseStatLine.result$
    @parseStatLine: statsText$, "max_displacement_ms="
    maxDispStat$ = parseStatLine.result$
    @parseStatLine: statsText$, "crystal_pct="
    crystalPct$ = parseStatLine.result$
    @parseStatLine: statsText$, "fluid_pct="
    fluidPct$ = parseStatLine.result$
    @parseStatLine: statsText$, "gas_pct="
    gasPct$ = parseStatLine.result$
    @parseStatLine: statsText$, "plasma_pct="
    plasmaPct$ = parseStatLine.result$
    @parseStatLine: statsText$, "final_loss="
    finalLoss$ = parseStatLine.result$
    @parseStatLine: statsText$, "initial_loss="
    initialLoss$ = parseStatLine.result$
    @parseStatLine: statsText$, "mean_temperature="
    meanTempStat$ = parseStatLine.result$
    @parseStatLine: statsText$, "mean_event_dur="
    meanEvDur$ = parseStatLine.result$
    @parseStatLine: statsText$, "warning="
    warningStat$ = parseStatLine.result$

    # ── Parse displacement map data ──
    @parseStatLine: statsText$, "n_disp_pts="
    nDP$ = parseStatLine.result$
    if nDP$ <> "?"
        nDispPts = number(nDP$)
    endif
    if nDispPts > 100
        nDispPts = 100
    endif
    for iDP from 0 to nDispPts - 1
        @parseStatLine: statsText$, "dp_" + string$(iDP) + "="
        dpRaw$ = parseStatLine.result$
        dp_'iDP'_x = 0
        dp_'iDP'_y = 0
        dp_'iDP'_dest = iDP
        dp_'iDP'_temp = 0
        dp_'iDP'_reg = 0
        if dpRaw$ <> "?"
            remaining$ = dpRaw$
            comma = index(remaining$, ",")
            if comma > 0
                dp_'iDP'_x = number(left$(remaining$, comma - 1))
                remaining$ = mid$(remaining$, comma + 1, length(remaining$) - comma)
            endif
            comma = index(remaining$, ",")
            if comma > 0
                dp_'iDP'_y = number(left$(remaining$, comma - 1))
                remaining$ = mid$(remaining$, comma + 1, length(remaining$) - comma)
            endif
            comma = index(remaining$, ",")
            if comma > 0
                dp_'iDP'_dest = number(left$(remaining$, comma - 1))
                remaining$ = mid$(remaining$, comma + 1, length(remaining$) - comma)
            endif
            comma = index(remaining$, ",")
            if comma > 0
                dp_'iDP'_temp = number(left$(remaining$, comma - 1))
                remaining$ = mid$(remaining$, comma + 1, length(remaining$) - comma)
                dp_'iDP'_reg = number(remaining$)
            endif
        endif
    endfor
endif

###############################################################################
# VISUALIZATION
###############################################################################

if draw_visualization
    appendInfoLine: "Drawing visualization..."

    Erase all
    Select outer viewport: 0, 8, 0, 8

    # === Title ===
    Select outer viewport: 0, 8, 0, 0.5
    Axes: 0, 1, 0, 1
    Font size: 12
    Colour: "Black"
    Text: 0.5, "centre", 0.6, "half", "##Latent-Event Relocation##"
    Font size: 9
    Colour: "{0.4, 0.4, 0.5}"
    Text: 0.5, "centre", -0.7, "half", soundName$ + " | " + presetName$ + " | Latent=" + string$(latent_size) + " | Seed=" + string$(seed)

    # === Input Waveform ===
    Select outer viewport: 0, 8, 0.6, 1.5
    Select inner viewport: 0.6, 7.7, 0.65, 1.45
    selectObject: sound
    Colour: "{0.5, 0.5, 0.5}"
    Draw: 0, 0, 0, 0, "no", "Curve"
    Colour: "Black"
    Draw inner box
    Font size: 7
    Text left: "yes", "Original"

    Colour: "{0.48, 0.56, 0.68}"
    Line width: 1
    Axes: soundXmin, soundXmin + dur, -1, 1
    for iEv from 1 to nEvents
        evBound = soundXmin + evS_'iEv'
        if evBound > soundXmin and evBound < soundXmin + dur
            Draw line: evBound, -0.9, evBound, 0.9
        endif
    endfor
    Text top: "no", string$(nEvents) + " events | " + fixed$(dur, 2) + " s"

    # === Output Waveform ===
    Select outer viewport: 0, 8, 1.5, 2.4
    Select inner viewport: 0.6, 7.7, 1.55, 2.35
    selectObject: resultSound
    Colour: "{0.20, 0.40, 0.75}"
    Draw: 0, 0, 0, 0, "no", "Curve"
    Colour: "Black"
    Draw inner box
    Font size: 7
    Text left: "yes", "Relocated"
    Text bottom: "yes", "Time (s)"

    # === Original Spectrogram ===
    Select outer viewport: 0, 8, 2.5, 3.7
    Select inner viewport: 0.6, 7.7, 2.6, 3.6

    selectObject: sound
    if nChannels > 1
        Extract one channel: 1
        tmpOrig = selected("Sound")
    else
        Copy: "tmpOrig"
        tmpOrig = selected("Sound")
    endif

    To Spectrogram: 0.03, 5000, 0.002, 20, "Gaussian"
    specOrig = selected("Spectrogram")
    Paint: 0, 0, 0, 5000, 100, "yes", 50, 6, 0, "no"
    Colour: "Black"
    Draw inner box
    Font size: 6
    Text left: "yes", "Hz"
    Text top: "no", "Original spectrogram"
    removeObject: specOrig, tmpOrig

    # === Output Spectrogram ===
    Select outer viewport: 0, 8, 3.7, 4.9
    Select inner viewport: 0.6, 7.7, 3.8, 4.8

    selectObject: resultSound
    if nChannels > 1
        Extract one channel: 1
        tmpOut = selected("Sound")
    else
        Copy: "tmpOut"
        tmpOut = selected("Sound")
    endif

    To Spectrogram: 0.03, 5000, 0.002, 20, "Gaussian"
    specOut = selected("Spectrogram")
    Paint: 0, 0, 0, 5000, 100, "yes", 50, 6, 0, "no"
    Colour: "Black"
    Draw inner box
    Font size: 6
    Text left: "yes", "Hz"
    Text bottom: "yes", "Time (s)"
    Text top: "no", "Relocated spectrogram"
    removeObject: specOut, tmpOut

    # === Regime Distribution Bar ===
    Select outer viewport: 0, 8, 5.0, 5.6
    Select inner viewport: 0.6, 7.7, 5.1, 5.5

    Axes: 0, 1, 0, 1
    Paint rectangle: "{0.96, 0.96, 0.96}", 0, 1, 0, 1

    crystalW = 0
    fluidW = 0
    gasW = 0
    plasmaW = 0
    if crystalPct$ <> "?"
        crystalW = number(crystalPct$) / 100
    endif
    if fluidPct$ <> "?"
        fluidW = number(fluidPct$) / 100
    endif
    if gasPct$ <> "?"
        gasW = number(gasPct$) / 100
    endif
    if plasmaPct$ <> "?"
        plasmaW = number(plasmaPct$) / 100
    endif

    x0 = 0.05
    barH_top = 0.75
    barH_bot = 0.25

    if crystalW > 0.001
        Paint rectangle: "{0.20, 0.40, 0.75}", x0, x0 + crystalW * 0.9, barH_bot, barH_top
        x0 = x0 + crystalW * 0.9
    endif
    if fluidW > 0.001
        Paint rectangle: "{0.25, 0.60, 0.62}", x0, x0 + fluidW * 0.9, barH_bot, barH_top
        x0 = x0 + fluidW * 0.9
    endif
    if gasW > 0.001
        Paint rectangle: "{0.52, 0.58, 0.68}", x0, x0 + gasW * 0.9, barH_bot, barH_top
        x0 = x0 + gasW * 0.9
    endif
    if plasmaW > 0.001
        Paint rectangle: "{0.55, 0.38, 0.68}", x0, x0 + plasmaW * 0.9, barH_bot, barH_top
    endif

    Font size: 6
    Colour: "Black"
    Text: 0.02, "left", 0.92, "half", "Regimes: blue=Crystal | teal=Fluid | slate=Gas | violet=Plasma"
    Font size: 5
    Colour: "{0.34, 0.38, 0.48}"
    Text: 0.98, "right", 0.92, "half", "log-mel -> AE -> Z + temperature/regime -> rank relocation -> timeline"

    Colour: "Black"
    Draw rectangle: 0, 1, 0, 1

    # === Latent Field + Timeline Relocation ===
    Select outer viewport: 0, 8, 5.7, 7.0

    if nDispPts > 0
        # Left: measured latent event field. Events do NOT move in Z; colour
        # shows the regime that drives the timeline relocation law.
        Select inner viewport: 0.6, 4.0, 5.8, 6.9
        axMinX = dp_0_x
        axMaxX = dp_0_x
        axMinY = dp_0_y
        axMaxY = dp_0_y
        for iDP from 0 to nDispPts - 1
            bx = dp_'iDP'_x
            by = dp_'iDP'_y
            if bx < axMinX
                axMinX = bx
            endif
            if bx > axMaxX
                axMaxX = bx
            endif
            if by < axMinY
                axMinY = by
            endif
            if by > axMaxY
                axMaxY = by
            endif
        endfor
        rangeX = axMaxX - axMinX
        rangeY = axMaxY - axMinY
        if rangeX < 0.01
            rangeX = 1
        endif
        if rangeY < 0.01
            rangeY = 1
        endif
        axMinX = axMinX - rangeX * 0.12
        axMaxX = axMaxX + rangeX * 0.12
        axMinY = axMinY - rangeY * 0.12
        axMaxY = axMaxY + rangeY * 0.12
        Axes: axMinX, axMaxX, axMinY, axMaxY
        Paint rectangle: "{0.97, 0.975, 0.985}", axMinX, axMaxX, axMinY, axMaxY
        markerHalfX = (axMaxX - axMinX) * 0.012
        markerHalfY = (axMaxY - axMinY) * 0.018
        for iDP from 0 to nDispPts - 1
            reg = dp_'iDP'_reg
            if reg = 0
                regCol$ = "{0.20, 0.40, 0.75}"
            elsif reg = 1
                regCol$ = "{0.25, 0.60, 0.62}"
            elsif reg = 2
                regCol$ = "{0.52, 0.58, 0.68}"
            else
                regCol$ = "{0.55, 0.38, 0.68}"
            endif
            Paint rectangle: regCol$, dp_'iDP'_x - markerHalfX, dp_'iDP'_x + markerHalfX, dp_'iDP'_y - markerHalfY, dp_'iDP'_y + markerHalfY
        endfor
        Colour: "Black"
        Draw inner box
        Font size: 6
        Text left: "yes", "PC2"
        Text bottom: "yes", "PC1"
        Text top: "no", "Latent field (events fixed in Z; colour = regime)"

        # Right: the actual operation -- original rank -> output rank.
        Select inner viewport: 4.35, 7.7, 5.8, 6.9
        rankMax = max(1, nDispPts - 1)
        Axes: 0, 1, -0.5, rankMax + 0.5
        Paint rectangle: "{0.97, 0.975, 0.985}", 0, 1, -0.5, rankMax + 0.5
        Line width: 1
        for iDP from 0 to nDispPts - 1
            reg = dp_'iDP'_reg
            if reg = 0
                Colour: "{0.20, 0.40, 0.75}"
            elsif reg = 1
                Colour: "{0.25, 0.60, 0.62}"
            elsif reg = 2
                Colour: "{0.52, 0.58, 0.68}"
            else
                Colour: "{0.55, 0.38, 0.68}"
            endif
            Draw line: 0.08, iDP, 0.92, dp_'iDP'_dest
        endfor
        Colour: "Black"
        Draw inner box
        Font size: 6
        Text bottom: "no", "Original rank                         Output rank"
        Text top: "no", "Timeline relocation (actual permutation)"
    else
        Select inner viewport: 0.6, 7.7, 5.8, 6.9
        Axes: 0, 1, 0, 1
        Paint rectangle: "{0.97, 0.975, 0.985}", 0, 1, 0, 1
        Font size: 7
        Colour: "{0.5, 0.5, 0.5}"
        Text: 0.5, "centre", 0.5, "half", "(relocation data not available)"
        Colour: "Black"
        Draw rectangle: 0, 1, 0, 1
    endif

    # === Summary Panel ===
    Select outer viewport: 0, 8, 7.1, 8.0
    Select inner viewport: 0.6, 7.7, 7.15, 7.95

    Axes: 0, 1, 0, 1
    Paint rectangle: "{0.95, 0.95, 0.95}", 0, 1, 0, 1

    Font size: 7
    Colour: "Black"
    Text: 0.02, "left", 0.90, "half", "Summary:"
    Font size: 6
    Colour: "{0.3, 0.3, 0.3}"
    Text: 0.02, "left", 0.70, "half", "Events=" + nEvStat$ + " Moved=" + nMovedStat$ + " AvgDisp=" + avgDispStat$ + "ms MaxDisp=" + maxDispStat$ + "ms | AE: " + initialLoss$ + "->" + finalLoss$
    Text: 0.02, "left", 0.46, "half", "Regimes: C=" + crystalPct$ + "\% F=" + fluidPct$ + "\% G=" + gasPct$ + "\% P=" + plasmaPct$ + "\% | T=" + meanTempStat$ + " | RMS: " + fixed$(rms_orig, 4) + "->" + fixed$(rms_out, 4)
    Colour: "{0.4, 0.4, 0.5}"
    Text: 0.02, "left", 0.22, "half", "Steps=" + string$(learning_steps) + " Lat=" + string$(latent_size) + " Int=" + fixed$(relocation_intensity, 2) + " Stab=" + fixed$(stability_bias, 2) + " Nov=" + fixed$(novelty_bias, 2) + " Seed=" + string$(seed)

    if warningStat$ <> "?" and warningStat$ <> ""
        Colour: "{0.8, 0.2, 0.2}"
        Text: 0.60, "left", 0.22, "half", "Warn: " + warningStat$
    endif

    Colour: "Black"
    Draw rectangle: 0, 1, 0, 1

    Font size: 10
    Colour: "Black"
endif

# ===========================================================================
# Cleanup
# ===========================================================================
@cleanUpTempFiles

# ===========================================================================
# Summary
# ===========================================================================

appendInfoLine: ""
appendInfoLine: "=== COMPLETE ==="
appendInfoLine: "Output: ", soundName$, "_latent"
appendInfoLine: "Preset: ", presetName$
appendInfoLine: ""
appendInfoLine: "Relocation report:"
appendInfoLine: "  Events: ", nEvStat$, " (mean dur: ", meanEvDur$, " s)"
appendInfoLine: "  Moved: ", nMovedStat$, " | Avg displacement: ", avgDispStat$, " ms"
appendInfoLine: "  Max displacement: ", maxDispStat$, " ms"
appendInfoLine: ""
appendInfoLine: "Latent regimes:"
appendInfoLine: "  Crystal: ", crystalPct$, "% | Fluid: ", fluidPct$, "% | Gas: ", gasPct$, "% | Plasma: ", plasmaPct$, "%"
appendInfoLine: "  Mean temperature: ", meanTempStat$
appendInfoLine: ""
appendInfoLine: "Autoencoder:"
appendInfoLine: "  Loss: ", initialLoss$, " -> ", finalLoss$
appendInfoLine: "  Steps: ", learning_steps, " | Latent: ", latent_size
appendInfoLine: ""
appendInfoLine: "RMS original:    ", fixed$(rms_orig, 6)
appendInfoLine: "RMS relocated:   ", fixed$(rms_out, 6)
if rms_orig > 0
    appendInfoLine: "RMS ratio:       ", fixed$(rms_out / rms_orig, 3), "x"
else
    appendInfoLine: "RMS ratio:       n/a (silent input)"
endif

if warningStat$ <> "?" and warningStat$ <> ""
    appendInfoLine: ""
    appendInfoLine: "WARNING: ", warningStat$
endif

selectObject: resultSound

if play_result
    Play
endif

# ===========================================================================
# Procedures
# ===========================================================================
procedure parseStatLine: .text$, .key$
    .result$ = "?"
    .pos = index(.text$, .key$)
    if .pos > 0
        .start = .pos + length(.key$)
        .rest$ = mid$(.text$, .start, length(.text$) - .start + 1)
        .nlPos = index(.rest$, newline$)
        if .nlPos > 0
            .result$ = left$(.rest$, .nlPos - 1)
        else
            .result$ = .rest$
        endif
    endif
endproc