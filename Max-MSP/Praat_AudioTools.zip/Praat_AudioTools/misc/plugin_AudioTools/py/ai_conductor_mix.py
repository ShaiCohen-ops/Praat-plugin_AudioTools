#!/usr/bin/env python3
# ============================================================
# Praat AudioTools - ai_conductor_mix.py
# Author: Shai Cohen
# Affiliation: Department of Music, Bar-Ilan University, Israel
# Email: shai.cohen@biu.ac.il
# Version: 3.2 (2026) - descriptor-integrated, robust continuous rendering
# License: MIT License
# Repository: https://github.com/ShaiCohen-ops/Praat-plugin_AudioTools
#
# Description:
#   Algorithmic Conductor – descriptor-driven ensemble mixer.
#   Receives: manifest (WAV paths), macro descriptors (from Praat).
#   Produces:
#     1. A stereo WAV rendered at sample level (smooth, click-free)
#     2. A tab-delimited mix plan CSV for Praat-side visualisation
#
#   Roles: leader, shadow, resonance, noise_fringe, pulse_carrier,
#          interruption, sustain_bed, contrast_voice, memory_trace,
#          silence
#   States: sparse, balanced, agitated, saturated, suspended, released
#
# Dependencies:
#   pip install numpy soundfile
#   Optional: pip install librosa  (better onset detection)
#
# ============================================================

import argparse
import csv
import math
import os
import sys
import traceback
from collections import Counter

import numpy as np
import soundfile as sf

# ── Optional librosa for onset detection ──────────────────────────────────────
try:
    import librosa
    HAS_LIBROSA = True
except ImportError:
    HAS_LIBROSA = False

# Optional SciPy: preferred high-quality resampling.
try:
    from scipy import signal as scipy_signal
    HAS_SCIPY = True
except ImportError:
    scipy_signal = None
    HAS_SCIPY = False

# ─────────────────────────────────────────────────────────────────────────────
# CONSTANTS / LABELS
# ─────────────────────────────────────────────────────────────────────────────

ROLES = [
    "leader", "shadow", "resonance", "noise_fringe",
    "pulse_carrier", "interruption", "sustain_bed",
    "contrast_voice", "memory_trace", "silence"
]

STATES = ["sparse", "balanced", "agitated", "saturated", "suspended", "released"]

N_ROLES  = len(ROLES)
N_STATES = len(STATES)

DESC_DIM = 10


# ─────────────────────────────────────────────────────────────────────────────
# AUDIO ANALYSIS
# ─────────────────────────────────────────────────────────────────────────────

def _analysis_mono(audio_2d):
    """Mono analysis signal with anti-phase cancellation protection.

    A straight channel mean is normally appropriate, but a stereo pair can be
    nearly anti-phase. In that case the mean can approach silence and corrupt
    every descriptor, so use the strongest individual channel instead.
    """
    audio_2d = np.asarray(audio_2d, dtype=np.float64)
    if audio_2d.shape[1] == 1:
        return audio_2d[:, 0].astype(np.float32), "mono"
    mean = audio_2d.mean(axis=1)
    ch_rms = np.sqrt(np.mean(audio_2d ** 2, axis=0) + 1e-20)
    mean_rms = float(np.sqrt(np.mean(mean ** 2) + 1e-20))
    strongest = int(np.argmax(ch_rms))
    if ch_rms[strongest] > 1e-9 and mean_rms < 0.20 * float(ch_rms[strongest]):
        return audio_2d[:, strongest].astype(np.float32), f"channel_{strongest+1}_anti_phase_safe"
    return mean.astype(np.float32), "mean"


def load_audio_mono(path: str) -> tuple:
    audio, sr = sf.read(path, always_2d=True)
    mono, mix_mode = _analysis_mono(audio)
    return mono, sr, mix_mode


def _resample_channel(x, sr, target_sr):
    if sr == target_sr or len(x) == 0:
        return np.asarray(x, dtype=np.float64)
    if HAS_SCIPY:
        g = math.gcd(int(sr), int(target_sr))
        return scipy_signal.resample_poly(x, target_sr // g, sr // g).astype(np.float64)
    if HAS_LIBROSA:
        return librosa.resample(np.asarray(x, dtype=np.float64),
                                orig_sr=sr, target_sr=target_sr).astype(np.float64)
    # Last-resort dependency-free interpolation.
    new_len = max(1, int(round(len(x) * target_sr / sr)))
    old_pos = np.arange(len(x), dtype=np.float64)
    new_pos = np.linspace(0.0, max(len(x) - 1, 0), new_len)
    return np.interp(new_pos, old_pos, x).astype(np.float64)


def load_audio_stereo(path: str, target_sr: int) -> tuple:
    """Load all source channels and fold to stereo at target_sr.

    Mono is duplicated; stereo is preserved; >2 channels are folded by
    alternating channels so no channel is silently discarded.
    """
    audio, sr = sf.read(path, always_2d=True)
    audio = audio.astype(np.float64)
    n_ch = audio.shape[1]
    if n_ch == 1:
        left = right = audio[:, 0]
    elif n_ch == 2:
        left, right = audio[:, 0], audio[:, 1]
    else:
        left_group = audio[:, 0::2]
        right_group = audio[:, 1::2]
        left = left_group.mean(axis=1)
        right = right_group.mean(axis=1) if right_group.shape[1] else left.copy()
    return _resample_channel(left, sr, target_sr), _resample_channel(right, sr, target_sr)


def segment_fixed(audio, sr, frame_ms, hop_ms):
    frame_n = max(2, int(round(sr * frame_ms / 1000)))
    hop_n   = max(1, int(round(sr * hop_ms  / 1000)))
    n = len(audio)
    if n < 2:
        return []
    segs, t, idx = [], 0, 0
    while t < n:
        end = min(t + frame_n, n)
        if end - t >= 2:
            segs.append({"start_samp": t, "end_samp": end,
                         "start_sec": t / sr, "dur_sec": (end-t) / sr, "idx": idx})
            idx += 1
        if end >= n:
            break
        t += hop_n
    return segs


def segment_onset(audio, sr, min_gap_ms):
    n = len(audio)
    if n < 2:
        return []
    if HAS_LIBROSA and n >= 2048:
        onsets = librosa.onset.onset_detect(
            y=audio, sr=sr, units="samples", backtrack=True, delta=0.1)
    else:
        hop = max(8, min(int(sr * 0.01), max(8, n // 4)))
        n_frames = n // hop
        if n_frames < 2:
            onsets = np.array([], dtype=int)
        else:
            usable = n_frames * hop
            frames = audio[:usable].reshape(n_frames, hop)
            energy = np.sum(frames ** 2, axis=1)
            diff   = np.diff(energy, prepend=energy[0])
            thresh = diff.mean() + diff.std() * 1.5
            onsets = (np.where(diff > thresh)[0] * hop).astype(int)

    min_gap_samp = max(1, int(sr * min_gap_ms / 1000))
    # Always cover the beginning of the source: onset detectors need not return 0.
    filtered, last = [0], 0
    for o in np.asarray(onsets, dtype=int):
        o = int(np.clip(o, 0, n - 1))
        if o > 0 and o - last >= min_gap_samp:
            filtered.append(o); last = o

    segs = []
    for i, seg_start in enumerate(filtered):
        seg_end = filtered[i + 1] if i + 1 < len(filtered) else n
        if seg_end - seg_start >= 2:
            segs.append({"start_samp": seg_start, "end_samp": seg_end,
                         "start_sec": seg_start / sr,
                         "dur_sec": (seg_end-seg_start) / sr, "idx": i})
    return segs

def segment_hybrid(audio, sr, frame_ms, hop_ms, min_gap_ms):
    onset_segs = segment_onset(audio, sr, min_gap_ms)
    fixed_segs = segment_fixed(audio, sr, frame_ms, hop_ms)
    hybrid, idx = [], 0
    for os_seg in onset_segs:
        if os_seg["dur_sec"] > frame_ms / 1000 * 3:
            sub = segment_fixed(
                audio[os_seg["start_samp"]:os_seg["end_samp"]], sr,
                frame_ms, hop_ms)
            for s in sub:
                s["start_samp"] += os_seg["start_samp"]
                s["end_samp"]   += os_seg["start_samp"]
                s["start_sec"]   = s["start_samp"] / sr
                s["idx"] = idx; hybrid.append(s); idx += 1
        else:
            os_seg["idx"] = idx; hybrid.append(os_seg); idx += 1
    return hybrid if hybrid else fixed_segs


def extract_descriptors(audio, sr, segs):
    """Extract comparable segment descriptors on a fixed spectral grid.

    Onset segments can differ greatly in duration. Using each segment's native
    FFT size makes spectral flux and cepstral measures incomparable, and very
    long segments can allocate huge autocorrelation FFTs. We therefore average
    a few 4096-sample views on one fixed grid and cap the pitch-analysis view.
    """
    descs = np.zeros((len(segs), DESC_DIM), dtype=np.float32)
    eps = 1e-12; prev_mag = None
    spec_n = 4096
    freqs = np.fft.rfftfreq(spec_n, d=1.0 / sr)

    for i, seg in enumerate(segs):
        chunk = np.asarray(audio[seg["start_samp"]:seg["end_samp"]], dtype=np.float64)
        if len(chunk) < 2:
            continue
        n = len(chunk)

        view_n = min(spec_n, n)
        n_views = min(8, max(1, int(math.ceil(n / max(view_n, 1)))))
        starts = np.linspace(0, max(0, n-view_n), n_views).astype(int)
        specs = []
        for st in starts:
            view = chunk[st:st+view_n]
            win = view * np.hanning(len(view))
            specs.append(np.abs(np.fft.rfft(win, n=spec_n)))
        spec = np.mean(specs, axis=0)

        rms = float(np.sqrt(np.mean(chunk ** 2)))
        zcr = float(np.mean(np.abs(np.diff(np.signbit(chunk))).astype(float)))
        spec_sum = spec.sum() + eps
        centroid = float(np.sum(freqs * spec) / spec_sum)
        bandwidth = float(np.sqrt(np.sum(((freqs - centroid)**2) * spec) / spec_sum))

        norm_spec = spec / spec_sum
        if prev_mag is None:
            flux = 0.0
        else:
            flux = float(np.sum(np.maximum(norm_spec - prev_mag, 0.0)))
        prev_mag = norm_spec.copy()

        roughness = float(spec[freqs > 3000].sum() / spec_sum)

        pitch_cap = min(n, max(256, int(sr * 2.0)))
        if n > pitch_cap:
            # Use the highest-RMS of a few candidate windows rather than the attack only.
            cand_starts = np.linspace(0, n-pitch_cap, min(7, max(2, n//pitch_cap+1))).astype(int)
            st = max(cand_starts, key=lambda q: float(np.mean(chunk[q:q+pitch_cap]**2)))
            pitch_view = chunk[st:st+pitch_cap]
        else:
            pitch_view = chunk
        pn = len(pitch_view)
        n_fft = 1 << max(1, (2 * pn - 1).bit_length())
        X = np.fft.rfft(pitch_view, n=n_fft)
        acorr = np.fft.irfft(X * np.conj(X))[:pn]
        lo_lag, hi_lag = max(1, sr // 500), min(pn - 1, sr // 50)
        pitch_salience = float(acorr[lo_lag:hi_lag].max() / acorr[0]) \
            if hi_lag > lo_lag and acorr[0] > eps else 0.0

        log_spec = np.log(spec + eps)
        ceps = np.abs(np.fft.irfft(log_spec, n=spec_n))
        q_lo, q_hi = max(1, int(sr / 500)), min(len(ceps) - 1, int(sr / 50))
        hnr_proxy = float(ceps[q_lo:q_hi].max() / (np.abs(ceps).mean() + eps)) \
            if q_hi > q_lo and len(ceps) > 10 else 0.0

        attack_n = max(2, min(n-1, n // 5))
        tail = chunk[attack_n:] if attack_n < n else chunk[-1:]
        attack_slope = float(
            np.sqrt(np.mean(chunk[:attack_n]**2) + eps) /
            (np.sqrt(np.mean(tail**2) + eps) + eps) - 1.0)

        blk = 32
        if n >= blk * 2:
            n_blks = n // blk
            frame_e = np.mean(chunk[:n_blks*blk].reshape(n_blks, blk)**2, axis=1)
            stab = 1.0 - min(1.0, float(frame_e.std() / (frame_e.mean() + eps))) \
                if frame_e.mean() > eps else 1.0
        else:
            stab = 1.0

        descs[i] = [rms, zcr, centroid, bandwidth, flux, roughness,
                    pitch_salience, hnr_proxy, attack_slope, stab]
    return descs



def read_macro_descriptors(path):
    """Read the Praat-side per-file descriptors. Returns index->dict."""
    out = {}
    if not path or not os.path.isfile(path):
        return out
    try:
        with open(path, "r", encoding="utf-8") as f:
            r = csv.DictReader(f, delimiter="\t")
            for row in r:
                try:
                    idx = int(row.get("file_index", 0))
                except (TypeError, ValueError):
                    continue
                vals = {}
                for k in ("rms", "mean_pitch_hz", "pitch_range", "mean_intensity_db",
                          "intensity_range_db", "spectral_centroid_est", "harmonicity_hnr"):
                    try:
                        vals[k] = float(row.get(k, "nan"))
                    except (TypeError, ValueError):
                        vals[k] = float("nan")
                out[idx] = vals
    except OSError:
        return {}
    return out


def _normalise_macro(macro_descs, key, default=0.5):
    vals = np.array([d.get(key, np.nan) if d else np.nan for d in macro_descs], dtype=float)
    valid = np.isfinite(vals)
    out = np.full(len(vals), default, dtype=float)
    if valid.any():
        lo, hi = float(np.min(vals[valid])), float(np.max(vals[valid]))
        if hi - lo > 1e-9:
            out[valid] = (vals[valid] - lo) / (hi - lo)
        else:
            out[valid] = 0.5
    return out

# ─────────────────────────────────────────────────────────────────────────────
# CONDUCTOR LOGIC
# ─────────────────────────────────────────────────────────────────────────────

def conduct(file_audios, file_srs, file_names, seg_mode, frame_ms, hop_ms,
            onset_gap_ms, style, memory_weight, tension_sens,
            allow_silence, nonlinear, macro_descs=None):
    n_files = len(file_audios)
    memory_weight = float(np.clip(memory_weight, 0.0, 1.0))
    tension_sens = float(np.clip(tension_sens, 0.0, 2.0))

    # ── 1. Segmentation ──────────────────────────────────────────────────────
    print("  Segmenting ensemble...", flush=True)
    all_segs, all_descs = [], []
    for fi, (audio, sr) in enumerate(zip(file_audios, file_srs)):
        if seg_mode == "fixed":
            segs = segment_fixed(audio, sr, frame_ms, hop_ms)
        elif seg_mode == "onset":
            segs = segment_onset(audio, sr, onset_gap_ms)
        else:
            segs = segment_hybrid(audio, sr, frame_ms, hop_ms, onset_gap_ms)
        descs = extract_descriptors(audio, sr, segs)
        all_segs.extend([(fi, s) for s in segs])
        all_descs.append(descs)
        print(f"    File {fi+1} ({file_names[fi]}): {len(segs)} segments", flush=True)

    n_total = len(all_segs)
    if n_total == 0:
        raise RuntimeError("No analysable segments were produced from the ensemble.")
    flat_descs = np.vstack(all_descs)
    max_dur = max(a.shape[0] / sr for a, sr in zip(file_audios, file_srs))

    # ── 2. Normalise ─────────────────────────────────────────────────────────
    col_min = flat_descs.min(axis=0)
    col_range = flat_descs.max(axis=0) - col_min + 1e-12
    flat_norm = (flat_descs - col_min) / col_range

    rms, flux, centroid = flat_norm[:, 0], flat_norm[:, 4], flat_norm[:, 2]
    rough, pitch_s, hnr = flat_norm[:, 5], flat_norm[:, 6], flat_norm[:, 7]
    attack_arr, stab = flat_norm[:, 8], flat_norm[:, 9]

    # Praat-side macro descriptors are deliberately a light prior (15-20%):
    # local segment behaviour remains dominant, but the expensive Pitch/HNR/
    # Spectrum analysis performed by Praat now genuinely informs the conductor.
    macro_descs = macro_descs or [None] * n_files
    if len(macro_descs) < n_files:
        macro_descs = list(macro_descs) + [None] * (n_files-len(macro_descs))
    seg_file_ids = np.array([fi for fi, _ in all_segs], dtype=int)
    m_rms = _normalise_macro(macro_descs, "rms")
    m_int = _normalise_macro(macro_descs, "mean_intensity_db")
    m_cent = _normalise_macro(macro_descs, "spectral_centroid_est")
    m_hnr = _normalise_macro(macro_descs, "harmonicity_hnr")
    m_prange = _normalise_macro(macro_descs, "pitch_range")
    m_irange = _normalise_macro(macro_descs, "intensity_range_db")
    m_pitch_present = np.array([1.0 if d and np.isfinite(d.get("mean_pitch_hz", np.nan))
                                and d.get("mean_pitch_hz", 0.0) > 0 else 0.0
                                for d in macro_descs])

    macro_energy = 0.55*m_rms + 0.45*m_int
    energy_local = np.clip(rms * 0.6 + flux * 0.4, 0, 1)
    energy = np.clip(0.85*energy_local + 0.15*macro_energy[seg_file_ids], 0, 1)
    pitch_s = np.clip(0.85*pitch_s + 0.15*m_pitch_present[seg_file_ids], 0, 1)
    hnr = np.clip(0.82*hnr + 0.18*m_hnr[seg_file_ids], 0, 1)
    noisiness = np.clip((rough + (1 - pitch_s) + (1 - hnr)) / 3, 0, 1)
    bright = np.clip(0.85*centroid + 0.15*m_cent[seg_file_ids], 0, 1)
    macro_var = 0.5*m_prange + 0.5*m_irange
    sharpness = np.clip(0.90*np.clip(attack_arr, 0, 1) + 0.10*macro_var[seg_file_ids], 0, 1)
    stabil = stab

    print(f"    energy: {energy.min():.3f}–{energy.max():.3f} "
          f"| bright: {bright.min():.3f}–{bright.max():.3f} "
          f"| noise: {noisiness.min():.3f}–{noisiness.max():.3f}", flush=True)

    # ── 3. Tension curve ─────────────────────────────────────────────────────
    n_tc = 100; t_ax = np.linspace(0, 1, n_tc)
    if style == "dramatic":
        tension_curve = (0.6 * np.sin(t_ax * np.pi) ** 1.5
                         + 0.25 * np.sin(t_ax * 3 * np.pi)
                         + 0.15 * np.clip(np.sin((t_ax - 0.8) * 5 * np.pi), 0, 1))
    elif style == "minimal":
        tension_curve = 0.2 + 0.3 * np.sin(t_ax * np.pi)
    elif style == "dense":
        tension_curve = 0.7 + 0.25 * np.sin(t_ax * 4 * np.pi)
    else:
        tension_curve = 0.4 + 0.2 * np.sin(t_ax * np.pi)
    tension_curve = np.clip(tension_curve, 0, 1)

    def get_tension(t_norm):
        return float(tension_curve[int(np.clip(t_norm * (n_tc-1), 0, n_tc-1))])

    # ── 4. Role scoring ──────────────────────────────────────────────────────
    print("  Assigning roles...", flush=True)
    def rank_norm(arr):
        """Tie-aware percentile rank. Equal descriptors must remain equal.

        The old argsort-based ranking assigned 0..1 by segment order even when
        every value was identical, inventing musical distinctions from ties.
        """
        x = np.asarray(arr, dtype=float)
        n = len(x)
        if n == 0:
            return np.zeros(0, dtype=float)
        if n == 1:
            return np.full(1, 0.5, dtype=float)
        vals, inv, counts = np.unique(x, return_inverse=True, return_counts=True)
        if len(vals) == 1:
            return np.full(n, 0.5, dtype=float)
        starts = np.cumsum(np.r_[0, counts[:-1]])
        avg_rank = starts + (counts - 1) / 2.0
        return avg_rank[inv] / (n - 1)

    rn = {k: rank_norm(v) for k, v in [
        ("energy", energy), ("bright", bright), ("noise", noisiness),
        ("stab", stabil), ("attack", sharpness), ("hnr", hnr),
        ("flux", flux), ("pitch", pitch_s)]}

    STYLE_W = {
        "neutral":  [1.0, 0.8, 0.9, 0.7, 0.9, 0.7, 0.9, 0.9, 0.8, 0.4],
        "dramatic": [1.4, 0.8, 0.9, 0.6, 0.9, 0.9, 0.8, 1.0, 0.7, 0.3],
        "minimal":  [0.8, 0.7, 1.1, 0.5, 0.6, 0.4, 1.2, 0.8, 1.1, 0.8],
        "dense":    [1.0, 0.8, 1.1, 1.0, 1.2, 0.9, 1.0, 1.1, 0.6, 0.1],
    }
    sw = np.array(STYLE_W.get(style, STYLE_W["neutral"]))

    scores = np.column_stack([
        rn["energy"]*0.7 + rn["bright"]*0.3,
        (1-rn["energy"])*0.4 + rn["stab"]*0.6,
        rn["hnr"]*0.5 + rn["stab"]*0.3 + (1-rn["noise"])*0.2,
        rn["noise"]*0.6 + (1-rn["pitch"])*0.4,
        rn["attack"]*0.5 + rn["energy"]*0.3 + rn["stab"]*0.2,
        rn["energy"]*0.5 + rn["flux"]*0.3 + rn["attack"]*0.2,
        rn["stab"]*0.5 + (1-rn["energy"])*0.3 + (1-rn["flux"])*0.2,
        rn["bright"]*0.5 + rn["pitch"]*0.3 + (1-rn["noise"])*0.2,
        (1-rn["energy"])*0.5 + rn["stab"]*0.3 + (1-rn["flux"])*0.2,
        (1-rn["energy"])*0.8 + (1-rn["flux"])*0.2,
    ]) * sw

    if not allow_silence:
        scores[:, ROLES.index("silence")] = -1.0

    role_ids  = scores.argmax(axis=1).astype(int)
    state_ids = np.zeros(n_total, dtype=int)
    prom_vals = np.zeros(n_total, dtype=float)
    tension_vals = np.zeros(n_total, dtype=float)

    # ── 5. Temporal post-pass ────────────────────────────────────────────────
    sorted_gi = sorted(range(n_total), key=lambda i: all_segs[i][1]["start_sec"])
    last_leader_end, last_file_leader = -999.0, -1
    memory_energy = float(np.mean(energy))
    e_med = float(np.median(energy))

    for gi in sorted_gi:
        fi, seg = all_segs[gi]
        t_norm  = seg["start_sec"] / (max_dur + 1e-9)
        base_tension = get_tension(t_norm)
        e, s    = float(energy[gi]), float(stabil[gi])
        seg_start, seg_end = seg["start_sec"], seg["start_sec"] + seg["dur_sec"]

        # React to contrast against PAST energy, then update memory afterwards.
        # v3.0 updated memory first and never used tension_sens at all.
        past_energy = memory_energy
        contrast = abs(e - past_energy)
        sens = float(np.clip(tension_sens, 0.0, 2.0))
        tension = float(np.clip(base_tension + 0.55 * sens * contrast, 0.0, 1.0))
        prom = float(np.clip(rn["energy"][gi] * (0.4 + 0.6*tension) + rn["stab"][gi]*0.2, 0, 1))
        prom_vals[gi] = prom
        tension_vals[gi] = tension

        if tension > 0.75:
            st = STATES.index("agitated") if e > e_med else STATES.index("saturated")
        elif tension > 0.5:
            st = STATES.index("balanced") if s > 0.5 else STATES.index("saturated")
        elif tension > 0.25:
            st = STATES.index("sparse") if e < e_med else STATES.index("balanced")
        else:
            st = STATES.index("suspended") if s > 0.5 else STATES.index("released")
        state_ids[gi] = st

        if ROLES[role_ids[gi]] == "leader":
            gap_needed = 2.0 / (tension + 0.2)
            if seg_start < last_leader_end + gap_needed or fi == last_file_leader:
                row = scores[gi].copy(); row[ROLES.index("leader")] = -1.0
                role_ids[gi] = int(row.argmax())
            else:
                last_leader_end, last_file_leader = seg_end, fi

        if (nonlinear and float(rn["energy"][gi]) > 0.90
                and past_energy < float(np.percentile(energy, 20))
                and tension > 0.6
                and ROLES[role_ids[gi]] not in ["leader", "interruption"]):
            role_ids[gi] = ROLES.index("interruption")

        memory_energy = past_energy * (1 - memory_weight) + e * memory_weight

    # ── 6a. Foreground guarantee ─────────────────────────────────────────────
    FOREGROUND = {"leader", "contrast_voice", "interruption", "pulse_carrier"}
    for fi in range(n_files):
        file_gis = [gi for gi in sorted_gi if all_segs[gi][0] == fi]
        if file_gis and not any(ROLES[role_ids[gi]] in FOREGROUND for gi in file_gis):
            best = max(file_gis, key=lambda g: float(energy[g]))
            role_ids[best] = ROLES.index("leader")
            prom_vals[best] = max(prom_vals[best], 0.65)

    # ── 6b. Masking awareness ────────────────────────────────────────────────
    seg_intervals = [(all_segs[gi][1]["start_sec"],
                      all_segs[gi][1]["start_sec"] + all_segs[gi][1]["dur_sec"], gi)
                     for gi in sorted_gi]
    for idx_a, (st_a, en_a, gi_a) in enumerate(seg_intervals):
        if ROLES[role_ids[gi_a]] in ["silence", "leader", "interruption"]:
            continue
        fi_a = all_segs[gi_a][0]
        for idx_b in range(idx_a + 1, len(seg_intervals)):
            st_b, en_b, gi_b = seg_intervals[idx_b]
            if st_b >= en_a: break
            if all_segs[gi_b][0] == fi_a: continue
            if min(en_a, en_b) - max(st_a, st_b) > 0.05:
                cd = abs(centroid[gi_a] - centroid[gi_b])
                mr = float(np.exp(-cd*4) * (rms[gi_a] + rms[gi_b]))
                if mr > 0.55 and prom_vals[gi_a] < prom_vals[gi_b]:
                    if ROLES[role_ids[gi_a]] not in ["sustain_bed", "shadow", "memory_trace"]:
                        role_ids[gi_a] = ROLES.index("shadow")
                        prom_vals[gi_a] *= 0.65

    # ── 6c. Role diversity cap ───────────────────────────────────────────────
    max_per_role = max(2, int(n_total * 0.35))
    rc = np.bincount(role_ids, minlength=N_ROLES)
    for rid in range(N_ROLES):
        if ROLES[rid] == "silence": continue
        while rc[rid] > max_per_role:
            cands = [gi for gi in sorted_gi if role_ids[gi] == rid]
            if not cands: break
            w = min(cands, key=lambda g: prom_vals[g])
            row = scores[w].copy(); row[rid] = -1.0
            if not allow_silence: row[ROLES.index("silence")] = -1.0
            nr = int(row.argmax()); role_ids[w] = nr; rc[rid] -= 1; rc[nr] += 1

    print(f"    Roles: {dict(Counter(ROLES[r] for r in role_ids))}", flush=True)

    # ── 7. Gain / Pan / Polyphony ────────────────────────────────────────────
    ROLE_GAIN = {"leader": 0.90, "shadow": 0.45, "resonance": 0.60,
                 "noise_fringe": 0.35, "pulse_carrier": 0.70,
                 "interruption": 0.88, "sustain_bed": 0.40,
                 "contrast_voice": 0.75, "memory_trace": 0.30, "silence": 0.0}
    base_pans = ({fi: -1.0 + 2.0*fi/(n_files-1) for fi in range(n_files)}
                 if n_files > 1 else {0: 0.0})
    ROLE_PAN = {"leader": 0.3, "shadow": 1.0, "resonance": 0.8,
                "noise_fringe": 1.2, "pulse_carrier": 0.6,
                "interruption": 0.1, "sustain_bed": 0.9,
                "contrast_voice": 1.1, "memory_trace": 0.7, "silence": 0.0}

    active_gi = [gi for gi in sorted_gi if ROLES[role_ids[gi]] != "silence"]
    intervals = [(all_segs[gi][1]["start_sec"],
                  all_segs[gi][1]["start_sec"]+all_segs[gi][1]["dur_sec"], gi)
                 for gi in active_gi]
    poly_count = {}
    for ia, (sa, ea, ga) in enumerate(intervals):
        mid_a = (sa + ea) * 0.5
        count = sum(1 for (sb, eb, _) in intervals if sb <= mid_a < eb)
        poly_count[ga] = max(1, count)
    max_poly = max(poly_count.values()) if poly_count else 1
    print(f"    Peak polyphony: {max_poly}", flush=True)

    # ── 8. Build plan ────────────────────────────────────────────────────────
    print("  Assembling mix plan...", flush=True)
    plan_rows = []
    for gi in sorted_gi:
        fi, seg = all_segs[gi]
        rl = ROLES[role_ids[gi]]
        if rl == "silence": continue

        gain = ROLE_GAIN[rl] * (0.5 + 0.5 * float(prom_vals[gi]))
        nv = poly_count.get(gi, 1)
        if nv > 2:
            ps = 2.0 / nv
            if rl in ("leader", "interruption"): ps = min(1.0, ps * 1.5)
            gain *= ps
        gain = round(float(np.clip(gain, 0.05, 1.0)), 4)

        pv = round(float(base_pans[fi] * ROLE_PAN.get(rl, 1.0)), 4)
        pv = max(-1.0, min(1.0, pv))

        fade = max(0.003, min(0.008, seg["dur_sec"] * 0.10))

        plan_rows.append({
            "time": round(seg["start_sec"], 4),
            "file_index": fi + 1, "file_index0": fi,
            "file_name": file_names[fi], "seg_index": seg["idx"],
            "src_start": round(seg["start_sec"], 4),
            "src_dur": round(seg["dur_sec"], 4),
            # Exact sample positions for click-free rendering
            "src_start_samp": seg["start_samp"],
            "src_end_samp":   seg["end_samp"],
            "src_sr":         file_srs[fi],
            "gain": gain, "role": rl,
            "layer_group": 0 if rl in ["leader","interruption","contrast_voice"]
                           else 1 if rl in ["pulse_carrier","resonance","shadow"]
                           else 2,
            "entry_time": round(seg["start_sec"], 4),
            "exit_time": round(seg["start_sec"]+seg["dur_sec"], 4),
            "transform": round(float(1.0-prom_vals[gi])*0.4, 3),
            "state": STATES[state_ids[gi]],
            "density": round(gain/0.9, 3),
            "priority": round(float(prom_vals[gi]), 4),
            "pan": pv, "fade": round(fade, 6),
            "tension": round(float(tension_vals[gi]), 4),
            "polyphony": int(nv),
        })

    plan_rows.sort(key=lambda r: (r["entry_time"], -r["priority"]))
    print(f"  Plan: {len(plan_rows)} events", flush=True)
    return plan_rows, max_dur


# ─────────────────────────────────────────────────────────────────────────────
# SAMPLE-LEVEL RENDERER — continuous gain envelope (no segment chopping)
# ─────────────────────────────────────────────────────────────────────────────

def render_mix(plan_rows, file_paths, target_sr, max_dur, result_path):
    """
    Renders the conductor plan into a stereo WAV.

    Instead of extracting and reassembling individual segments (which
    creates boundary artifacts), this renderer:
      1. Loads each source file as a continuous stereo stream.
      2. Builds a smooth per-sample gain envelope from the role/gain plan.
      3. Builds a smooth per-sample pan envelope.
      4. Multiplies the uncut audio by the envelopes.
      5. Accumulates into stereo output buffers.

    Zero segment boundaries = zero clicks.
    """
    print("  Rendering stereo mix (continuous envelope)...", flush=True)

    SMOOTH_MS = 150.0   # envelope smoothing window in ms
    smooth_n  = max(1, int(round(SMOOTH_MS / 1000.0 * target_sr)))

    # --- FAST FFT CONVOLUTION HELPER ---
    # Kernel spectra are cached because gain, pan numerator and pan support use
    # the same smoothing window for a given source length.
    smooth_kernel_cache = {}

    def fast_smooth(arr, kernel):
        n = len(arr)
        k = len(kernel)
        if n == 0 or k == 0:
            return arr
        n_fft = 1 << (n + k - 1).bit_length()
        key = (n_fft, k)
        ker_f = smooth_kernel_cache.get(key)
        if ker_f is None:
            ker_f = np.fft.rfft(kernel, n=n_fft)
            smooth_kernel_cache[key] = ker_f
        arr_f = np.fft.rfft(arr, n=n_fft)
        res = np.fft.irfft(arr_f * ker_f, n=n_fft)
        shift = (k - 1) // 2
        return res[shift : shift + n][:n]
    # -----------------------------------

    n_out = int(math.ceil(max_dur * target_sr)) + target_sr
    buf_L = np.zeros(n_out, dtype=np.float64)
    buf_R = np.zeros(n_out, dtype=np.float64)

    # ── Group plan rows by file ──────────────────────────────────────────
    file_rows = {}
    for row in plan_rows:
        fi = row["file_index0"]
        file_rows.setdefault(fi, []).append(row)

    # ── Process each file as a continuous stream ─────────────────────────
    all_fis = sorted(set(row["file_index0"] for row in plan_rows))

    for fi in all_fis:
        # Load full file as stereo at target_sr
        src_L, src_R = load_audio_stereo(file_paths[fi], target_sr)
        n_src = len(src_L)
        print(f"    File [{fi+1}] {n_src} samples", flush=True)

        # Build COUPLED gain + pan targets. In v3.0 overlapping fixed/hybrid
        # segments took the maximum gain but "last writer wins" pan, so the pan
        # could belong to a different event than the gain actually being heard.
        gain_target = np.zeros(n_src, dtype=np.float64)
        pan_target = np.zeros(n_src, dtype=np.float64)

        rows = file_rows.get(fi, [])
        for row in rows:
            src_sr = row["src_sr"]
            if src_sr == target_sr:
                ss, se = row["src_start_samp"], row["src_end_samp"]
            else:
                ratio = target_sr / src_sr
                ss = int(round(row["src_start_samp"] * ratio))
                se = int(round(row["src_end_samp"] * ratio))
            ss = max(0, min(ss, n_src)); se = max(ss, min(se, n_src))
            if se <= ss:
                continue
            g = float(row["gain"]); p = float(row["pan"])
            cur = gain_target[ss:se]
            choose = g > cur + 1e-12
            # On equal gain, higher-priority later plan row may define the colour.
            if np.any(choose):
                cur[choose] = g
                pan_slice = pan_target[ss:se]
                pan_slice[choose] = p

        active_target = (gain_target > 0).astype(np.float64)
        gain_env = gain_target.copy()
        pan_env = pan_target.copy()
        if smooth_n > 1 and n_src > smooth_n * 2:
            kernel = np.hanning(smooth_n * 2 + 1)
            kernel /= kernel.sum()
            gain_env = fast_smooth(gain_target, kernel)
            # Smooth pan only over active support, so zeros outside events do not
            # pull pan toward the centre and create an unintended second fade.
            pan_num = fast_smooth(pan_target * active_target, kernel)
            pan_den = fast_smooth(active_target, kernel)
            pan_env = np.divide(pan_num, np.maximum(pan_den, 1e-12),
                                out=np.zeros_like(pan_num), where=pan_den > 1e-9)

        pan_env = np.clip(pan_env, -1.0, 1.0)
        pan_angle = (pan_env + 1.0) * (math.pi / 4.0)
        pan_l_env = np.cos(pan_angle)
        pan_r_env = np.sin(pan_angle)

        # ── Apply envelopes to full file and accumulate ONCE ─────────
        scaled_L = src_L.astype(np.float64) * gain_env * pan_l_env
        scaled_R = src_R.astype(np.float64) * gain_env * pan_r_env

        # Place into output buffer (source position = output position)
        out_len = min(n_src, n_out)
        buf_L[:out_len] += scaled_L[:out_len]
        buf_R[:out_len] += scaled_R[:out_len]

        print(f"      gain range: {gain_env.min():.4f}–{gain_env.max():.4f}  "
              f"active: {np.count_nonzero(gain_env)}/{n_src} samples",
              flush=True)

    # ── Diagnostics ──────────────────────────────────────────────────────
    # Windowed RMS, not a single sample: a legitimate waveform zero crossing
    # at a segment boundary must not be reported as a renderer dropout.
    check_r = max(4, int(0.004 * target_sr))
    centre_r = max(2, int(0.001 * target_sr))
    all_starts = sorted(set(
        row["src_start_samp"] if row["src_sr"] == target_sr
        else int(round(row["src_start_samp"] * target_sr / row["src_sr"]))
        for row in plan_rows
    ))
    dbg_dips = 0

    def stereo_rms(lo, hi):
        lo = max(0, lo); hi = min(len(buf_L), hi)
        if hi <= lo:
            return 0.0
        return float(np.sqrt(np.mean(buf_L[lo:hi]**2 + buf_R[lo:hi]**2) + 1e-20))

    for bp in all_starts:
        if bp < check_r or bp + check_r >= len(buf_L):
            continue
        centre = stereo_rms(bp-centre_r, bp+centre_r)
        before = stereo_rms(bp-check_r, bp-centre_r)
        after = stereo_rms(bp+centre_r, bp+check_r)
        surround = 0.5 * (before + after)
        if surround > 1e-5 and centre < surround * 0.30:
            dbg_dips += 1
            if dbg_dips <= 5:
                print(f"    RMS dip near {bp/target_sr:.4f}s: "
                      f"centre={centre:.6f} vs surround={surround:.6f}", flush=True)
    if dbg_dips > 5:
        print(f"    ... and {dbg_dips - 5} more RMS dips", flush=True)
    if dbg_dips == 0:
        print("    No boundary RMS dips detected", flush=True)

    # ── Trim / normalize / write ─────────────────────────────────────────
    trim = n_out
    while trim > 0 and abs(buf_L[trim-1]) < 1e-6 and abs(buf_R[trim-1]) < 1e-6:
        trim -= 1
    trim = max(trim, target_sr // 10)
    buf_L, buf_R = buf_L[:trim], buf_R[:trim]

    peak = max(np.max(np.abs(buf_L)), np.max(np.abs(buf_R)), 1e-12)
    rms_l = float(np.sqrt(np.mean(buf_L ** 2)))
    rms_r = float(np.sqrt(np.mean(buf_R ** 2)))
    print(f"    Pre-norm: peak={peak:.4f}  RMS L={rms_l:.4f} R={rms_r:.4f}",
          flush=True)

    if peak > 0.95:
        s = 0.95 / peak
        buf_L *= s; buf_R *= s
        print(f"    Scaled peak {peak:.3f} → 0.95", flush=True)

    actual_dur = trim / target_sr
    print(f"    Output: {actual_dur:.2f}s stereo @ {target_sr}Hz", flush=True)

    stereo = np.column_stack([buf_L.astype(np.float32),
                              buf_R.astype(np.float32)])
    sf.write(result_path, stereo, target_sr, subtype="FLOAT")
    print(f"    Written: {result_path}", flush=True)
    return actual_dur


# ─────────────────────────────────────────────────────────────────────────────
# I/O HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def read_manifest(path):
    entries = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line: continue
            parts = line.split("\t")
            if len(parts) < 3: continue
            entries.append({
                "index": int(parts[0]), "name": parts[1],
                "wav_path": parts[2],
                "duration": float(parts[3]) if len(parts) > 3 else None,
                "sr": int(parts[4]) if len(parts) > 4 else None,
                "channels": int(parts[5]) if len(parts) > 5 else None,
            })
    return entries


def write_plan_csv(path, rows, max_dur=0.0):
    if not rows: return
    fld = ["time","file_index","file_name","seg_index","src_start","src_dur",
           "gain","role","layer_group","entry_time","exit_time","transform",
           "state","density","priority","pan","tension","polyphony"]
    with open(path, "w", newline="", encoding="utf-8") as f:
        f.write(f"#max_dur={round(max_dur,6)}\n")
        w = csv.DictWriter(f, fieldnames=fld, delimiter="\t", extrasaction="ignore")
        w.writeheader(); w.writerows(rows)


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(description="Algorithmic Conductor v3.2")
    ap.add_argument("manifest_file", type=str)
    ap.add_argument("descriptor_file", type=str)
    ap.add_argument("mix_plan_file", type=str)
    ap.add_argument("done_file", type=str)
    ap.add_argument("--result_wav", type=str, default="")
    ap.add_argument("--style", type=str, default="dramatic")
    ap.add_argument("--seg_mode", type=str, default="onset")
    ap.add_argument("--frame_ms", type=float, default=80.0)
    ap.add_argument("--hop_ms", type=float, default=40.0)
    ap.add_argument("--onset_gap_ms", type=float, default=50.0)
    ap.add_argument("--memory", type=float, default=0.4)
    ap.add_argument("--tension", type=float, default=0.6)
    ap.add_argument("--allow_silence", type=int, default=1)
    ap.add_argument("--nonlinear", type=int, default=1)
    args = ap.parse_args()

    print("=== Algorithmic Conductor Mix v3.2 ===", flush=True)
    print(f"Style: {args.style} | Seg: {args.seg_mode} | "
          f"Mem: {args.memory:.2f} | Tens: {args.tension:.2f}", flush=True)

    manifest = read_manifest(args.manifest_file)
    macro_by_index = read_macro_descriptors(args.descriptor_file)
    print(f"Ensemble: {len(manifest)} files | Praat macro descriptors: {len(macro_by_index)}", flush=True)

    print("Loading audio...", flush=True)
    file_audios, file_srs, file_names, file_paths, macro_descs = [], [], [], [], []
    for entry in manifest:
        if not os.path.isfile(entry["wav_path"]):
            raise FileNotFoundError(f"Input WAV missing: {entry['wav_path']}")
        audio, sr, mix_mode = load_audio_mono(entry["wav_path"])
        file_audios.append(audio); file_srs.append(sr)
        file_names.append(entry["name"]); file_paths.append(entry["wav_path"])
        macro_descs.append(macro_by_index.get(entry["index"]))
        print(f"  [{entry['index']}] {entry['name']} | {len(audio)/sr:.2f}s @ {sr}Hz | analysis={mix_mode}", flush=True)

    if len(file_audios) < 2:
        print("ERROR: Need >=2 audio files.", flush=True)
        with open(args.done_file, "w") as f: f.write("error\n")
        sys.exit(1)

    plan, _max_dur = conduct(
        file_audios, file_srs, file_names, args.seg_mode,
        args.frame_ms, args.hop_ms, args.onset_gap_ms,
        args.style, args.memory, args.tension,
        bool(args.allow_silence), bool(args.nonlinear), macro_descs=macro_descs)

    write_plan_csv(args.mix_plan_file, plan, max_dur=_max_dur)
    print(f"Plan CSV: {args.mix_plan_file} ({len(plan)} events)", flush=True)

    target_sr = max(file_srs)
    result_wav = args.result_wav or args.mix_plan_file.replace(".csv", "_mix.wav")

    actual_dur = render_mix(plan, file_paths, target_sr, _max_dur, result_wav)

    rc = Counter(r["role"] for r in plan)
    sc = Counter(r["state"] for r in plan)
    print(f"Roles: {dict(rc)}", flush=True)
    print(f"States: {dict(sc)}", flush=True)
    print(f"Duration: {actual_dur:.2f}s", flush=True)

    with open(args.done_file, "w") as f: f.write("ok\n")
    print("OK: conductor done", flush=True)


if __name__ == "__main__":
    # Praat polls done_file. On a Python exception, always release the poller
    # immediately instead of making the user wait for the 10-minute timeout.
    done_path = sys.argv[4] if len(sys.argv) > 4 else None
    try:
        main()
    except Exception:
        tb = traceback.format_exc()
        print(tb, file=sys.stderr, flush=True)
        if done_path:
            try:
                with open(done_path, "w") as f:
                    f.write("error\n")
            except OSError:
                pass
        sys.exit(1)