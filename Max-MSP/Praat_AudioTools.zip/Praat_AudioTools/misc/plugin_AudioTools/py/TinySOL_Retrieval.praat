# ============================================================
# Praat AudioTools - TinySOL_Retrieval.praat
# Author: Shai Cohen
# Affiliation: Department of Music, Bar-Ilan University, Israel
# Email: shai.cohen@biu.ac.il
# Version: 1.9 (2026) - Target macro-envelope transfer
# License: MIT License
# Repository: https://github.com/ShaiCohen-ops/Praat-plugin_AudioTools
#
# Description:
#   TinySOL Orchestration Retrieval
#
#   Exports the selected Sound to a temp WAV, passes it to the
#   Python backend (tinysol_retrieval.py) which:
#     1. Loads pre-computed .db descriptor files (mfcc, specenv,
#        moments, specpeaks, spectrum) — no full corpus recompute.
#     2. Parses TinySOL filenames to build a rich metadata index.
#     3. Analyses the target sound and computes comparable descriptors.
#     4. Retrieves the closest orchestral analogues by weighted
#        multi-descriptor distance.
#     5. Optionally blends 2-4 samples for a richer texture.
#     6. Returns a rendered WAV + a ranked results text file.
#   Praat then imports the WAV and displays the results summary.
#
# Changelog v1.9 (2026):
#   - MUSICAL: optional Envelope_follow transfers the target's smoothed macro-RMS
#     gesture onto the retrieved result. This reduces duration/envelope mismatch
#     between heterogeneous TinySOL samples without time-stretching or pitch shift.
#   - Envelope_follow=0 is exact v1.8 rendering; default 0.85. Backend reports
#     target-envelope correlation before/after transfer.
#
# Changelog v1.8 (2026):
#   - Python v1.8 backend: corrected F0/pitch-gate logic, silent-frame handling,
#     frame-mode silence gate, variant selection, speech pitch neutrality,
#     polyphase resampling, and strongest-channel target analysis.
#   - CORPUS: All families now includes official TinySOL Keyboards/Accordion;
#     added Keyboards-only filter. Family detection is path-based in Python.
#   - UI: All dynamics now means no dynamic preference penalty (previously it
#     still preferred pp/p/mf/ff and penalised f).
#   - UI: descriptor weights are relative; they are normalized internally and
#     need not sum to 1. At least one must be positive.
#   - VIS: representative strongest channels + shared waveform scale; 10 kHz
#     spectrogram ceiling where supported; title/subtitle viewport repaired.
#
# Changelog v1.5 (2026):
#   - FIX: The probe loop's "if pythonCmd$ = """ post-check at the
#     end was dead code: the OS-discovery block (lines 36-50) always
#     assigned pythonCmd$ to something non-empty, so total probe
#     failure couldn't be detected. Now pythonCmd$ is cleared
#     before the probe loop, and the early-discovery path (when
#     present) is prepended as the highest-priority candidate.
#     Total Python failure now produces the documented error.
#   - PORTABILITY: Replaced the for-loop early-break that mutated
#     the loop variable (iCand = nCandidates + 1) with a "found"
#     flag pattern. Loop-var mutation works in current Praat but
#     is documented as fragile across versions.
# ============================================================

# ---- INPUT CHECK ----
if numberOfSelected("Sound") <> 1
    exitScript: "Please select exactly one Sound object."
endif

sound     = selected("Sound")
soundName$ = selected$("Sound")

# ---- OS-SPECIFIC PYTHON DISCOVERY ----
if macintosh
    if fileReadable("/opt/homebrew/bin/python3")
        pythonCmd$ = "/opt/homebrew/bin/python3"
    elsif fileReadable("/Library/Frameworks/Python.framework/Versions/3.14/bin/python3")
        pythonCmd$ = "/Library/Frameworks/Python.framework/Versions/3.14/bin/python3"
    elsif fileReadable("/usr/local/bin/python3")
        pythonCmd$ = "/usr/local/bin/python3"
    else
        pythonCmd$ = "python3"
    endif
elsif windows
    pythonCmd$ = "python"
else
    pythonCmd$ = "python3"
endif

# ---- PATHS & UNIFIED CROSS-PLATFORM FIX ----
pluginDirRaw$ = preferencesDirectory$ + "/plugin_AudioTools/"
pluginDir$ = replace_regex$(pluginDirRaw$, "\\", "/", 0)

pythonScript$ = pluginDir$ + "py/tinysol_retrieval.py"
if not fileReadable(pythonScript$)
    pythonScript$ = defaultDirectory$ + "/tinysol_retrieval.py"
endif
if not fileReadable(pythonScript$)
    exitScript: "Cannot find Python script: tinysol_retrieval.py" + newline$ + "Expected at: " + pluginDir$ + "py/ or next to this script."
endif

tempDirRaw$ = temporaryDirectory$ + "/"
tempDir$ = replace_regex$(tempDirRaw$, "\\", "/", 0)

runTag$    = replace_regex$(soundName$, "[^A-Za-z0-9_]", "_", 0) + "_" + string$(sound) + "_" + replace_regex$(date$(), "[ :]", "_", 0)
runTag$    = replace_regex$(runTag$, "__+", "_", 0)

tempInput$   = tempDir$ + "tmp_" + runTag$ + "_input.wav"
tempParams$  = tempDir$ + "tmp_" + runTag$ + "_params.txt"
tempOutput$  = tempDir$ + "tmp_" + runTag$ + "_output.wav"
tempResults$ = tempDir$ + "tmp_" + runTag$ + "_results.txt"
doneFile$    = tempDir$ + "tmp_" + runTag$ + "_done.txt"
probePy$     = tempDir$ + "tmp_" + runTag$ + "_probe.py"
probeMarker$ = tempDir$ + "tmp_" + runTag$ + "_probe.ok"

# Enforce forward slashes for all temporary paths passed to python
pythonScriptJ$ = replace_regex$(pythonScript$, "\\", "/", 0)
tempInputJ$    = replace_regex$(tempInput$, "\\", "/", 0)
tempParamsJ$   = replace_regex$(tempParams$, "\\", "/", 0)
tempOutputJ$   = replace_regex$(tempOutput$, "\\", "/", 0)
tempResultsJ$  = replace_regex$(tempResults$, "\\", "/", 0)
doneFileJ$     = replace_regex$(doneFile$, "\\", "/", 0)
probePyJ$      = replace_regex$(probePy$, "\\", "/", 0)
probeMarkerJ$  = replace_regex$(probeMarker$, "\\", "/", 0)

# ---- CLEANUP PROCEDURE ----
procedure cleanUpTempFiles
    if fileReadable(tempInput$)
        deleteFile: tempInput$
    endif
    if fileReadable(tempParams$)
        deleteFile: tempParams$
    endif
    if fileReadable(tempOutput$)
        deleteFile: tempOutput$
    endif
    if fileReadable(tempResults$)
        deleteFile: tempResults$
    endif
    if fileReadable(doneFile$)
        deleteFile: doneFile$
    endif
    if fileReadable(probePy$)
        deleteFile: probePy$
    endif
    if fileReadable(probeMarker$)
        deleteFile: probeMarker$
    endif
endproc

@cleanUpTempFiles

# ---- FORM ----
form TinySOL Orchestration Retrieval v1.9
    # ── Preset  ───────────────────────────────────────────────────────
    optionmenu Preset: 1
        option Custom  (use fields as-is)
        option REF-whole  (whole-file reference preset)
        option REF-frame  (frame-based reference preset)
        option REF-orchids  (Orchidea-architecture preset)
        option Speech  (speech / vocal input — no harmonic matching)

    # ── Corpus paths ─────────────────────────────────────────────────
    sentence DB_directory         D:/old D/waves/TinySOL_2020
    sentence Corpus_root          D:/old D/waves/TinySOL_2020/TinySOL

    # ── Instrument / family constraints ──────────────────────────────
    optionmenu Instrument_families: 1
        option All families
        option Brass only
        option Strings only
        option Winds only
        option Brass + Strings
        option Brass + Winds
        option Strings + Winds
        option Keyboards only

    sentence Specific_instruments 

    # ── Pitch range (MIDI) ───────────────────────────────────────────
    integer Min_MIDI_pitch 36
    integer Max_MIDI_pitch 96

    # ── Dynamics ────────────────────────────────────────────────────
    optionmenu Preferred_dynamics: 3
        option pp
        option p
        option mf
        option ff
        option pp + mf
        option mf + ff
        option All dynamics

    # ── Analysis mode ────────────────────────────────────────────────
    optionmenu Analysis_mode: 1
        option Whole file  (average timbre)
        option Frame-based  (follows pitch + dynamics)

    integer Frame_size_ms 150
    integer Hop_size_ms 75
    integer Pitch_tolerance_semitones 2
    boolean Pitch_pan_in_stereo 0

    # ── Retrieval & render ───────────────────────────────────────────
    integer Number_of_results 8

    optionmenu Render_mode: 1
        option best              (single best match)
        option blend             (top-3 rank-weighted mix)
        option top2              (top-2 equal mix)
        option top3              (top-3 equal mix)
        option top4              (top-4 equal mix)

    real Render_gain 0.8
    real Envelope_follow 0.85

    # ── Descriptor weights  (relative; normalized internally) ─────────
    real MFCC_weight    0.25
    real Specenv_weight 0.20
    real Moments_weight 0.05
    real Specpeaks_weight 0.15
    real Harmonic_weight 0.35

    boolean Draw_visualization 1
    boolean Play_result 1
    boolean Stereo_output 0
    boolean Speech_mode 0
    # ── Match quality gate ───────────────────────────────────────────
    real Silence_threshold 2.0
endform

# Sanitize input paths from the UI to ensure forward slashes
dB_directory$ = replace_regex$(dB_directory$, "\\", "/", 0)
corpus_root$  = replace_regex$(corpus_root$, "\\", "/", 0)

# ---- APPLY PRESET ----
if preset = 2
    analysisStr$             = "whole_file"
    analysis_mode            = 1
    mFCC_weight              = 0.25
    specenv_weight           = 0.20
    moments_weight           = 0.05
    specpeaks_weight         = 0.15
    harmonic_weight          = 0.35
    dynStr$                  = "mf,ff"
    preferred_dynamics       = 6
    render_mode              = 1
    renderStr$               = "best"
    stereo_output            = 0
    pitch_pan_in_stereo      = 0
    draw_visualization       = 1
    silence_threshold        = 1.0
elsif preset = 3
    analysisStr$             = "frame_based"
    analysis_mode            = 2
    frame_size_ms            = 150
    hop_size_ms              = 75
    pitch_tolerance_semitones = 2
    mFCC_weight              = 0.25
    specenv_weight           = 0.20
    moments_weight           = 0.05
    specpeaks_weight         = 0.15
    harmonic_weight          = 0.35
    dynStr$                  = "mf,ff"
    preferred_dynamics       = 6
    render_mode              = 1
    renderStr$               = "best"
    stereo_output            = 0
    pitch_pan_in_stereo      = 0
    draw_visualization       = 1
    silence_threshold        = 1.0
elsif preset = 4
    analysisStr$             = "whole_file"
    analysis_mode            = 1
    mFCC_weight              = 0.20
    specenv_weight           = 0.30
    moments_weight           = 0.05
    specpeaks_weight         = 0.10
    harmonic_weight          = 0.35
    dynStr$                  = "mf,ff"
    preferred_dynamics       = 6
    render_mode              = 1
    renderStr$               = "best"
    stereo_output            = 0
    pitch_pan_in_stereo      = 0
    draw_visualization       = 1
    silence_threshold        = 1.0
endif

if preset = 5
    analysisStr$             = "whole_file"
    analysis_mode            = 1
    mFCC_weight              = 0.45
    specenv_weight           = 0.30
    moments_weight           = 0.10
    specpeaks_weight         = 0.15
    harmonic_weight          = 0.00
    dynStr$                  = "mf,ff"
    preferred_dynamics       = 6
    render_mode              = 1
    renderStr$               = "best"
    stereo_output            = 0
    pitch_pan_in_stereo      = 0
    draw_visualization       = 1
    silence_threshold        = 2.0
    speech_mode              = 1
endif

# ---- CLAMP numerical inputs ----
if min_MIDI_pitch < 0
    min_MIDI_pitch = 0
endif
if min_MIDI_pitch > 127
    min_MIDI_pitch = 127
endif
if max_MIDI_pitch < min_MIDI_pitch
    max_MIDI_pitch = min_MIDI_pitch
endif
if max_MIDI_pitch > 127
    max_MIDI_pitch = 127
endif
if number_of_results < 1
    number_of_results = 1
endif
if number_of_results > 32
    number_of_results = 32
endif
if render_gain <= 0
    render_gain = 0.01
endif
if render_gain > 2
    render_gain = 2
endif
if envelope_follow < 0
    envelope_follow = 0
endif
if envelope_follow > 1
    envelope_follow = 1
endif
if mFCC_weight < 0
    mFCC_weight = 0
endif
if specenv_weight < 0
    specenv_weight = 0
endif
if moments_weight < 0
    moments_weight = 0
endif
if specpeaks_weight < 0
    specpeaks_weight = 0
endif
if harmonic_weight < 0
    harmonic_weight = 0
endif
if silence_threshold < 0
    silence_threshold = 0
endif
if silence_threshold > 2
    silence_threshold = 2
endif

# ---- Resolve analysis mode ----
if analysis_mode = 1
    analysisStr$ = "whole_file"
else
    analysisStr$ = "frame_based"
endif

# ---- Clamp frame params ----
if frame_size_ms < 50
    frame_size_ms = 50
endif
if frame_size_ms > 500
    frame_size_ms = 500
endif
if hop_size_ms < 10
    hop_size_ms = 10
endif
if hop_size_ms > frame_size_ms
    hop_size_ms = frame_size_ms
endif
if pitch_tolerance_semitones < 0
    pitch_tolerance_semitones = 0
endif
if pitch_tolerance_semitones > 12
    pitch_tolerance_semitones = 12
endif

# ---- Resolve instrument families string ----
if instrument_families = 1
    familyStr$ = "Brass,Strings,Winds,Keyboards"
elsif instrument_families = 2
    familyStr$ = "Brass"
elsif instrument_families = 3
    familyStr$ = "Strings"
elsif instrument_families = 4
    familyStr$ = "Winds"
elsif instrument_families = 5
    familyStr$ = "Brass,Strings"
elsif instrument_families = 6
    familyStr$ = "Brass,Winds"
elsif instrument_families = 7
    familyStr$ = "Strings,Winds"
else
    familyStr$ = "Keyboards"
endif

# ---- Resolve dynamics string ----
if preferred_dynamics = 1
    dynStr$ = "pp"
elsif preferred_dynamics = 2
    dynStr$ = "p"
elsif preferred_dynamics = 3
    dynStr$ = "mf"
elsif preferred_dynamics = 4
    dynStr$ = "ff"
elsif preferred_dynamics = 5
    dynStr$ = "pp,mf"
elsif preferred_dynamics = 6
    dynStr$ = "mf,ff"
else
    # Empty list = no dynamic preference penalty: truly "All dynamics".
    dynStr$ = ""
endif

dynDisplay$ = dynStr$
if preferred_dynamics = 7
    dynDisplay$ = "All"
endif

# ---- Resolve render mode string ----
if render_mode = 1
    renderStr$ = "best"
elsif render_mode = 2
    renderStr$ = "blend"
elsif render_mode = 3
    renderStr$ = "top2"
elsif render_mode = 4
    renderStr$ = "top3"
else
    renderStr$ = "top4"
endif

# Speech mode uses the backend's speech-optimised profile and disables
# harmonic/pitch scoring there. Mirror the weights here so the Info panel is honest.
if speech_mode
    mFCC_weight      = 0.45
    specenv_weight   = 0.30
    moments_weight   = 0.10
    specpeaks_weight = 0.15
    harmonic_weight  = 0.00
endif

weightSum = mFCC_weight + specenv_weight + moments_weight + specpeaks_weight + harmonic_weight
if weightSum <= 0
    @cleanUpTempFiles
    exitScript: "At least one descriptor weight must be greater than zero."
endif

# ---- INFO header ----
clearinfo
writeInfoLine:  "=== TinySOL Orchestration Retrieval v1.9 ==="
appendInfoLine: "Input:   ", soundName$
appendInfoLine: "DB dir:  ", dB_directory$
appendInfoLine: "Corpus:  ", corpus_root$
if preset = 2
    appendInfoLine: ">>> Preset: REF-whole applied <<<"
elsif preset = 3
    appendInfoLine: ">>> Preset: REF-frame applied <<<"
elsif preset = 4
    appendInfoLine: ">>> Preset: REF-orchids applied (hard MIDI filter, silence gate disabled) <<<"
elsif preset = 5
    appendInfoLine: ">>> Preset: Speech applied (harmonic=0, silence gate raised) <<<"
endif
appendInfoLine: ""
appendInfoLine: "Families:   ", familyStr$
appendInfoLine: "Dynamics:   ", dynDisplay$
appendInfoLine: "MIDI range: ", min_MIDI_pitch, " — ", max_MIDI_pitch
appendInfoLine: "Analysis:   ", analysisStr$
if analysis_mode = 2
    appendInfoLine: "Frame/hop:  ", frame_size_ms, " ms / ", hop_size_ms, " ms  pitch_tol: ±", pitch_tolerance_semitones, " st"
endif
appendInfoLine: "Render:     ", renderStr$, "  gain=", fixed$(render_gain, 2), "  stereo=", stereo_output, "  envelope=", fixed$(envelope_follow, 2), "  silence_threshold=", fixed$(silence_threshold, 2)
appendInfoLine: "Weights:    mfcc=", fixed$(mFCC_weight, 2),
    ... "  specenv=", fixed$(specenv_weight, 2),
    ... "  moments=", fixed$(moments_weight, 2),
    ... "  specpeaks=", fixed$(specpeaks_weight, 2),
    ... "  harmonic=", fixed$(harmonic_weight, 2)
appendInfoLine: ""

# ---- Original sound stats ----
selectObject: sound
dur       = Get total duration
sr        = Get sampling frequency
nChannels = Get number of channels
rms_orig  = Get root-mean-square: 0, 0

# ===========================================================================
# Stage 0 — Early Python Dependency Probe
# ===========================================================================
appendInfoLine: "[0/5] Detecting Python dependencies..."

writeFileLine: probePy$, "import sys"
appendFileLine: probePy$, "try:"
appendFileLine: probePy$, "    import numpy, scipy, soundfile"
appendFileLine: probePy$, "    with open(r'" + probeMarkerJ$ + "', 'w') as f: f.write('ok')"
appendFileLine: probePy$, "except ImportError:"
appendFileLine: probePy$, "    sys.exit(1)"

# v1.5: Save the OS-discovery value as a candidate0 (highest priority),
# then clear pythonCmd$ so the post-probe check can detect total failure.
# The OS-discovery block at the top set pythonCmd$ to a path like
# /opt/homebrew/bin/python3 if available — if that path passes the
# probe, it's preferred over the generic "python3" name (which may
# resolve to a different Python on Mac).
earlyDiscovered$ = pythonCmd$
pythonCmd$ = ""

if windows
    nCandidates = 5
    candidate1$ = earlyDiscovered$
    candidate2$ = "python"
    candidate3$ = "py"
    candidate4$ = "py -3"
    candidate5$ = "python3"
else
    nCandidates = 4
    candidate1$ = earlyDiscovered$
    candidate2$ = "python3"
    candidate3$ = "python"
    candidate4$ = "py"
    candidate5$ = ""
endif

found = 0
for iCand from 1 to nCandidates
    if found = 0
        if iCand = 1
            tryCmd$ = candidate1$
        elsif iCand = 2
            tryCmd$ = candidate2$
        elsif iCand = 3
            tryCmd$ = candidate3$
        elsif iCand = 4
            tryCmd$ = candidate4$
        else
            tryCmd$ = candidate5$
        endif

        # Skip empty candidate slot (Linux candidate5)
        if tryCmd$ <> ""
            if fileReadable(probeMarker$)
                deleteFile: probeMarker$
            endif

            runSystem_nocheck: tryCmd$ + " """ + probePyJ$ + """"

            if fileReadable(probeMarker$)
                pythonCmd$ = tryCmd$
                deleteFile: probeMarker$
                found = 1
            endif
        endif
    endif
endfor

deleteFile: probePy$

if pythonCmd$ = ""
    @cleanUpTempFiles
    exitScript: "Cannot find Python 3 installation with required packages." + newline$ + "Tried: " + earlyDiscovered$ + ", python3, python, py" + newline$ + "Please install: pip install numpy scipy soundfile"
endif

appendInfoLine: "  Python found: ", pythonCmd$

# ===========================================================================
# Stage 1 — Export target WAV
# ===========================================================================
appendInfoLine: "[1/5] Exporting target audio..."
selectObject: sound
Save as WAV file: tempInput$

# ===========================================================================
# Stage 2 — Write params file
# ===========================================================================
appendInfoLine: "[2/5] Writing parameter file..."
deleteFile: tempParams$

# Build descriptor weight string
descWeightStr$ = "mfcc:" + string$(mFCC_weight)
    ... + ",specenv:" + string$(specenv_weight)
    ... + ",moments:" + string$(moments_weight)
    ... + ",specpeaks:" + string$(specpeaks_weight)
    ... + ",harmonic:" + string$(harmonic_weight)

# Write params (key=value, one per line)
writeFileLine: tempParams$, "db_dir=" + dB_directory$
appendFileLine: tempParams$, "corpus_root=" + corpus_root$
appendFileLine: tempParams$, "allowed_families=" + familyStr$
appendFileLine: tempParams$, "allowed_instruments=" + specific_instruments$
appendFileLine: tempParams$, "min_midi=" + string$(min_MIDI_pitch)
appendFileLine: tempParams$, "max_midi=" + string$(max_MIDI_pitch)
appendFileLine: tempParams$, "preferred_dynamics=" + dynStr$
appendFileLine: tempParams$, "max_layers=4"
appendFileLine: tempParams$, "descriptor_weights=" + descWeightStr$
appendFileLine: tempParams$, "n_results=" + string$(number_of_results)
appendFileLine: tempParams$, "render_mode=" + renderStr$
appendFileLine: tempParams$, "render_gain=" + string$(render_gain)
appendFileLine: tempParams$, "envelope_follow=" + string$(envelope_follow)
appendFileLine: tempParams$, "stereo_output=" + string$(stereo_output)
appendFileLine: tempParams$, "analysis_mode=" + analysisStr$
appendFileLine: tempParams$, "frame_size_ms=" + string$(frame_size_ms)
appendFileLine: tempParams$, "hop_size_ms=" + string$(hop_size_ms)
appendFileLine: tempParams$, "pitch_tolerance=" + string$(pitch_tolerance_semitones)
appendFileLine: tempParams$, "pitch_pan_stereo=" + string$(pitch_pan_in_stereo)
appendFileLine: tempParams$, "silence_threshold=" + string$(silence_threshold)
appendFileLine: tempParams$, "speech_mode=" + string$(speech_mode)

# ===========================================================================
# Stage 3 — Run Python backend
# ===========================================================================
appendInfoLine: "[3/5] Running Python retrieval engine..."
appendInfoLine: "  (this may take a few seconds on first run while the"
appendInfoLine: "   corpus index is built from the .db files)"
appendInfoLine: ""

pythonCall$ = pythonCmd$ + " """ + pythonScriptJ$ + """"
    ... + " """ + tempInputJ$   + """"
    ... + " """ + tempParamsJ$  + """"
    ... + " """ + tempOutputJ$  + """"
    ... + " """ + tempResultsJ$ + """"
    ... + " """ + doneFileJ$    + """"

runSystem_nocheck: pythonCall$

# ---- Check done file for status ----
if fileReadable(doneFile$)
    doneStatus$ = readFile$(doneFile$)
    if index(doneStatus$, "ERROR") > 0
        @cleanUpTempFiles
        exitScript: "Python backend reported an error:" + newline$ + doneStatus$
    endif
elsif not fileReadable(tempOutput$)
    @cleanUpTempFiles
    exitScript: "Python backend did not produce output WAV." + newline$ + "Check the Praat Info window and verify paths."
endif

# ===========================================================================
# Stage 4 — Import result
# ===========================================================================
appendInfoLine: "[4/5] Importing result..."

Read from file: tempOutput$
resultSound = selected("Sound")
Rename: soundName$ + "_orchestrated"

# ---- Output stats ----
selectObject: resultSound
dur_out   = Get total duration
rms_out   = Get root-mean-square: 0, 0

# ===========================================================================
# Stage 5 — Parse results file + display
# ===========================================================================
appendInfoLine: "[5/5] Reading retrieval results..."
appendInfoLine: ""

bestMatch$     = "?"
bestScore$     = "?"
nCandidates$   = "?"
renderMode$    = "?"
chosenCount$   = "?"
silenceFlag$   = ""

if fileReadable(tempResults$)
    resultText$ = readFile$(tempResults$)

    # Extract scalar stats using the parseStatLine procedure
    @parseStatLine: resultText$, "n_candidates="
    nCandidates$ = parseStatLine.result$

    @parseStatLine: resultText$, "render_mode="
    renderMode$ = parseStatLine.result$

    @parseStatLine: resultText$, "chosen_count="
    chosenCount$ = parseStatLine.result$

    @parseStatLine: resultText$, "silence_rendered="
    silenceRendered$ = parseStatLine.result$
    @parseStatLine: resultText$, "silence_reason="
    silenceReason$ = parseStatLine.result$
    if silenceRendered$ = "1"
        if silenceReason$ = "silent_target"
            silenceFlag$ = "  [SILENCE - silent target]"
        elsif silenceReason$ = "frame_unmatched"
            silenceFlag$ = "  [SILENCE - no frame matches]"
        else
            silenceFlag$ = "  [SILENCE - score > threshold]"
        endif
    endif

    # Parse top-ranked match from the CSV section
    csvStart = index(resultText$, newline$ + "1,")
    if csvStart > 0
        lineStart = csvStart + 1
        tailText$ = mid$(resultText$, lineStart, length(resultText$) - lineStart + 1)
        nlPos = index(tailText$, newline$)
        if nlPos > 0
            firstLine$ = left$(tailText$, nlPos - 1)
        else
            firstLine$ = tailText$
        endif

        nCommas = 0
        fieldCount = 0
        fieldStr$ = firstLine$

        # field 1 = rank
        p = index(fieldStr$, ",")
        if p > 0
            f1$ = left$(fieldStr$, p - 1)
            fieldStr$ = mid$(fieldStr$, p + 1, length(fieldStr$) - p)
        endif
        # field 2 = score
        p = index(fieldStr$, ",")
        if p > 0
            bestScore$ = left$(fieldStr$, p - 1)
            fieldStr$ = mid$(fieldStr$, p + 1, length(fieldStr$) - p)
        endif
        # field 3 = family
        p = index(fieldStr$, ",")
        if p > 0
            bf$ = left$(fieldStr$, p - 1)
            fieldStr$ = mid$(fieldStr$, p + 1, length(fieldStr$) - p)
        endif
        # field 4 = instrument
        p = index(fieldStr$, ",")
        if p > 0
            bi$ = left$(fieldStr$, p - 1)
            fieldStr$ = mid$(fieldStr$, p + 1, length(fieldStr$) - p)
        endif
        # field 5 = note
        p = index(fieldStr$, ",")
        if p > 0
            bn$ = left$(fieldStr$, p - 1)
            fieldStr$ = mid$(fieldStr$, p + 1, length(fieldStr$) - p)
        endif
        # field 6 = midi  (skip)
        p = index(fieldStr$, ",")
        if p > 0
            fieldStr$ = mid$(fieldStr$, p + 1, length(fieldStr$) - p)
        endif
        # field 7 = dynamic
        p = index(fieldStr$, ",")
        if p > 0
            bd$ = left$(fieldStr$, p - 1)
            fieldStr$ = mid$(fieldStr$, p + 1, length(fieldStr$) - p)
        endif

        bestMatch$ = bf$ + " " + bi$ + " " + bn$ + " " + bd$
    endif
endif

# ===========================================================================
# Visualization (optional)
# ===========================================================================
if draw_visualization
    appendInfoLine: "Drawing visualization..."

    # Representative real input channel: strongest RMS channel, avoiding
    # phase-cancelling mono fold-down.  Use the strongest result channel too.
    analysisChannel = 1
    bestVizRms = -1
    for ch from 1 to nChannels
        selectObject: sound
        chObj = Extract one channel: ch
        chRms = Get root-mean-square: 0, 0
        if chRms > bestVizRms
            bestVizRms = chRms
            analysisChannel = ch
        endif
        removeObject: chObj
    endfor

    selectObject: sound
    if nChannels > 1
        vizIn = Extract one channel: analysisChannel
    else
        Copy: "tinysol_viz_input"
        vizIn = selected("Sound")
    endif

    selectObject: resultSound
    nChRes = Get number of channels
    resultChannel = 1
    bestOutRms = -1
    for ch from 1 to nChRes
        selectObject: resultSound
        chObj = Extract one channel: ch
        chRms = Get root-mean-square: 0, 0
        if chRms > bestOutRms
            bestOutRms = chRms
            resultChannel = ch
        endif
        removeObject: chObj
    endfor
    selectObject: resultSound
    if nChRes > 1
        vizOut = Extract one channel: resultChannel
    else
        Copy: "tinysol_viz_output"
        vizOut = selected("Sound")
    endif

    selectObject: vizIn
    inPeak = Get absolute extremum: 0, 0, "none"
    selectObject: vizOut
    outPeak = Get absolute extremum: 0, 0, "none"
    wavePeak = 1.05 * max(inPeak, outPeak)
    if wavePeak < 0.000001
        wavePeak = 1
    endif
    specCeil = min(10000, sr / 2)

    Erase all
    Select outer viewport: 0, 8, 0, 8

    # ----------------------------------------------------------
    # Title
    # ----------------------------------------------------------
    Select outer viewport: 0, 8, 0, 0.65
    Axes: 0, 1, 0, 1
    Font size: 12
    Colour: "Black"
    Text: 0.5, "centre", 0.68, "half", "##TinySOL Orchestration Retrieval v1.9##"
    Font size: 7
    Colour: "{0.35, 0.35, 0.52}"
    Text: 0.5, "centre", -1.22, "half",
        ... soundName$ + "  |  " + analysisStr$
        ... + "  |  " + renderStr$
        ... + "  |  " + familyStr$

    # ----------------------------------------------------------
    # Input waveform — explicit shared scale
    # ----------------------------------------------------------
    Select outer viewport: 0, 8, 0.70, 1.55
    Select inner viewport: 0.55, 7.65, 0.75, 1.50
    selectObject: vizIn
    Colour: "{0.55, 0.55, 0.55}"
    Draw: 0, 0, -wavePeak, wavePeak, "no", "Curve"
    Colour: "Black"
    Draw inner box
    Font size: 7
    Text left: "yes", "Input ch" + string$(analysisChannel)
    Text top: "no", "Target waveform  [shared amplitude scale]"

    # ----------------------------------------------------------
    # Output waveform — same scale
    # ----------------------------------------------------------
    Select outer viewport: 0, 8, 1.55, 2.40
    Select inner viewport: 0.55, 7.65, 1.60, 2.35
    selectObject: vizOut
    Colour: "{0.15, 0.50, 0.35}"
    Draw: 0, 0, -wavePeak, wavePeak, "no", "Curve"
    Colour: "Black"
    Draw inner box
    Font size: 7
    Text left: "yes", "Output ch" + string$(resultChannel)
    Text bottom: "yes", "Time (s)"
    Text top: "no", "Retrieved render  [same amplitude scale]"

    # ----------------------------------------------------------
    # Input spectrogram
    # ----------------------------------------------------------
    Select outer viewport: 0, 4.1, 2.50, 3.90
    Select inner viewport: 0.55, 3.85, 2.60, 3.80
    selectObject: vizIn
    To Spectrogram: 0.02, specCeil, 0.005, 20, "Gaussian"
    specOrig = selected("Spectrogram")
    Paint: 0, 0, 0, specCeil, 100, "yes", 50, 6, 0, "no"
    Colour: "Black"
    Draw inner box
    Font size: 7
    Text left: "yes", "Hz"
    Text bottom: "yes", "Time (s)"
    Text top: "no", "Target spectrogram ch" + string$(analysisChannel) + " (auto-levelled)"
    removeObject: specOrig

    # ----------------------------------------------------------
    # Output spectrogram
    # ----------------------------------------------------------
    Select outer viewport: 4.1, 8, 2.50, 3.90
    Select inner viewport: 4.40, 7.65, 2.60, 3.80
    selectObject: vizOut
    To Spectrogram: 0.02, specCeil, 0.005, 20, "Gaussian"
    specRes = selected("Spectrogram")
    Paint: 0, 0, 0, specCeil, 100, "yes", 50, 6, 0, "no"
    Colour: "Black"
    Draw inner box
    Font size: 7
    Text left: "yes", "Hz"
    Text bottom: "yes", "Time (s)"
    Text top: "no", "Retrieved spectrogram ch" + string$(resultChannel) + " (auto-levelled)"
    removeObject: specRes

    # ----------------------------------------------------------
    # Retrieval results panel
    # ----------------------------------------------------------
    Select outer viewport: 0, 8, 4.02, 5.42
    Select inner viewport: 0.55, 7.65, 4.08, 5.36
    Axes: 0, 1, 0, 1
    Paint rectangle: "{0.94, 0.94, 0.96}", 0, 1, 0, 1

    Font size: 7
    Colour: "Black"
    Text: 0.02, "left", 0.91, "half", "##Retrieval Results##"
    Font size: 6
    Colour: "{0.30, 0.30, 0.30}"
    Text: 0.02, "left", 0.74, "half",
        ... "Best match:  " + bestMatch$ + "   score=" + bestScore$ + silenceFlag$

    if analysis_mode = 2
        Text: 0.02, "left", 0.57, "half",
            ... "Frames: " + nCandidates$
            ... + "  |  Matched: " + chosenCount$
            ... + "  |  pitch tol: " + string$(pitch_tolerance_semitones) + " st"
            ... + "  |  Gain: " + fixed$(render_gain, 2) + "  |  Env: " + fixed$(envelope_follow, 2)
    else
        Text: 0.02, "left", 0.57, "half",
            ... "Candidates: " + nCandidates$
            ... + "  |  Layers: " + chosenCount$
            ... + "  |  Mode: " + renderMode$
            ... + "  |  Gain: " + fixed$(render_gain, 2) + "  |  Env: " + fixed$(envelope_follow, 2)
    endif

    Text: 0.02, "left", 0.40, "half",
        ... "Families: " + familyStr$
        ... + "  |  Dynamics: " + dynDisplay$
        ... + "  |  MIDI: " + string$(min_MIDI_pitch) + "-" + string$(max_MIDI_pitch)

    Text: 0.02, "left", 0.23, "half",
        ... "Weights: mfcc=" + fixed$(mFCC_weight, 2)
        ... + " specenv=" + fixed$(specenv_weight, 2)
        ... + " moments=" + fixed$(moments_weight, 2)
        ... + " specpeaks=" + fixed$(specpeaks_weight, 2)
        ... + " harmonic=" + fixed$(harmonic_weight, 2)

    Text: 0.02, "left", 0.08, "half",
        ... "Flow: target descriptors -> hard candidate domain -> weighted distance -> rank -> render"
    Colour: "Black"
    Draw rectangle: 0, 1, 0, 1

    # ----------------------------------------------------------
    # Summary panel
    # ----------------------------------------------------------
    Select outer viewport: 0, 8, 5.52, 6.22
    Select inner viewport: 0.55, 7.65, 5.58, 6.16
    Axes: 0, 1, 0, 1
    Paint rectangle: "{0.94, 0.94, 0.94}", 0, 1, 0, 1
    Font size: 7
    Colour: "Black"
    Text: 0.02, "left", 0.80, "half", "##Summary##"
    Font size: 6
    Colour: "{0.30, 0.30, 0.30}"
    Text: 0.02, "left", 0.47, "half",
        ... "Target: " + fixed$(dur, 2) + "s  RMS=" + fixed$(rms_orig, 4)
        ... + "  |  Output: " + fixed$(dur_out, 2) + "s  RMS=" + fixed$(rms_out, 4)
    Text: 0.02, "left", 0.20, "half",
        ... "Analysis ch " + string$(analysisChannel)
        ... + " -> display output ch " + string$(resultChannel)
        ... + "  |  silence threshold=" + fixed$(silence_threshold, 2)
        ... + " (2=disabled)"
    Colour: "Black"
    Draw rectangle: 0, 1, 0, 1

    removeObject: vizIn, vizOut

    Font size: 10
    Colour: "Black"
    Line width: 1
endif

# ===========================================================================
# Final Cleanup
# ===========================================================================
@cleanUpTempFiles

# ===========================================================================
# Summary
# ===========================================================================

appendInfoLine: ""
appendInfoLine: "=== COMPLETE ==="
appendInfoLine: "Output: ", soundName$, "_orchestrated"
appendInfoLine: ""
appendInfoLine: "Best match:     ", bestMatch$, silenceFlag$
appendInfoLine: "Match score:    ", bestScore$, "  (lower = closer)"
if analysis_mode = 2
    appendInfoLine: "Frames analyzed:", nCandidates$
    appendInfoLine: "Frames matched: ", chosenCount$
    appendInfoLine: "Render mode:    frame_based"
else
    appendInfoLine: "Candidates:     ", nCandidates$
    appendInfoLine: "Layers used:    ", chosenCount$
    appendInfoLine: "Render mode:    ", renderMode$
endif
appendInfoLine: ""
appendInfoLine: "Target:         ", fixed$(dur, 2), " s  RMS=", fixed$(rms_orig, 4)
appendInfoLine: "Output:         ", fixed$(dur_out, 2), " s  RMS=", fixed$(rms_out, 4)

selectObject: resultSound

if play_result
    Play
endif

# ===========================================================================
# Procedures
# ===========================================================================
procedure parseStatLine: .text$, .key$
    .result$ = "?"
    .pos = index(.text$, .key$)
    if .pos > 0
        .start = .pos + length(.key$)
        .rest$ = mid$(.text$, .start, length(.text$) - .start + 1)
        .nlPos = index(.rest$, newline$)
        if .nlPos = 0
            .nlPos = index(.rest$, unicode$(10))
        endif
        if .nlPos > 0
            .result$ = left$(.rest$, .nlPos - 1)
        else
            .result$ = .rest$
        endif
        if length(.result$) > 0
            if right$(.result$, 1) = unicode$(13)
                .result$ = left$(.result$, length(.result$) - 1)
            endif
        endif
    endif
endproc