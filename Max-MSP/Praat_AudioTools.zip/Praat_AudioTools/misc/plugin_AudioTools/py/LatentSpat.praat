# ============================================================
# Praat AudioTools - LatentSpat.praat
# Author: Shai Cohen
# Affiliation: Department of Music, Bar-Ilan University, Israel
# Email: shai.cohen@biu.ac.il
# Version: 1.3 (2026)
# License: MIT License
# Repository: https://github.com/ShaiCohen-ops/Praat-plugin_AudioTools
#
# Description:
#   Latent Spat — Agent-Based Spatialization
#
#   Extends Latent Counterpoint with physical space: each agent's
#   latent position maps to spatial coordinates via VBAP panning.
#   Latent X → azimuth (position around listener)
#   Latent Y → distance (amplitude, filtering, reverb)
#
#   When agents repel in timbre, they move to opposite sides
#   of the room. The counterpoint becomes spatial.
#
#   Spatial formats: Stereo, Quad, 5.1, Octophonic
#   Distance models: Amplitude, +LowPass, +LowPass+Reverb
#
# Citation:
#   Cohen, S. (2026). Praat AudioTools: An Offline Analysis-Resynthesis
#   Toolkit for Experimental Composition.
#   https://github.com/ShaiCohen-ops/Praat-plugin_AudioTools
#
# Changelog v1.3:
#   - Preserve the v1.2 agent/physics/spatial law for ordinary inputs
#   - Fix single-event geometry and multichannel anti-phase fold-down
#   - 5.1 LFE is now a true non-directional ~120 Hz bass feed
#   - Circular azimuth statistics + measured trajectory visualization
#   - Praat 7 trust guard and non-zero xmin-safe analysis
#
# Changelog v1.2:
#   - 5.1: Python pans among real speakers only (LFE fed separately);
#     front/center content is no longer routed into the LFE and lost
#   - Renamed the Duration form field to a clean identifier
#   - Removed unused RMS captures and a redundant clearinfo
#
# ============================================================

# ---- INPUT CHECK ----
if numberOfSelected("Sound") <> 1
    exitScript: "Please select exactly one Sound object."
endif

sound = selected("Sound")
soundName$ = selected$("Sound")

# Praat 7 full-trust guard: this script writes temp files and calls Python.
if praatVersion >= 7000
    askForTrust()
endif

# ---- OS-SPECIFIC PYTHON DISCOVERY ----
if macintosh
    if fileReadable("/opt/homebrew/bin/python3")
        pythonCmd$ = "/opt/homebrew/bin/python3"
    elsif fileReadable("/Library/Frameworks/Python.framework/Versions/3.14/bin/python3")
        pythonCmd$ = "/Library/Frameworks/Python.framework/Versions/3.14/bin/python3"
    elsif fileReadable("/usr/local/bin/python3")
        pythonCmd$ = "/usr/local/bin/python3"
    else
        pythonCmd$ = "python3"
    endif
elsif windows
    pythonCmd$ = "python"
else
    pythonCmd$ = "python3"
endif

# ---- PATHS & UNIFIED CROSS-PLATFORM FIX ----
pluginDirRaw$ = preferencesDirectory$ + "/plugin_AudioTools/"
pluginDir$ = replace_regex$(pluginDirRaw$, "\\", "/", 0)

pythonScript$ = pluginDir$ + "py/latent_spat.py"

if not fileReadable(pythonScript$)
    pythonScript$ = defaultDirectory$ + "/latent_spat.py"
endif
if not fileReadable(pythonScript$)
    exitScript: "Cannot find Python script: latent_spat.py" + newline$ + "Expected at: " + pluginDir$ + "py/ or next to this script."
endif

tempInput$   = temporaryDirectory$ + "/temp_latspat_input.wav"
tempCSV$     = temporaryDirectory$ + "/temp_latspat_events.csv"
tempOutput$  = temporaryDirectory$ + "/temp_latspat_output.wav"
tempStats$   = temporaryDirectory$ + "/temp_latspat_stats.txt"
probePy$     = temporaryDirectory$ + "/temp_latspat_probe.py"
probeMarker$ = temporaryDirectory$ + "/temp_latspat_probe.ok"

# Enforce forward slashes for all temporary paths passed to python
pythonScriptJ$ = replace_regex$(pythonScript$, "\\", "/", 0)
tempInputJ$    = replace_regex$(tempInput$, "\\", "/", 0)
tempCSVJ$      = replace_regex$(tempCSV$, "\\", "/", 0)
tempOutputJ$   = replace_regex$(tempOutput$, "\\", "/", 0)
tempStatsJ$    = replace_regex$(tempStats$, "\\", "/", 0)
probePyJ$      = replace_regex$(probePy$, "\\", "/", 0)
probeMarkerJ$  = replace_regex$(probeMarker$, "\\", "/", 0)

# ---- CLEANUP PROCEDURE ----
procedure cleanUpTempFiles
    if fileReadable(tempInput$)
        deleteFile: tempInput$
    endif
    if fileReadable(tempCSV$)
        deleteFile: tempCSV$
    endif
    if fileReadable(tempOutput$)
        deleteFile: tempOutput$
    endif
    if fileReadable(tempStats$)
        deleteFile: tempStats$
    endif
    if fileReadable(probeMarker$)
        deleteFile: probeMarker$
    endif
    if fileReadable(probePy$)
        deleteFile: probePy$
    endif
endproc

@cleanUpTempFiles

# ---- FORM ----
form Latent Spat v1.3 — Agent-Based Spatialization
    optionmenu Preset: 1
        option Custom
        option Stereo duo
        option Quad trio
        option Surround ensemble
        option Octophonic scatter
        option Immersive drift
        option Close-mic trio
    integer Number_of_agents 3
    integer Latent_size 8
    real Counterpoint_rigidity 0.5
    real Speed 0.5
    optionmenu Spatial_format: 1
        option Stereo (2ch)
        option Quad (4ch)
        option 5.1 (6ch)
        option Octophonic (8ch)
    optionmenu Distance_model: 3
        option Amplitude only
        option Amplitude + Low-pass
        option Amplitude + Low-pass + Reverb
    real Reverb_amount 0.4
    comment Output duration in seconds (0 = original)
    real Duration 0
    integer Seed 42
    boolean Draw_visualization 1
    boolean Play_result 1
endform

# ---- PRESETS ----
if preset = 2
    number_of_agents = 2
    latent_size = 6
    counterpoint_rigidity = 0.4
    speed = 0.4
    spatial_format = 1
    distance_model = 2
    reverb_amount = 0.2
    presetName$ = "StereoDuo"
elsif preset = 3
    number_of_agents = 3
    latent_size = 8
    counterpoint_rigidity = 0.5
    speed = 0.5
    spatial_format = 2
    distance_model = 3
    reverb_amount = 0.4
    presetName$ = "QuadTrio"
elsif preset = 4
    number_of_agents = 4
    latent_size = 10
    counterpoint_rigidity = 0.6
    speed = 0.5
    spatial_format = 3
    distance_model = 3
    reverb_amount = 0.5
    presetName$ = "SurroundEnsemble"
elsif preset = 5
    number_of_agents = 5
    latent_size = 12
    counterpoint_rigidity = 0.8
    speed = 0.8
    spatial_format = 4
    distance_model = 3
    reverb_amount = 0.5
    presetName$ = "OctoScatter"
elsif preset = 6
    number_of_agents = 3
    latent_size = 10
    counterpoint_rigidity = 0.3
    speed = 0.3
    spatial_format = 4
    distance_model = 3
    reverb_amount = 0.7
    presetName$ = "ImmersiveDrift"
elsif preset = 7
    number_of_agents = 3
    latent_size = 8
    counterpoint_rigidity = 0.6
    speed = 0.5
    spatial_format = 2
    distance_model = 1
    reverb_amount = 0.0
    presetName$ = "CloseMicTrio"
else
    presetName$ = "Custom"
endif

# Clamp
if number_of_agents < 2
    number_of_agents = 2
endif
if number_of_agents > 6
    number_of_agents = 6
endif
if latent_size < 2
    latent_size = 2
endif
if latent_size > 32
    latent_size = 32
endif
if reverb_amount < 0
    reverb_amount = 0
endif
if reverb_amount > 1
    reverb_amount = 1
endif

# Map menu indices to Python integers (0-based)
spatFormatInt = spatial_format - 1
distModelInt = distance_model - 1

# Format info
if spatial_format = 1
    spatName$ = "Stereo"
    nCh = 2
    chLabel$ = "L R"
elsif spatial_format = 2
    spatName$ = "Quad"
    nCh = 4
    chLabel$ = "FL FR RL RR"
elsif spatial_format = 3
    spatName$ = "5.1"
    nCh = 6
    chLabel$ = "L R C LFE LS RS"
else
    spatName$ = "Octophonic"
    nCh = 8
    chLabel$ = "F FR R RR B RL L FL"
endif

if distance_model = 1
    distName$ = "Amplitude"
elsif distance_model = 2
    distName$ = "Amp+LowPass"
else
    distName$ = "Amp+LP+Reverb"
endif

# ---- INFO ----
writeInfoLine:  "=== Latent Spat v1.3 — Agent-Based Spatialization ==="
appendInfoLine: "Input: ", soundName$
appendInfoLine: "Preset: ", presetName$
appendInfoLine: ""
appendInfoLine: "Agents:     ", number_of_agents
appendInfoLine: "Latent:     ", latent_size
appendInfoLine: "Rigidity:   ", fixed$(counterpoint_rigidity, 2)
appendInfoLine: "Speed:      ", fixed$(speed, 2)
appendInfoLine: ""
appendInfoLine: "Spatial:    ", spatName$, " (", nCh, " ch)"
appendInfoLine: "Distance:   ", distName$
appendInfoLine: "Reverb:     ", fixed$(reverb_amount, 2)
appendInfoLine: "Channels:   ", chLabel$
appendInfoLine: ""

# ---- CAPTURE ORIGINAL STATS ----
selectObject: sound
dur = Get total duration
sr  = Get sampling frequency
nChannels = Get number of channels

if duration <= 0
    duration = dur
endif

appendInfoLine: "Duration: ", fixed$(dur, 2), " s | SR: ", sr, " Hz | Channels: ", nChannels
appendInfoLine: ""

# ===========================================================================
# Stage 1 — Detect Python Dependencies
# ===========================================================================
appendInfoLine: "[1/5] Detecting Python dependencies..."

# File-Based Python Probing (safest cross-platform approach)
pyCode$ = "import sys" + newline$
pyCode$ = pyCode$ + "try:" + newline$
pyCode$ = pyCode$ + "    import numpy, scipy, soundfile" + newline$
pyCode$ = pyCode$ + "    with open('" + probeMarkerJ$ + "', 'w') as f:" + newline$
pyCode$ = pyCode$ + "        f.write('ok')" + newline$
pyCode$ = pyCode$ + "except Exception as e:" + newline$
pyCode$ = pyCode$ + "    print('Missing dependencies:', e)" + newline$
writeFile: probePy$, pyCode$

probeCmd$ = pythonCmd$ + " """ + probePyJ$ + """"
runSystem_nocheck: probeCmd$

if not fileReadable(probeMarker$)
    @cleanUpTempFiles
    exitScript: "Python not found or dependencies missing." + newline$ + "Please install: pip install numpy scipy soundfile"
endif

deleteFile: probeMarker$
deleteFile: probePy$
appendInfoLine: "  Python found: ", pythonCmd$

# ===========================================================================
# Stage 2 — Event Segmentation
# ===========================================================================
appendInfoLine: "[2/5] Segmenting events..."

minEventDur = 0.200
maxEventDur = 3.000

selectObject: sound
if nChannels > 1
    Extract one channel: 1
    analysisMono = selected("Sound")
else
    Copy: "analysisMono"
    analysisMono = selected("Sound")
endif

# Exported WAV time starts at sample 0. Put the analysis copy on that same
# time base so a non-zero Sound xmin cannot offset event boundaries.
selectObject: analysisMono
Shift times to: "start time", 0

selectObject: analysisMono
pitchObj = To Pitch: 0.01, 75, 600

selectObject: analysisMono
harmObj = To Harmonicity (cc): 0.01, 75, 0.1, 1.0

selectObject: analysisMono
intObj = To Intensity: 100, 0.01, "yes"

selectObject: intObj
intMatrix = Down to Matrix
intSound = To Sound (slice): 1
selectObject: intSound
ppObj = To PointProcess (extrema): 1, "yes", "no", "Sinc70"

selectObject: ppObj
nPeaks = Get number of points

bound_1 = 0
bound_2 = dur
iBound = 3
for iPeak from 1 to nPeaks
    selectObject: ppObj
    peakT = Get time from index: iPeak
    bound_'iBound' = peakT
    iBound = iBound + 1
endfor
nBounds = iBound - 1

for i from 1 to nBounds
    for j from i + 1 to nBounds
        if bound_'j' < bound_'i'
            tmpVal = bound_'i'
            bound_'i' = bound_'j'
            bound_'j' = tmpVal
        endif
    endfor
endfor

nFinal = 0
prevT = -1
for i from 1 to nBounds
    thisT = bound_'i'
    if thisT - prevT >= minEventDur
        nFinal = nFinal + 1
        final_'nFinal' = thisT
        prevT = thisT
    endif
endfor

if nFinal > 0
    lastFinal = final_'nFinal'
    if dur - lastFinal > 0.050
        nFinal = nFinal + 1
        final_'nFinal' = dur
    else
        final_'nFinal' = dur
    endif
else
    nFinal = 2
    final_1 = 0
    final_2 = dur
endif

nEvents = 0
for i from 1 to nFinal - 1
    evStart = final_'i'
    iNext = i + 1
    evEnd = final_'iNext'
    evDur = evEnd - evStart

    if evDur > maxEventDur
        nChunks = ceiling(evDur / maxEventDur)
        chunkDur = evDur / nChunks
        for iChunk from 0 to nChunks - 1
            nEvents = nEvents + 1
            evS_'nEvents' = evStart + iChunk * chunkDur
            if iChunk = nChunks - 1
                evE_'nEvents' = evEnd
            else
                evE_'nEvents' = evStart + (iChunk + 1) * chunkDur
            endif
        endfor
    elsif evDur >= minEventDur
        nEvents = nEvents + 1
        evS_'nEvents' = evStart
        evE_'nEvents' = evEnd
    endif
endfor

if nEvents < 2
    nEvents = 1
    evS_1 = 0
    evE_1 = dur
endif

appendInfoLine: "  Found ", nEvents, " events"

# ===========================================================================
# Stage 3 — Extract Features + Export
# ===========================================================================
appendInfoLine: "[3/5] Extracting features..."

Create Table with column names: "eventFeatures", nEvents, "start_time end_time label pitch_stability intensity_mean attack_slope hnr_mean"
eventTable = selected("Table")

for iEv from 1 to nEvents
    t1 = evS_'iEv'
    t2 = evE_'iEv'
    tMid = (t1 + t2) / 2

    selectObject: eventTable
    Set numeric value: iEv, "start_time", t1
    Set numeric value: iEv, "end_time", t2
    Set string value: iEv, "label", "ev" + string$(iEv)

    selectObject: pitchObj
    pMean = Get mean: t1, t2, "Hertz"
    pStd = Get standard deviation: t1, t2, "Hertz"
    if pMean = undefined or pMean = 0
        pitchStab = 0
    else
        if pStd = undefined
            pStd = 0
        endif
        pitchCV = pStd / (pMean + 0.001)
        pitchStab = 1 - min(1, pitchCV)
        if pitchStab < 0
            pitchStab = 0
        endif
    endif
    selectObject: eventTable
    Set numeric value: iEv, "pitch_stability", pitchStab

    selectObject: intObj
    iMean = Get mean: t1, t2, "energy"
    if iMean = undefined
        iMean = 0
    endif
    iStart = Get value at time: t1, "Cubic"
    if iStart = undefined
        iStart = 0
    endif
    iPeak = Get maximum: t1, t2, "Parabolic"
    if iPeak = undefined
        iPeak = iStart
    endif
    tPeak = Get time of maximum: t1, t2, "Parabolic"
    if tPeak = undefined
        tPeak = tMid
    endif
    attackTime = tPeak - t1
    if attackTime > 0.001
        attackSlope = (iPeak - iStart) / attackTime
    else
        attackSlope = 0
    endif
    selectObject: eventTable
    Set numeric value: iEv, "intensity_mean", iMean
    Set numeric value: iEv, "attack_slope", attackSlope

    selectObject: harmObj
    hMean = Get mean: t1, t2
    if hMean = undefined
        hMean = 0
    endif
    selectObject: eventTable
    Set numeric value: iEv, "hnr_mean", hMean
endfor

appendInfoLine: "  Exporting temp files..."
selectObject: sound
Save as WAV file: tempInput$
selectObject: eventTable
Save as comma-separated file: tempCSV$

removeObject: analysisMono, pitchObj, harmObj, intObj
removeObject: intMatrix, intSound, ppObj, eventTable

# ===========================================================================
# Stage 4 — Call Python Engine
# ===========================================================================
appendInfoLine: "[4/5] Running Python engine..."
appendInfoLine: "  (Training AE + ", number_of_agents, "-voice counterpoint → ", spatName$, " spatialization)"

pythonCall$ = pythonCmd$ + " """ + pythonScriptJ$ + """"
    ... + " """ + tempInputJ$ + """"
    ... + " """ + tempCSVJ$ + """"
    ... + " """ + tempOutputJ$ + """"
    ... + " """ + tempStatsJ$ + """"
    ... + " " + string$(number_of_agents)
    ... + " " + string$(latent_size)
    ... + " " + fixed$(counterpoint_rigidity, 4)
    ... + " " + fixed$(speed, 4)
    ... + " " + fixed$(duration, 4)
    ... + " " + string$(spatFormatInt)
    ... + " " + string$(distModelInt)
    ... + " " + fixed$(reverb_amount, 4)
    ... + " " + string$(seed)

runSystem_nocheck: pythonCall$

if not fileReadable(tempOutput$)
    @cleanUpTempFiles
    exitScript: "Python spatialization engine failed." + newline$ + "Check terminal for error details."
endif

# ===========================================================================
# Stage 5 — Import Result
# ===========================================================================
appendInfoLine: "[5/5] Importing result..."

Read from file: tempOutput$
Rename: soundName$ + "_spat"
resultSound = selected("Sound")

selectObject: resultSound
durOut = Get total duration
nChOut = Get number of channels

# ===========================================================================
# Read Stats
# ===========================================================================
nEvStat$ = "?"
nAgentsStat$ = "?"
nChannelsStat$ = "?"
spatFormatStat$ = "?"
distModelStat$ = "?"
reverbStat$ = "?"
outDurStat$ = "?"
finalLoss$ = "?"
initialLoss$ = "?"
meanEvDur$ = "?"
totalUnique$ = "?"
speakerLabels$ = "?"
warningStat$ = ""

for iA from 0 to 5
    agProfile_'iA'$ = "?"
    agSteps_'iA'$ = "?"
    agUnique_'iA'$ = "?"
    agRepRate_'iA'$ = "?"
    agAzRange_'iA'$ = "?"
    agAzTravel_'iA'$ = "?"
    agMeanDist_'iA'$ = "?"
    agMeanAz_'iA'$ = "?"
    agNSpat_'iA' = 0
endfor

for iA from 0 to 5
    for iB from iA + 1 to 5
        unisonRate_'iA'_'iB'$ = "?"
        spatSep_'iA'_'iB'$ = "?"
    endfor
endfor

if fileReadable(tempStats$)
    statsText$ = readFile$(tempStats$)

    @parseStatLine: statsText$, "n_events="
    nEvStat$ = parseStatLine.result$
    @parseStatLine: statsText$, "n_agents="
    nAgentsStat$ = parseStatLine.result$
    @parseStatLine: statsText$, "n_channels="
    nChannelsStat$ = parseStatLine.result$
    @parseStatLine: statsText$, "spatial_format="
    spatFormatStat$ = parseStatLine.result$
    @parseStatLine: statsText$, "distance_model="
    distModelStat$ = parseStatLine.result$
    @parseStatLine: statsText$, "reverb_amount="
    reverbStat$ = parseStatLine.result$
    @parseStatLine: statsText$, "output_duration="
    outDurStat$ = parseStatLine.result$
    @parseStatLine: statsText$, "final_loss="
    finalLoss$ = parseStatLine.result$
    @parseStatLine: statsText$, "initial_loss="
    initialLoss$ = parseStatLine.result$
    @parseStatLine: statsText$, "mean_event_dur="
    meanEvDur$ = parseStatLine.result$
    @parseStatLine: statsText$, "total_unique_events="
    totalUnique$ = parseStatLine.result$
    @parseStatLine: statsText$, "speaker_labels="
    speakerLabels$ = parseStatLine.result$
    @parseStatLine: statsText$, "warning="
    warningStat$ = parseStatLine.result$

    for iA from 0 to number_of_agents - 1
        @parseStatLine: statsText$, "agent_" + string$(iA) + "_profile="
        agProfile_'iA'$ = parseStatLine.result$
        @parseStatLine: statsText$, "agent_" + string$(iA) + "_steps="
        agSteps_'iA'$ = parseStatLine.result$
        @parseStatLine: statsText$, "agent_" + string$(iA) + "_unique="
        agUnique_'iA'$ = parseStatLine.result$
        @parseStatLine: statsText$, "agent_" + string$(iA) + "_rep_rate="
        agRepRate_'iA'$ = parseStatLine.result$
        @parseStatLine: statsText$, "agent_" + string$(iA) + "_az_range="
        agAzRange_'iA'$ = parseStatLine.result$
        @parseStatLine: statsText$, "agent_" + string$(iA) + "_az_travel="
        agAzTravel_'iA'$ = parseStatLine.result$
        @parseStatLine: statsText$, "agent_" + string$(iA) + "_mean_dist="
        agMeanDist_'iA'$ = parseStatLine.result$
        @parseStatLine: statsText$, "agent_" + string$(iA) + "_mean_az="
        agMeanAz_'iA'$ = parseStatLine.result$

        @parseStatLine: statsText$, "agent_" + string$(iA) + "_n_spat="
        nSpatRaw$ = parseStatLine.result$
        agNSpat_'iA' = 0
        if nSpatRaw$ <> "?"
            agNSpat_'iA' = number(nSpatRaw$)
        endif
        if agNSpat_'iA' > 61
            agNSpat_'iA' = 61
        endif
        for iP from 0 to agNSpat_'iA' - 1
            @parseStatLine: statsText$, "agent_" + string$(iA) + "_spat_" + string$(iP) + "="
            spatRaw$ = parseStatLine.result$
            agSpat_'iA'_'iP'_az = 0
            agSpat_'iA'_'iP'_dist = 0.55
            if spatRaw$ <> "?"
                comma = index(spatRaw$, ",")
                if comma > 0
                    agSpat_'iA'_'iP'_az = number(left$(spatRaw$, comma - 1))
                    agSpat_'iA'_'iP'_dist = number(mid$(spatRaw$, comma + 1, length(spatRaw$) - comma))
                endif
            endif
        endfor
    endfor

    for iA from 0 to number_of_agents - 2
        for iB from iA + 1 to number_of_agents - 1
            @parseStatLine: statsText$, "unison_rate_" + string$(iA) + "_" + string$(iB) + "="
            unisonRate_'iA'_'iB'$ = parseStatLine.result$
            @parseStatLine: statsText$, "spatial_sep_" + string$(iA) + "_" + string$(iB) + "="
            spatSep_'iA'_'iB'$ = parseStatLine.result$
        endfor
    endfor
endif

###############################################################################
# VISUALIZATION
###############################################################################

if draw_visualization
    appendInfoLine: ""
    appendInfoLine: "Drawing visualization..."

    Erase all
    Select outer viewport: 0, 8, 0, 8

    # === Title ===
    Select outer viewport: 0, 8, 0, 0.55
    Select inner viewport: 0, 8, 0, 0.55
    Axes: 0, 1, 0, 1
    Font size: 12
    Colour: "Black"
    Text: 0.5, "centre", 0.72, "half", "##Latent Spat — Agent-Based Spatialization##"
    Font size: 8
    Colour: "{0.34,0.38,0.48}"
    Text: 0.5, "centre", 0.22, "half", soundName$ + " | " + presetName$ + " | " + spatFormatStat$ + " " + nChannelsStat$ + "ch | latent agents -> azimuth/distance -> VBAP"

    # === Input Waveform ===
    Select outer viewport: 0, 8, 0.6, 1.5
    Select inner viewport: 0.6, 7.7, 0.65, 1.45
    selectObject: sound
    Copy: "visOriginal"
    visOriginal = selected("Sound")
    Shift times to: "start time", 0
    Colour: "{0.46,0.49,0.56}"
    Draw: 0, 0, 0, 0, "no", "Curve"
    Colour: "Black"
    Draw inner box
    Font size: 7
    Text left: "yes", "Original"
    Select outer viewport: 0, 8, 0.6, 1.5
    Select inner viewport: 0.6, 7.7, 0.65, 1.45
    Axes: 0, dur, -1, 1
    Colour: "{0.20,0.40,0.75}"
    Line width: 1
    for iEv from 1 to nEvents
        evBound = evS_'iEv'
        if evBound > 0 and evBound < dur
            Draw line: evBound, -0.9, evBound, 0.9
        endif
    endfor
    Colour: "Black"
    Text top: "no", string$(nEvents) + " events | " + fixed$(dur, 2) + " s"
    removeObject: visOriginal

    # === Output Waveform (ch 1) ===
    Select outer viewport: 0, 8, 1.5, 2.4
    Select inner viewport: 0.6, 7.7, 1.55, 2.35
    selectObject: resultSound
    Extract one channel: 1
    tmpCh1 = selected("Sound")
    Colour: "{0.20,0.40,0.75}"
    Draw: 0, 0, 0, 0, "no", "Curve"
    Colour: "Black"
    Draw inner box
    Font size: 7
    Text left: "yes", "Ch 1"
    Text bottom: "yes", "Time (s)"
    removeObject: tmpCh1

    # === Measured Spatial Field (top-down) ===
    Select outer viewport: 0, 4, 2.5, 5.1
    Select inner viewport: 0.4, 3.8, 2.7, 4.9
    Axes: -1.5, 1.5, -1.5, 1.5

    Paint rectangle: "{0.965,0.975,0.990}", -1.5, 1.5, -1.5, 1.5
    Colour: "{0.78,0.82,0.88}"
    Draw circle: 0, 0, 1.0
    Colour: "{0.88,0.90,0.94}"
    Draw circle: 0, 0, 0.5

    agCol_0$ = "{0.20,0.40,0.75}"
    agCol_1$ = "{0.18,0.58,0.62}"
    agCol_2$ = "{0.42,0.48,0.62}"
    agCol_3$ = "{0.36,0.34,0.62}"
    agCol_4$ = "{0.27,0.52,0.68}"
    agCol_5$ = "{0.50,0.44,0.64}"

    agSymb_0$ = "C"
    agSymb_1$ = "F"
    agSymb_2$ = "S"
    agSymb_3$ = "C"
    agSymb_4$ = "F"
    agSymb_5$ = "S"

    # Draw the measured trajectory of each agent first. Distance is radial:
    # close=centre, far=edge; azimuth 0 deg is front/top.
    for iA from 0 to number_of_agents - 1
        thisCol$ = agCol_'iA'$
        nPath = agNSpat_'iA'
        if nPath > 1
            Colour: thisCol$
            Line width: 1
            for iP from 1 to nPath - 1
                prevP = iP - 1
                az0 = agSpat_'iA'_'prevP'_az
                d0 = agSpat_'iA'_'prevP'_dist
                az1 = agSpat_'iA'_'iP'_az
                d1 = agSpat_'iA'_'iP'_dist
                r0 = d0
                r1 = d1
                a0 = (90 - az0) * pi / 180
                a1 = (90 - az1) * pi / 180
                x0 = r0 * cos(a0)
                y0 = r0 * sin(a0)
                x1 = r1 * cos(a1)
                y1 = r1 * sin(a1)
                # Do not draw a chord across the whole room when the numeric
                # azimuth representation crosses 0/360.
                dAz = abs(az1 - az0)
                if dAz > 180
                    dAz = 360 - dAz
                endif
                if dAz < 90
                    Draw line: x0, y0, x1, y1
                endif
            endfor
        endif
    endfor

    # Directional speaker layout. LFE is deliberately not positioned at 0 deg:
    # it is a non-directional bass feed, not a VBAP speaker.
    if spatial_format = 1
        nSpkDraw = 2
        spkAz_1 = 330
        spkAz_2 = 30
        spkLab_1$ = "L"
        spkLab_2$ = "R"
    elsif spatial_format = 2
        nSpkDraw = 4
        spkAz_1 = 315
        spkAz_2 = 45
        spkAz_3 = 225
        spkAz_4 = 135
        spkLab_1$ = "FL"
        spkLab_2$ = "FR"
        spkLab_3$ = "RL"
        spkLab_4$ = "RR"
    elsif spatial_format = 3
        nSpkDraw = 5
        spkAz_1 = 330
        spkAz_2 = 30
        spkAz_3 = 0
        spkAz_4 = 240
        spkAz_5 = 120
        spkLab_1$ = "L"
        spkLab_2$ = "R"
        spkLab_3$ = "C"
        spkLab_4$ = "LS"
        spkLab_5$ = "RS"
    else
        nSpkDraw = 8
        spkAz_1 = 0
        spkAz_2 = 45
        spkAz_3 = 90
        spkAz_4 = 135
        spkAz_5 = 180
        spkAz_6 = 225
        spkAz_7 = 270
        spkAz_8 = 315
        spkLab_1$ = "F"
        spkLab_2$ = "FR"
        spkLab_3$ = "R"
        spkLab_4$ = "RR"
        spkLab_5$ = "B"
        spkLab_6$ = "RL"
        spkLab_7$ = "L"
        spkLab_8$ = "FL"
    endif

    for iSpk from 1 to nSpkDraw
        thisAz = spkAz_'iSpk'
        azRad = (90 - thisAz) * pi / 180
        sx = 1.18 * cos(azRad)
        sy = 1.18 * sin(azRad)
        Paint rectangle: "{0.70,0.74,0.80}", sx - 0.045, sx + 0.045, sy - 0.045, sy + 0.045
    endfor

    # Mean measured position for each agent.
    for iA from 0 to number_of_agents - 1
        thisCol$ = agCol_'iA'$
        thisSymb$ = agSymb_'iA'$
        if agMeanDist_'iA'$ <> "?"
            agDist = number(agMeanDist_'iA'$)
        else
            agDist = 0.55
        endif
        if agMeanAz_'iA'$ <> "?"
            estAz = number(agMeanAz_'iA'$)
        else
            estAz = 0
        endif
        azRad = (90 - estAz) * pi / 180
        ax = agDist * cos(azRad)
        ay = agDist * sin(azRad)
        Paint rectangle: thisCol$, ax - 0.055, ax + 0.055, ay - 0.055, ay + 0.055
    endfor

    # Labels are drawn last so text/viewport state cannot affect data paths.
    Select outer viewport: 0, 4, 2.5, 5.1
    Select inner viewport: 0.4, 3.8, 2.7, 4.9
    Axes: -1.5, 1.5, -1.5, 1.5
    Colour: "Black"
    Font size: 5
    for iSpk from 1 to nSpkDraw
        thisAz = spkAz_'iSpk'
        azRad = (90 - thisAz) * pi / 180
        tx = 1.36 * cos(azRad)
        ty = 1.36 * sin(azRad)
        Text: tx, "centre", ty, "half", spkLab_'iSpk'$
    endfor
    if spatial_format = 3
        Colour: "{0.34,0.38,0.48}"
        Text: -1.42, "left", -1.35, "half", "LFE <120 Hz (non-directional)"
    endif
    Colour: "Black"
    Font size: 6
    Text: 0, "centre", 1.45, "half", "front"
    Draw inner box
    Text top: "no", "Measured spatial trajectories"
    Text bottom: "yes", "radius = distance | square = mean agent position"

    # === Agent Spatial Stats ===
    Select outer viewport: 4, 8, 2.5, 5.1
    Select inner viewport: 4.2, 7.7, 2.7, 4.9

    Axes: 0, 1, 0, 1
    Paint rectangle: "{0.945,0.955,0.975}", 0, 1, 0, 1

    Font size: 7
    Colour: "Black"
    Text: 0.02, "left", 0.95, "half", "Agent Spatial Profiles:"

    yStep = 0.85 / max(1, number_of_agents)
    for iA from 0 to number_of_agents - 1
        yPos = 0.85 - iA * yStep
        thisCol$ = agCol_'iA'$
        Colour: thisCol$
        Font size: 6

        line1$ = agProfile_'iA'$ + " | Az range=" + agAzRange_'iA'$ + "° | Travel=" + agAzTravel_'iA'$ + "°"
        line2$ = "  Dist=" + agMeanDist_'iA'$ + " | Steps=" + agSteps_'iA'$ + " | Uniq=" + agUnique_'iA'$

        Text: 0.02, "left", yPos, "half", "Agent " + string$(iA) + ": " + line1$
        Text: 0.02, "left", yPos - yStep * 0.4, "half", line2$
    endfor

    Colour: "Black"
    Draw rectangle: 0, 1, 0, 1

    # === Spatial Separation + Unison Panel ===
    Select outer viewport: 0, 8, 5.2, 6.2
    Select inner viewport: 0.6, 7.7, 5.3, 6.1

    Axes: 0, 1, 0, 1
    Paint rectangle: "{0.955,0.965,0.980}", 0, 1, 0, 1

    Font size: 7
    Colour: "Black"
    Text: 0.02, "left", 0.88, "half", "Counterpoint & Spatial Separation:"

    Font size: 6
    Colour: "{0.3, 0.3, 0.3}"

    sepLine$ = ""
    uniLine$ = ""
    for iA from 0 to number_of_agents - 2
        for iB from iA + 1 to number_of_agents - 1
            thisSep$ = spatSep_'iA'_'iB'$
            thisUni$ = unisonRate_'iA'_'iB'$
            if thisSep$ <> "?"
                sepLine$ = sepLine$ + string$(iA) + "↔" + string$(iB) + "=" + thisSep$ + "°  "
            endif
            if thisUni$ <> "?"
                uniLine$ = uniLine$ + string$(iA) + "↔" + string$(iB) + "=" + thisUni$ + "  "
            endif
        endfor
    endfor
    Text: 0.02, "left", 0.58, "half", "Spatial: " + sepLine$
    Text: 0.02, "left", 0.22, "half", "Unison: " + uniLine$

    Colour: "Black"
    Draw rectangle: 0, 1, 0, 1

    # === Summary Panel ===
    Select outer viewport: 0, 8, 6.4, 7.9
    Select inner viewport: 0.6, 7.7, 6.5, 7.8

    Axes: 0, 1, 0, 1
    Paint rectangle: "{0.945,0.955,0.975}", 0, 1, 0, 1

    Font size: 7
    Colour: "Black"
    Text: 0.02, "left", 0.92, "half", "Summary:"
    Font size: 6
    Colour: "{0.3, 0.3, 0.3}"
    Text: 0.02, "left", 0.75, "half", "Agents -> latent PCA -> azimuth/distance -> " + spatFormatStat$ + " VBAP | " + distModelStat$
    Text: 0.02, "left", 0.55, "half", "Events: " + nEvStat$ + " | Unique used: " + totalUnique$ + " | Mean dur: " + meanEvDur$ + " s | Reverb=" + reverbStat$
    Text: 0.02, "left", 0.35, "half", "AE loss: " + initialLoss$ + " -> " + finalLoss$ + " | Latent=" + string$(latent_size) + " | Rigidity=" + fixed$(counterpoint_rigidity, 2) + " | Speed=" + fixed$(speed, 2)
    Text: 0.02, "left", 0.15, "half", "Duration: " + fixed$(dur, 2) + "s -> " + outDurStat$ + "s | Output channels: " + string$(nChOut) + " | Seed=" + string$(seed)

    if warningStat$ <> "?" and warningStat$ <> ""
        Colour: "{0.70,0.20,0.20}"
        Text: 0.62, "left", 0.15, "half", "Warning: " + warningStat$
    endif

    Colour: "Black"
    Draw rectangle: 0, 1, 0, 1

    Font size: 10
    Colour: "Black"
endif

# ===========================================================================
# Cleanup
# ===========================================================================
@cleanUpTempFiles

# ===========================================================================
# Summary
# ===========================================================================

appendInfoLine: ""
appendInfoLine: "=== COMPLETE ==="
appendInfoLine: "Output: ", soundName$, "_spat (", nChOut, " channels)"
appendInfoLine: "Preset: ", presetName$
appendInfoLine: "Format: ", spatFormatStat$, " | Distance: ", distModelStat$
appendInfoLine: ""

appendInfoLine: "Agent Spatial Profiles:"
for iA from 0 to number_of_agents - 1
    appendInfoLine: "  Agent ", string$(iA), ": ", agProfile_'iA'$, " | Az range=", agAzRange_'iA'$, "° | Travel=", agAzTravel_'iA'$, "° | Dist=", agMeanDist_'iA'$, " | Steps=", agSteps_'iA'$, " | Unique=", agUnique_'iA'$
endfor

appendInfoLine: ""
appendInfoLine: "Spatial Separation (degrees):"
for iA from 0 to number_of_agents - 2
    for iB from iA + 1 to number_of_agents - 1
        appendInfoLine: "  ", string$(iA), " ↔ ", string$(iB), ": ", spatSep_'iA'_'iB'$, "° (unison=", unisonRate_'iA'_'iB'$, ")"
    endfor
endfor

appendInfoLine: ""
appendInfoLine: "Duration: ", fixed$(dur, 2), " s -> ", outDurStat$, " s"
appendInfoLine: "Channels: ", nChOut
appendInfoLine: "Speaker layout: ", speakerLabels$

if warningStat$ <> "?" and warningStat$ <> ""
    appendInfoLine: ""
    appendInfoLine: "WARNING: ", warningStat$
endif

selectObject: resultSound

if play_result
    Play
endif

# ===========================================================================
# Procedures
# ===========================================================================

procedure parseStatLine: .text$, .key$
    .result$ = "?"
    .pos = index(.text$, .key$)
    if .pos > 0
        .start = .pos + length(.key$)
        .rest$ = mid$(.text$, .start, length(.text$) - .start + 1)
        .nlPos = index(.rest$, newline$)
        if .nlPos > 0
            .result$ = left$(.rest$, .nlPos - 1)
        else
            .result$ = .rest$
        endif
    endif
endproc