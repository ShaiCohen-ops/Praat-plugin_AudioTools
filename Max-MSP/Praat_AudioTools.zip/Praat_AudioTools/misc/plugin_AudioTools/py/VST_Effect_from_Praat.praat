# ============================================================
# Praat AudioTools - VST_Effect_from_Praat.praat
# Author: Shai Cohen
# Affiliation: Department of Music, Bar-Ilan University, Israel
# Email: shai.cohen@biu.ac.il
# Version: 1.7 (2026) - Toolbar host GUI; the Praat form no longer duplicates
#          the settings that live in the host window
# License: MIT License
# Repository: https://github.com/ShaiCohen-ops/Praat-plugin_AudioTools
#
# Description:
#   VST3 Effect - Praat -> Python host -> native VST3 editor/audition -> Praat
#
#   This script serves as a bridge between Praat and a Python-based 
#   GUI host for VST3 plugins. It allows users to process Praat 
#   Sound objects through external VST3 effects while maintaining 
#   a responsive front-end.
#
# Citation:
#   Cohen, S. (2026). VST3 Host:
#   Python GUI Bridge for Praat.
#   Praat AudioTools Plugin.
#   https://github.com/ShaiCohen-ops/Praat-plugin_AudioTools
#
# ============================================================

if numberOfSelected("Sound") <> 1
    exitScript: "Please select exactly one Sound object."
endif

sound = selected("Sound")
soundName$ = selected$("Sound")

q$ = """"

# ============================================================
# Platform setup & OS-SPECIFIC PYTHON DISCOVERY
# ============================================================

if macintosh
    if fileReadable("/opt/homebrew/bin/python3")
        pythonCmd$ = "/opt/homebrew/bin/python3"
    elsif fileReadable("/Library/Frameworks/Python.framework/Versions/3.14/bin/python3")
        pythonCmd$ = "/Library/Frameworks/Python.framework/Versions/3.14/bin/python3"
    elsif fileReadable("/usr/local/bin/python3")
        pythonCmd$ = "/usr/local/bin/python3"
    else
        pythonCmd$ = "python3"
    endif
    platform$ = "macOS"
elsif windows
    pythonCmd$ = "python"
    platform$ = "Windows"
else
    pythonCmd$ = "python3"
    platform$ = "Linux"
endif

# ---- PATHS & UNIFIED CROSS-PLATFORM FIX ----
pluginDirRaw$ = preferencesDirectory$ + "/plugin_AudioTools/"
pluginDir$ = replace_regex$(pluginDirRaw$, "\\", "/", 0)

# Prefer the versioned host so an older installed host_vst.py cannot silently
# shadow a newly downloaded fix. Fall back to the legacy filename for compatibility.
pythonScript$ = pluginDir$ + "py/host_vst_v1_7.py"
if not fileReadable(pythonScript$)
    pythonScript$ = defaultDirectory$ + "/host_vst_v1_7.py"
endif
if not fileReadable(pythonScript$)
    pythonScript$ = pluginDir$ + "py/host_vst_v1_6.py"
endif
if not fileReadable(pythonScript$)
    pythonScript$ = defaultDirectory$ + "/host_vst_v1_6.py"
endif
if not fileReadable(pythonScript$)
    pythonScript$ = pluginDir$ + "py/host_vst.py"
endif
if not fileReadable(pythonScript$)
    pythonScript$ = defaultDirectory$ + "/host_vst.py"
endif
if not fileReadable(pythonScript$)
    exitScript: "Cannot find Python VST host." + newline$ + "Expected host_vst_v1_7.py (preferred), host_vst_v1_6.py or host_vst.py in: " + pluginDir$ + "py/ or the current Praat directory."
endif

tempDirRaw$ = temporaryDirectory$ + "/"
tempDir$ = replace_regex$(tempDirRaw$, "\\", "/", 0)

tempInput$  = tempDir$ + "vst_temp_input.wav"
tempOutput$ = tempDir$ + "vst_temp_output.wav"
tempLog$    = tempDir$ + "vst_temp_gui_log.txt"
tempDone$   = tempDir$ + "vst_temp_done.txt"
probePy$    = tempDir$ + "vst_temp_probe.py"
probeMarker$= tempDir$ + "vst_temp_probe.ok"

# Persistent preference: remember the last-used VST plugin
prefsFile$ = pluginDir$ + "last_vst_plugin.txt"
legacyPrefsFile$ = defaultDirectory$ + "/../last_vst_plugin.txt"

# Preserve an existing Praat 6-era preference when running
# from the old plugin location under Praat 7
if not fileReadable(prefsFile$) and fileReadable(legacyPrefsFile$)
    prefsFile$ = legacyPrefsFile$
elsif not folderExists(pluginDir$)
    prefsFile$ = legacyPrefsFile$
endif

prefsFile$ = replace_regex$(prefsFile$, "\\", "/", 0)

# Enforce forward slashes for all paths passed to python
pythonScriptJ$ = replace_regex$(pythonScript$, "\\", "/", 0)
tempInputJ$    = replace_regex$(tempInput$, "\\", "/", 0)
tempOutputJ$   = replace_regex$(tempOutput$, "\\", "/", 0)
tempLogJ$      = replace_regex$(tempLog$, "\\", "/", 0)
tempDoneJ$     = replace_regex$(tempDone$, "\\", "/", 0)
probePyJ$      = replace_regex$(probePy$, "\\", "/", 0)
probeMarkerJ$  = replace_regex$(probeMarker$, "\\", "/", 0)
prefsFileJ$    = replace_regex$(prefsFile$, "\\", "/", 0)

# ---- CLEANUP PROCEDURE ----
procedure cleanUpTempFiles
    if fileReadable(tempInput$)
        deleteFile: tempInput$
    endif
    if fileReadable(tempOutput$)
        deleteFile: tempOutput$
    endif
    if fileReadable(tempLog$)
        deleteFile: tempLog$
    endif
    if fileReadable(tempDone$)
        deleteFile: tempDone$
    endif
    if fileReadable(probePy$)
        deleteFile: probePy$
    endif
    if fileReadable(probeMarker$)
        deleteFile: probeMarker$
    endif
endproc

@cleanUpTempFiles

# ===========================================================================
# Stage 0 — Early Python Dependency Probe
# ===========================================================================

writeFileLine: probePy$, "import sys"
appendFileLine: probePy$, "try:"
appendFileLine: probePy$, "    import pedalboard, soundfile, tkinter"
appendFileLine: probePy$, "    with open(r'" + probeMarkerJ$ + "', 'w') as f: f.write('ok')"
appendFileLine: probePy$, "except ImportError:"
appendFileLine: probePy$, "    sys.exit(1)"

if windows
    nCandidates = 4
    candidate1$ = "python"
    candidate2$ = "py"
    candidate3$ = "py -3"
    candidate4$ = "python3"
else
    nCandidates = 3
    candidate1$ = "python3"
    candidate2$ = "python"
    candidate3$ = "py"
    candidate4$ = ""
endif

# The probe result must be able to say "nothing worked". In v1.6 pythonCmd$ was
# pre-seeded with an OS default and only overwritten on success, so the
# "cannot find Python" branch below was unreachable: a machine without the
# packages launched a broken command and the user waited out the full 10-minute
# timeout instead of reading the one-line explanation.
pythonCmd$ = ""

for iCand from 1 to nCandidates
    if iCand = 1
        tryCmd$ = candidate1$
    elsif iCand = 2
        tryCmd$ = candidate2$
    elsif iCand = 3
        tryCmd$ = candidate3$
    else
        tryCmd$ = candidate4$
    endif

    if fileReadable(probeMarker$)
        deleteFile: probeMarker$
    endif

    runSystem_nocheck: tryCmd$ + " """ + probePyJ$ + """"

    if fileReadable(probeMarker$)
        pythonCmd$ = tryCmd$
        deleteFile: probeMarker$
        iCand = nCandidates + 1 ; Break early
    endif
endfor

deleteFile: probePy$

if pythonCmd$ = ""
    @cleanUpTempFiles
    exitScript: "Cannot find Python 3 installation with required packages." + newline$ + "Tried: python3, python, py" + newline$ + "Please install: pip install pedalboard soundfile"
endif

# ============================================================
# Load last-used plugin path
# ============================================================

defaultPlugin$ = ""
if fileReadable(prefsFile$)
    defaultPlugin$ = readFile$(prefsFile$)
    if right$(defaultPlugin$, 1) = newline$
        defaultPlugin$ = left$(defaultPlugin$, length(defaultPlugin$) - 1)
    endif
endif

# ============================================================
# Settings form  (lightweight – most settings are in the GUI)
# ============================================================

# The host window owns tail / buffer / parameters / plugin choice and persists
# them itself, so asking for them here made the user answer the same questions
# twice before seeing a single plugin. Only the genuinely Praat-side decision
# is left.
beginPause: "VST3 Effect - Launch Host v1.7"
    comment: "The host window handles plugin choice, the native VST3 editor and audition."
    if defaultPlugin$ <> ""
        comment: "Last plugin: " + defaultPlugin$
    else
        comment: "No last-used plugin yet - the host will scan for installed VST3s."
    endif
    boolean: "Play result", 1
clicked = endPause: "Cancel", "Open host", 2

if clicked = 1
    exitScript: "Cancelled."
endif

curPlay = play_result

# Empty strings tell the host "use your saved settings" (v1.7 treats an empty
# argument and an absent argument identically).
curTail$   = ""
curBuf$    = ""
curParams$ = ""

# The host writes the plugin the user actually picked, once a render succeeds.
prefsOutJ$ = prefsFileJ$

# ============================================================
# Write input WAV
# ============================================================

selectObject: sound
Save as WAV file: tempInput$

# ============================================================
# Build command  (--gui flag → Python opens the Tkinter window)
# Python will write tempDone$ when it exits (success or cancel).
# ============================================================

# Every argument is quoted, including the ones that may now be empty. An
# unquoted empty string collapses to nothing on the command line and silently
# shifts every later positional argument -- which would hand the host the
# sentinel path as its parameter string and leave Praat polling forever.
pyArgs$ = " --gui"
    ... + " " + q$ + tempInputJ$ + q$
    ... + " " + q$ + tempOutputJ$ + q$
    ... + " " + q$ + defaultPlugin$ + q$
    ... + " " + q$ + curTail$ + q$
    ... + " " + q$ + curBuf$ + q$
    ... + " " + q$ + curParams$ + q$
    ... + " " + q$ + tempDoneJ$ + q$
    ... + " " + q$ + prefsOutJ$ + q$

# Launch Python detached so Praat is NOT blocked
if windows
    # "start /b" launches without a new window and returns immediately
    cmd$ = "start /b " + pythonCmd$ + " " + q$ + pythonScriptJ$ + q$ + pyArgs$
    ...   + " > " + q$ + tempLogJ$ + q$ + " 2>&1"
else
    # "&" backgrounds the process on mac / Linux
    cmd$ = pythonCmd$ + " " + q$ + pythonScriptJ$ + q$ + pyArgs$
    ...   + " > " + q$ + tempLogJ$ + q$ + " 2>&1 &"
endif

clearinfo
writeInfoLine:  "=== Praat -> Python host -> native VST3 -> Praat ==="
appendInfoLine: "Input sound:   ", soundName$
appendInfoLine: "Platform:      ", platform$
appendInfoLine: "Python:        ", pythonCmd$
appendInfoLine: "VST host:      ", pythonScript$
appendInfoLine: ""
appendInfoLine: "Launching host GUI with native plugin editor and audition..."

runSystem_nocheck: cmd$

# ============================================================
# Poll for the sentinel file (Python writes it on exit).
# Praat stays fully responsive; the loop just checks the disk.
# Timeout after ~10 minutes (600 × 1 s pauses).
# ============================================================

appendInfoLine: "Waiting for Python host to finish..."

# Poll without a modal pause window. sleep() is the standard Praat scripting
# mechanism for a short timed wait; 6000 x 0.1 s = 10 minutes.
maxWait   = 6000
waited    = 0
gotResult = 0

repeat
    sleep(0.1)
    waited += 1
    if fileReadable(tempDone$)
        gotResult = 1
    endif
until gotResult = 1 or waited >= maxWait

# ============================================================
# Show Python log output
# ============================================================

if fileReadable(tempLog$)
    log$ = readFile$(tempLog$)
    appendInfoLine: log$
endif

# ============================================================
# Import result
# ============================================================

if waited >= maxWait and not gotResult
    appendInfoLine: ""
    appendInfoLine: "*** Timed out waiting for Python (10 min). ***"
    appendInfoLine: "The GUI may still be open. Close it and re-run if needed."
    @cleanUpTempFiles

elsif fileReadable(tempOutput$)
    Read from file: tempOutput$
    Rename: soundName$ + "_vst"
    resultSound = selected("Sound")
    
    appendInfoLine: "Done. Created: ", soundName$ + "_vst"

    # Default VST persistence is handled by the Python GUI so the plugin
    # selected from the new VST list is the one remembered next time.

    @cleanUpTempFiles

    if curPlay
        selectObject: resultSound
        Play
    endif
else
    appendInfoLine: ""
    appendInfoLine: "*** No output WAV produced. ***"
    appendInfoLine: "The user cancelled, or processing failed."
    appendInfoLine: "Check the log above for details."
    @cleanUpTempFiles
endif