# Wave Gesture Path Performer

Perform a playback **path** through a folder of sounds using the
**Genki Wave ring** (Bluetooth MIDI). Sounds are ordered by MFCC timbral
similarity (as in `Timbral_Similarity_Browser.praat`); you then record a
gesture take that steps through that path:

| Gesture | Controls |
|--------|----------|
| **Tilt** | which sound (position along the ordered path) |
| **Pan**  | scrub offset (nudge forward/back for non-linear motion) |
| **Roll** | velocity / volume |

Each take is concatenated into one rendered WAV, played, and a popup
offers another take.

This is **not** real-time: you record a gesture window, then the system
renders and plays the result.

---

## Why two files (Praat + Python)?

Praat cannot read MIDI or Bluetooth. So:

- **`wave_capture.py`** is the only part that touches the ring. It opens
  the BLE-MIDI port via `mido`, records the Tilt/Pan/Roll CC streams for
  the take duration, and writes a gesture CSV.
- **`Wave_Gesture_Path_Performer.praat`** orders the corpus, launches the
  Python helper, reads the CSV, renders the take, and loops.

They talk through plain files in a shared **work folder** (a capture job
+ a done-sentinel) — the same Praat<->Python pattern used elsewhere in
AudioTools.

---

## One-time setup

1. **Install Python deps** (Python 3):
   ```
   pip install mido python-rtmidi
   ```

2. **Pair the Wave ring** over Bluetooth (BLE MIDI) and keep **Genki
   Softwave** open. In Softwave, assign **Tilt, Pan, Roll** to MIDI CC
   numbers. The script defaults to **CC 16 / 17 / 18** — either set those
   in Softwave, or change the numbers in the Praat form to match.

3. **Put `wave_capture.py` in your work folder** (the folder you'll point
   the Praat script at). The Praat script runs
   `python <work_folder>/wave_capture.py <work_folder>`.

---

## Running

1. Open `Wave_Gesture_Path_Performer.praat` in Praat and **Run**.
2. Fill the form:
   - **Record seconds** — how long each take captures.
   - **Countdown seconds** — get-ready delay before recording.
   - **Cc tilt / pan / roll** — must match your Softwave assignment.
   - **Midi port name** — leave **empty** to auto-detect a port whose
     name contains "wave"/"genki"/"bluetooth"/"ble"; or type the exact
     port name (run the troubleshooting snippet below to list them).
   - **Pan scrub amount** — how many path positions Pan can nudge by.
   - **Grain seconds** — length of each gestured step in the take.
   - **Python command** — `python` (or `py` on Windows, or a full path).
   - **Work folder** — leave empty to get a chooser; must contain
     `wave_capture.py`.
3. Choose the **work folder**, then the **sound folder** (`.wav`s).
4. The script orders the corpus, then for each take:
   - shows a countdown (watch the Info window / `capture_status.txt`),
   - records while you move your hand,
   - renders + plays the take, saves `wave_takeN.wav` in the work folder,
   - pops up **Stop** / **Take N+1**.

---

## Output

- `wave_takeN.wav` — the rendered take(s), in the work folder.
- `gesture_takeN.csv` — the raw captured gesture (time, tilt, pan, roll,
  normalised 0..1) — keep these to re-render or analyse later.

---

## Troubleshooting

**List available MIDI ports** (to find the exact name):
```python
import mido
print(mido.get_input_names())
```

- **"python package 'mido' not installed"** — run the pip install above.
- **"No usable MIDI input port"** — the ring isn't paired / Softwave
  isn't bridging MIDI. Pair it, open Softwave, re-check the port list.
- **"no MIDI received; wrote flat path"** — capture ran but no CC arrived
  on the configured numbers. Confirm Tilt/Pan/Roll CCs in Softwave match
  the form (default 16/17/18), and that the ring is **active** (middle
  button).
- **Console window flashes / nothing plays** — make sure `python` is on
  PATH, or set **Python command** to `py` (Windows launcher) or a full
  interpreter path.

---

## Notes on the rendered audio

Grains are Hanning-windowed and **concatenated end-to-end** (your chosen
model), so each step has a soft attack/decay but adjacent grains butt
together — expect a gently scalloped, stepped texture rather than a
seamless legato. If you ever want seamless overlap instead, that's a
switch to equal-power overlap-add (as in `Morphic_Form.praat`).

The path ordering is deterministic (MFCC nearest-neighbor from the first
file), so the same folder always maps Tilt the same way — your gestures
are repeatable across sessions.
